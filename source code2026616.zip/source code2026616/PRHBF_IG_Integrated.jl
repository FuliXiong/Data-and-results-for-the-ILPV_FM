
# ===================================================================
# PRHBF_IG_Integrated.jl
# Iterated Greedy (IG) algorithm for PRHBF problem
# Integrates: skyline bin packing, group-to-mold assignment,
#             group sequencing, and vehicle routing
# ===================================================================

using JLD2, HDF5, LinearAlgebra, Plots, Statistics, DataFrames, Random
using JuMP, JLD, StatsBase, CSV, Dates, CPUTime
using Gurobi




const SCRIPT_DIR = @__DIR__
const TUNING_DIR = joinpath(SCRIPT_DIR, "..", "tuning_irace", "R", "results")

function load_tuning_params()
    try
        params_ig = CSV.File(joinpath(TUNING_DIR, "PRHBF_IG", "best_params_PRHBF_IG.csv")) |> first
        return (
            max_iteration = params_ig.max_iteration,
            d_para = params_ig.d_para,
            T_para = params_ig.T_para
        )
    catch e
        @warn "无法读取调参参数文件，使用默认参数: $e"
        return (
            max_iteration = 81,
            d_para = 3,
            T_para = 0.2473
        )
    end
end

const params_ig = load_tuning_params()
const maxIter_tuning = params_ig.max_iteration
const d_para_tuning = params_ig.d_para
const T_para_tuning = params_ig.T_para




# Skyline bin packing data structures
mutable struct SkylineSegment
    x::Int; width::Int; height::Int
end

mutable struct RectangleItem
    index::Int; width::Int; height::Int; rotated::Bool
end

mutable struct PackingItem
    id::Int; width::Int; height::Int
end

mutable struct PackingBin
    width::Int; height::Int
    items::Vector{Tuple{PackingItem,Tuple{Int,Int}}}
    remaining_width::Int; remaining_height::Int
end

PackingBin(width::Int, height::Int) = PackingBin(width, height, [], width, height)

function can_place(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int})
    x, y = position
    x + item.width <= bin.width && y + item.height <= bin.height || return false
    for (pi, pp) in bin.items
        px, py = pp
        x < px + pi.width && x + item.width > px &&
        y < py + pi.height && y + item.height > py && return false
    end
    true
end

place_item!(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int}) =
    push!(bin.items, (item, position))

function find_position_skyline(bin::PackingBin, item::PackingItem)
    for y in 0:(bin.height - item.height)
        for x in 0:(bin.width - item.width)
            can_place(bin, item, (x, y)) && return (x, y)
        end
    end
    nothing
end

function merge_adjacent_segments(segments::Vector{SkylineSegment})
    isempty(segments) && return segments
    merged = SkylineSegment[]; current = segments[1]
    for i in 2:length(segments)
        if segments[i].height == current.height
            current = SkylineSegment(current.x, current.width + segments[i].width, current.height)
        else
            push!(merged, current); current = segments[i]
        end
    end
    push!(merged, current); merged
end

function place_rectangle_on_skyline(
    segments::Vector{SkylineSegment}, item_w::Int, item_h::Int, x_pos::Int)
    new_segments = SkylineSegment[]
    cur_x = 0; seg_idx = 0
    for (i, seg) in enumerate(segments)
        if x_pos >= cur_x && x_pos < cur_x + seg.width
            seg_idx = i; break
        end
        cur_x += seg.width
    end
    seg_idx == 0 && (seg_idx = length(segments))
    left_w = x_pos - cur_x
    right_w = segments[seg_idx].width - left_w - item_w
    for i in 1:(seg_idx-1); push!(new_segments, segments[i]); end
    if left_w > 0
        push!(new_segments, SkylineSegment(segments[seg_idx].x, left_w, segments[seg_idx].height))
    end
    push!(new_segments, SkylineSegment(x_pos, item_w, segments[seg_idx].height + item_h))
    if right_w > 0
        push!(new_segments, SkylineSegment(x_pos + item_w, right_w, segments[seg_idx].height))
    end
    for i in (seg_idx+1):length(segments); push!(new_segments, segments[i]); end
    merge_adjacent_segments(new_segments)
end






function skyline_bf_packing_v2(Item, ran, pallet_width, pallet_height)
    itemNum = size(Item, 1)
    ansBXY = zeros(Int, itemNum, 6)
    result = zeros(Int, itemNum, 2)
    rotated = zeros(Int, itemNum)
    placed = Vector{Tuple{Int,Int,Int,Int,Int,Int}}()

    
    R = Vector{Tuple{Int, Int}}()  
    for (row_idx, orig_id) in enumerate(ran)
        w, h = Item[row_idx, 1], Item[row_idx, 2]
        rf = false
        if h > w; w, h = h, w; rf = true; end
        push!(R, (row_idx, orig_id))
    end

    bin_num = 0
    pallet_area = pallet_width * pallet_height

    while !isempty(R)
        bin_num += 1
        skyline = [SkylineSegment(0, pallet_width, 0)]

        
        L = Vector{Tuple{Int, Int}}()  
        total_area = 0
        idx = 1
        while idx <= length(R) && total_area < pallet_area
            row_idx, orig_id = R[idx]
            w, h = Item[row_idx, 1], Item[row_idx, 2]
            total_area += w * h
            push!(L, R[idx])
            idx += 1
        end

        
        for i in 1:length(L)
            row_idx, orig_id = L[i]
            w, h = Item[row_idx, 1], Item[row_idx, 2]
            if h > w
                L[i] = (row_idx, orig_id)
            end
        end
        sort!(L, by=x -> begin
            row_idx, _ = x
            w, h = Item[row_idx, 1], Item[row_idx, 2]
            return (-w, -h)
        end)

        
        for item in L
            rmi = findfirst(x -> x == item, R)
            if rmi !== nothing
                deleteat!(R, rmi)
            end
        end

        
        while !isempty(L)
            
            min_seg_idx = 0
            min_seg_h = typemax(Int)
            for (i, seg) in enumerate(skyline)
                if seg.height < min_seg_h
                    min_seg_h = seg.height
                    min_seg_idx = i
                end
            end

            seg = skyline[min_seg_idx]
            gap_h = seg.height
            gap_x = seg.x
            avail_w = seg.width
            avail_h = pallet_height - gap_h

            sky_dif = pallet_height - min_seg_h

            
            hwmin = minimum(min(Item[row_idx, 1], Item[row_idx, 2]) for (row_idx, _) in L)

            
            if sky_dif < hwmin
                reverse!(L)
                for item in L
                    insert!(R, 1, item)
                end
                break
            end

            
            best_item = nothing
            best_idx = 0
            best_score = -1

            for (idx, (row_idx, _)) in enumerate(L)
                w, h = Item[row_idx, 1], Item[row_idx, 2]
                if w <= avail_w && h <= avail_h
                    score = w * h
                    if score > best_score
                        best_score = score
                        best_item = (row_idx, L[idx][2])
                        best_idx = idx
                    end
                end
            end

            if best_item !== nothing
                row_idx, orig_id = best_item
                w, h = Item[row_idx, 1], Item[row_idx, 2]
                rf = (h > w)
                push!(placed, (orig_id, gap_x, gap_h, w, h, rf ? 1 : 0))
                ansBXY[row_idx, :] = [bin_num, orig_id, w, h, gap_x, gap_h]
                rotated[row_idx] = rf ? 1 : 0
                result[row_idx, :] = [orig_id, bin_num]

                deleteat!(L, best_idx)

                skyline = place_rectangle_on_skyline(skyline, w, h, gap_x)
            else
                if avail_w > 0 && avail_h > 0
                    skyline = place_rectangle_on_skyline(skyline, avail_w, avail_h, gap_x)
                end
            end
        end
    end

    boxes_dict = Dict{Int,Vector{Any}}()
    for b in 1:bin_num; boxes_dict[b] = []; end
    for i in 1:itemNum
        b = ansBXY[i, 1]
        orig_id = result[i, 1]
        if b > 0
            push!(boxes_dict[b], (Item[i, :], orig_id))
        end
    end

    bin_of = [ansBXY[i,1] for i in 1:itemNum]
    sorted_idx = sortperm(bin_of)
    final_result = zeros(Int, itemNum, 2)
    for (pos, i) in enumerate(sorted_idx)
        final_result[pos, 1] = result[i, 1]
        final_result[pos, 2] = result[i, 2]
    end

    wasted_space = 0
    return boxes_dict, ansBXY, ran, bin_num, final_result, rotated, wasted_space
end

function fast_packing_algorithm(items::Vector{PackingItem}, bin_width::Int, bin_height::Int)
    items = shuffle(items)
    J = length(items)
    Item_matrix = zeros(Int, J, 2)
    for (idx, item) in enumerate(items)
        Item_matrix[idx,1] = item.width; Item_matrix[idx,2] = item.height
    end
    ran = shuffle(1:J)
    boxes_dict, ansBXY, ran_out, BinNum, result, rotated, wasted_space =
        skyline_bf_packing_v2(Item_matrix, ran, bin_width, bin_height)
    bins = PackingBin[]
    for bin_id in 1:BinNum
        bin = PackingBin(bin_width, bin_height)
        for i in 1:size(ansBXY,1)
            if ansBXY[i,1] == bin_id
                item_id = ansBXY[i,2]; w = ansBXY[i,3]; h = ansBXY[i,4]
                x = ansBXY[i,5]; y = ansBXY[i,6]
                item = PackingItem(item_id, w, h)
                place_item!(bin, item, (x, y))
            end
        end
        push!(bins, bin)
    end
    bins
end

function print_bins(bins::Vector{PackingBin})
    result = []
    for (i, bin) in enumerate(bins)
        for (item, position) in bin.items
            push!(result, [item.id, i])
        end
    end
    result
end

calculate_utilization(placed, pallet_width, pallet_height) =
    sum(p[4]*p[5] for p in placed) / (pallet_width * pallet_height)

const packing_algorithm = skyline_bf_packing_v2
const Item = PackingItem
const Bin = PackingBin




function packing_by_sequence(items, seq, WW::Int, HH::Int)
    J = length(items)
    if isempty(seq)
        return fast_packing_algorithm(items, WW, HH)
    else
        return custom_packing_algorithm(items, seq, WW, HH)
    end
end

function custom_packing_algorithm(items, seq, WW::Int, HH::Int)
    J = length(items)
    Item_matrix = zeros(Int, J, 2)
    for (idx, item) in enumerate(items)
        Item_matrix[idx, 1] = item.width
        Item_matrix[idx, 2] = item.height
    end
    boxes_dict, ansBXY, ran_out, BinNum, result, rotated, wasted_space =
        skyline_bf_packing_v2(Item_matrix, seq, WW, HH)
    bins = Bin[]
    for bin_id in 1:BinNum
        bin = Bin(WW, HH)
        for i in 1:size(ansBXY, 1)
            if ansBXY[i, 1] == bin_id
                item_id = ansBXY[i, 2]
                w = ansBXY[i, 3]
                h = ansBXY[i, 4]
                x = ansBXY[i, 5]
                y = ansBXY[i, 6]
                item = PackingItem(item_id, w, h)
                place_item!(bin, item, (x, y))
            end
        end
        push!(bins, bin)
    end
    return bins
end

# Scheduling: makespan calculation
function makespan(p, G, W, mold_to_groups, group_to_mold, sequence_chromosome, ptr_time)
    phase2_complete_global = 0.0
    phase3_finish = zeros(Float64, G)
    ct = zeros(Float64, G)

    for g in sequence_chromosome
        if g < 1 || g > G
            continue
        end

        mold = group_to_mold[g]
        mold_groups_list = mold_to_groups[mold]
        g_idx_in_mold = findfirst(==(g), mold_groups_list)

        if g_idx_in_mold == 1
            phase1_start = 0.0
        else
            prev_group = mold_groups_list[g_idx_in_mold - 1]
            phase1_start = phase3_finish[prev_group]
        end

        phase1_complete = phase1_start + p[g, 1]
        phase2_start = max(phase1_complete, phase2_complete_global)
        phase2_complete = phase2_start + p[g, 2]
        phase2_complete_global = phase2_complete
        phase3_complete = phase2_complete + p[g, 3]
        phase3_finish[g] = phase3_complete
        ct[g] = phase3_complete + ptr_time
    end

    C = zeros(Float64, W)
    for mold in 1:W
        if haskey(mold_to_groups, mold) && !isempty(mold_to_groups[mold])
            C[mold] = maximum(ct[g] for g in mold_to_groups[mold])
        end
    end

    MK = maximum(C)
    return ct, C, MK
end

# TWT evaluation
function TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, tal_sol, v_result, ptr_time; verbose::Bool=false)
    ct, C, MK = makespan(p, G, W, mold_to_groups, group_to_mold, tal_sol, ptr_time)

    if isempty(ct) || any(isnan, ct) || any(isinf, ct)
        return Inf
    end

    ct_jobs = zeros(Int64, J)
    for pair in v_result
        job_id = pair[1]
        group_id = pair[2]
        if group_id <= length(ct)
            ct_jobs[job_id] = Int(ct[group_id])
        end
    end

    T = zeros(Int64, J)
    late_jobs = 0
    total_delay = 0
    for j in 1:J
        T[j] = ct_jobs[j] - d[j]
        if T[j] < 0
            T[j] = 0
        else
            late_jobs += 1
            total_delay += T[j]
        end
    end

    del_punish = sum(beta[j] * T[j] for j in 1:J)
    return del_punish
end





function mold_assignment_local_search!(
    group_to_mold,
    mold_to_groups,
    mold_load,
    p,
    G,
    W_num,
    beta,
    d,
    J,
    v_result,
    ptr_time;
    max_iterations::Int=50
)
    if G < 2 || W_num < 2
        return
    end
    
    
    initial_seq = collect(1:G)
    
    
    current_twt = TWT(beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, reshape(initial_seq, 1, length(initial_seq)), v_result, ptr_time)
    
    for iter in 1:max_iterations
        improved = false
        
        
        for g in 1:G
            current_mold = group_to_mold[g]
            
            
            for target_mold in 1:W_num
                if target_mold == current_mold
                    continue
                end
                
                
                old_mold = current_mold
                
                
                group_to_mold[g] = target_mold
                
                
                if !haskey(mold_to_groups, old_mold)
                    mold_to_groups[old_mold] = []
                end
                filter!(x -> x != g, mold_to_groups[old_mold])
                if !haskey(mold_to_groups, target_mold)
                    mold_to_groups[target_mold] = []
                end
                push!(mold_to_groups[target_mold], g)
                
                
                mold_load[old_mold] -= p[g, 1]
                mold_load[target_mold] += p[g, 1]
                
                
                new_twt = TWT(beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, reshape(initial_seq, 1, length(initial_seq)), v_result, ptr_time)
                
                if new_twt < current_twt - 1e-6  
                    current_twt = new_twt  
                    improved = true
                    
                else
                    
                    group_to_mold[g] = old_mold
                    if !haskey(mold_to_groups, target_mold)
                        mold_to_groups[target_mold] = []
                    end
                    filter!(x -> x != g, mold_to_groups[target_mold])
                    if !haskey(mold_to_groups, old_mold)
                        mold_to_groups[old_mold] = []
                    end
                    push!(mold_to_groups[old_mold], g)
                    mold_load[old_mold] += p[g, 1]
                    mold_load[target_mold] -= p[g, 1]
                end
            end
        end
        
        if !improved
            break  
        end
    end
end




function swap_mutation(seq_chromosome, alloc_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]
        alloc_chromosome[i], alloc_chromosome[j] = alloc_chromosome[j], alloc_chromosome[i]
    end
    return seq_chromosome, alloc_chromosome
end

function swap_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]
    end
    return seq_chromosome
end

function insert_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_elem = splice!(seq_chromosome, i)[1]
        insert!(seq_chromosome, j, seq_elem)
    end
    return seq_chromosome
end

function reverse_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = sort(rand(1:n, 2))
    if i != j
        seq_chromosome[i:j] = reverse(seq_chromosome[i:j])
    end
    return seq_chromosome
end




# VNS: Variable Neighborhood Search
function VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_chromosome)
    if G < 2
        TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)
        return copy(seq_chromosome), TWT_VALUE
    end

    k = 1
    TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)

    best_seq_chromosome = copy(seq_chromosome)
    new_seq_chromosome = copy(seq_chromosome)

    while k <= 3
        if k == 1
            new_seq_chromosome = swap_mutation1(copy(best_seq_chromosome))
        elseif k == 2
            new_seq_chromosome = insert_mutation1(copy(best_seq_chromosome))
        else
            new_seq_chromosome = reverse_mutation1(copy(best_seq_chromosome))
        end

        new_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_chromosome, 1, length(new_seq_chromosome)), v_result, ptr_time)

        if new_TWT < TWT_VALUE
            TWT_VALUE = new_TWT
            best_seq_chromosome = copy(new_seq_chromosome)
            k = 1
        else
            k += 1
        end
    end
    return best_seq_chromosome, TWT_VALUE
end




function NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    if G < 2
        if G == 1
            sol_NEH = [1]
        else
            return [1, 2], 0
        end
        TWT_sol = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH, 1, length(sol_NEH)), v_result, ptr_time)
        return reshape(sol_NEH, 1, length(sol_NEH)), TWT_sol
    end

    PT = sum(p, dims=2)
    PT1 = PT[:, 1]
    sol3 = sortperm(PT1)

    sol_prime = Int[]
    for i in 1:G
        push!(sol_prime, sol3[i])
    end

    sol_NEH = zeros(Int, 2)
    sol_NEH[1] = sol_prime[1]
    sol_NEH[2] = sol_prime[2]

    TWT_sol_NEH = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH, 1, length(sol_NEH)), v_result, ptr_time)

    sol_NEH2 = zeros(Int, 2)
    sol_NEH2[1] = sol_prime[2]
    sol_NEH2[2] = sol_prime[1]

    TWT_sol_NEH2 = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH2, 1, length(sol_NEH2)), v_result, ptr_time)

    if TWT_sol_NEH2 < TWT_sol_NEH
        sol_NEH = sol_NEH2
        TWT_sol_NEH = TWT_sol_NEH2
    end

    for k in 3:G
        Seq = zeros(Int64, k, k)
        TWT_Seq = zeros(Int64, k)

        for i in 1:k
            New_sol_NEH = zeros(Int64, length(sol_NEH))
            for u in 1:length(sol_NEH)
                New_sol_NEH[u] = sol_NEH[u]
            end
            insert!(New_sol_NEH, i, sol_prime[k])
            Seq[i, :] = New_sol_NEH
            TWT_Seq[i] = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(New_sol_NEH, 1, length(New_sol_NEH)), v_result, ptr_time)
        end

        min_val, best_index = findmin(TWT_Seq)
        sol_NEH = zeros(Int, k)
        sol_NEH = Seq[best_index, :]
        TWT_sol_NEH = min_val
    end

    return reshape(sol_NEH, 1, length(sol_NEH)), TWT_sol_NEH
end




function IG_Destruction(d, sol_Prime)
    n = length(sol_Prime)
    d = min(d, n)

    if n == 0
        return Int[], Int[]
    end

    d_Seq = randperm(n)
    New_Sol_Prime = zeros(Int64, n)
    New_Sol_R = zeros(Int64, d)

    for j = 1:n
        New_Sol_Prime[j] = sol_Prime[j]
    end
    for i in 1:d
        New_Sol_Prime[d_Seq[i]] = n + 1
        New_Sol_R[i] = sol_Prime[d_Seq[i]]
    end
    New_Sol_Prime = filter!(x -> x != n + 1, New_Sol_Prime)

    return New_Sol_Prime, New_Sol_R
end




function perturb_mold_assignment!(mold_to_groups, group_to_mold, mold_load, p, G, W_num; prob=0.3, max_perturb=2)
    if G < 2 || W_num < 2
        return
    end

    if rand() > prob
        return
    end

    perturb_count = rand(1:min(max_perturb, G))
    groups_to_move = randperm(G)[1:perturb_count]

    for g in groups_to_move
        old_mold = group_to_mold[g]
        possible_molds = filter(m -> m != old_mold, 1:W_num)
        if isempty(possible_molds)
            continue
        end

        new_mold = rand(possible_molds)
        group_to_mold[g] = new_mold
        filter!(x -> x != g, mold_to_groups[old_mold])
        push!(mold_to_groups[new_mold], g)
        mold_load[old_mold] -= p[g, 1]
        mold_load[new_mold] += p[g, 1]
    end
end

function IG_Reconstruction(sol_Prime, sol_R, beta, d, p, J, G, W, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time)
    n = length(sol_Prime) + length(sol_R)
    d_para = length(sol_R)
    n1 = n - d_para

    for k in 1:d_para
        TWT_Seq = zeros(n1 + k)

        for i in 1:(n1 + k)
            New_sol = [sol_Prime[j] for j in 1:length(sol_Prime)]
            insert!(New_sol, i, sol_R[k])
            TWT_Seq[i] = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(New_sol, 1, length(New_sol)), v_result, ptr_time)
        end

        min_val, best_index = findmin(TWT_Seq)
        sol_Prime = insert!(sol_Prime, best_index, sol_R[k])
    end

    perturb_mold_assignment!(mold_to_groups, group_to_mold, mold_load, p, G, W, prob=0.3, max_perturb=2)

    TWT_sol_Prime = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_Prime, 1, length(sol_Prime)), v_result, ptr_time)
    return sol_Prime, TWT_sol_Prime
end




# IG: Iterated Greedy main loop (destruction + reconstruction + SA acceptance)
function IG_twt(max_iteration, d_para, T_para, alpha, beta, d, p, J, G, W, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time, time_limit)
    if G < 2
        if G == 1
            tal_sol_best = [1]
        else
            tal_sol_best = [1, 2]
        end
        TWT_sol_best = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(tal_sol_best, 1, length(tal_sol_best)), v_result, ptr_time)
        return reshape(tal_sol_best, 1, length(tal_sol_best)), TWT_sol_best
    end

    Temp = T_para * sum(p) / (10 * J * G)

    tal_sol_best = zeros(Int, G)
    TWT_sol_best = 0

    tal_sol_0, tal_sol_TWT_0 = NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    tal_sol_0 = ndims(tal_sol_0) == 2 ? vec(tal_sol_0) : tal_sol_0

    tal_sol_0, tal_sol_TWT_0 = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, tal_sol_0)

    tal_sol_best = copy(tal_sol_0)
    TWT_sol_best = copy(tal_sol_TWT_0)

    iteration = 0
    start_time = time()

    while time() - start_time < time_limit
        sol_Prime, sol_R = IG_Destruction(d_para, tal_sol_0)

        tal_sol_Prime, TWT_Prime = IG_Reconstruction(sol_Prime, sol_R, beta, d, p, J, G, W, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time)

        tal_sol_Prime, TWT_Prime = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, tal_sol_Prime)

        g = rand()
        sa = exp(-(TWT_sol_best - TWT_Prime) / Temp)

        if TWT_Prime < tal_sol_TWT_0
            tal_sol_0 = copy(tal_sol_Prime)
            tal_sol_TWT_0 = TWT_Prime
            if tal_sol_TWT_0 < TWT_sol_best
                tal_sol_best = tal_sol_0
                TWT_sol_best = tal_sol_TWT_0
            end
        elseif g <= sa
            tal_sol_TWT_0 = TWT_Prime
            tal_sol_0 = tal_sol_Prime
        end

        Temp = alpha * Temp
        iteration += 1
    end

    return reshape(tal_sol_best, 1, length(tal_sol_best)), TWT_sol_best
end




# Vehicle routing: MILP vehicle assignment (Gurobi)
function yunshu(J, W, wg, rho, Q; verbose::Bool=false)
    V = J
    model = Model(Gurobi.Optimizer)

    time_limit = W > 0 ? J * W * 0.02 : 60

    if verbose
        println("    [yunshu诊断] J=$J, V=$V, rho=$rho, Q=$Q")
        println("    [yunshu诊断] 工件总重量=$(round(sum(wg), digits=2)), 最小所需车辆数=$(ceil(Int, sum(wg)/Q))")
    end

    try
        @variable(model, X[j=1:J, v=1:V], Bin)
        @variable(model, γ[v=1:V], Bin)

        @objective(model, Min, sum(rho * γ[v] for v in 1:V))

        @constraint(model, [j in 1:J], sum(X[j, v] for v in 1:V) == 1)
        @constraint(model, [j in 1:J, v in 1:V], X[j, v] <= γ[v])
        @constraint(model, [v in 1:V], sum(wg[j] * X[j, v] for j in 1:J) <= Q * γ[v])

        set_optimizer_attribute(model, "OutputFlag", 0)
        set_time_limit_sec(model, time_limit)
        set_silent(model)
        optimize!(model)

        status = termination_status(model)

        if status == OPTIMAL || status == TIME_LIMIT
            v_cost = objective_value(model)
            X_val = value.(X)
            vehicle_num = sum(γ[v] for v in 1:V) |> value |> Int
            v_status = zeros(Int, J)
            for j in 1:J
                for v in 1:V
                    if value(X_val[j, v]) > 0.5
                        v_status[j] = v
                        break
                    end
                end
            end
            return v_cost, vehicle_num, v_status
        else
            return Inf, 0, zeros(Int, J)
        end
    catch e
        return Inf, 0, zeros(Int, J)
    end
end




function perturb_sequence(seq; stagnate_limit::Int=5)
    if isempty(seq)
        return seq
    end

    n = length(seq)
    if n < 2
        return seq
    end

    idxs = shuffle(1:n)
    i, j = idxs[1], idxs[2]
    new_seq = copy(seq)
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    return new_seq
end


function is_similar_item(item1, item2; δ_w::Float64=0.1, δ_h::Float64=0.1)
    w1, h1 = item1
    w2, h2 = item2
    return abs(w1 - w2) < δ_w && abs(h1 - h2) < δ_h
end


function find_similar_pairs(seq, w, h; δ_w::Float64=0.1, δ_h::Float64=0.1)
    n = length(seq)
    similar_pairs = Vector{Tuple{Int, Int}}()
    for i in 1:n
        for j in (i+1):n
            job_i = seq[i]
            job_j = seq[j]
            item_i = (w[job_i], h[job_i])
            item_j = (w[job_j], h[job_j])
            if is_similar_item(item_i, item_j; δ_w=δ_w, δ_h=δ_h)
                push!(similar_pairs, (i, j))
            end
        end
    end
    return similar_pairs
end


# Perturbation: layout-aware neighborhood search
function neighborhood_perturb(seq, w, h, WW, HH; δ_w::Float64=0.1, δ_h::Float64=0.1)
    if isempty(seq)
        return seq, false
    end
    n = length(seq)
    if n < 2
        return seq, false
    end
    similar_pairs = find_similar_pairs(seq, w, h; δ_w=δ_w, δ_h=δ_h)
    if isempty(similar_pairs)
        return seq, false
    end
    i, j = rand(similar_pairs)
    new_seq = copy(seq)
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    items = [Item(idx, wi, hi) for (idx, (wi, hi)) in enumerate(zip(w, h))]
    bins = packing_by_sequence(items, new_seq, WW, HH)
    if length(bins) > 0
        return new_seq, true
    end
    return seq, false
end


function perturb_layout_sequence(seq, w, h, WW, HH; max_attempts::Int=10)
    if isempty(seq)
        return seq, false
    end
    n = length(seq)
    if n < 2
        return seq, false
    end
    for attempt in 1:max_attempts
        new_seq = copy(seq)
        success = false
        if attempt == 1
            new_seq, success = neighborhood_perturb(seq, w, h, WW, HH)
            if success
                return new_seq, true
            end
        end
        idxs = shuffle(1:n)
        i, j = idxs[1], idxs[2]
        new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
        items = [Item(idx, wi, hi) for (idx, (wi, hi)) in enumerate(zip(w, h))]
        bins = packing_by_sequence(items, new_seq, WW, HH)
        if length(bins) > 0
            return new_seq, true
        end
    end
    return seq, false
end




# Core integration: packing -> mold assignment -> IG scheduling -> vehicle routing
function BF_IG(J, W_num, w, h, pt, d, beta, ptr_time, wg, tal_seq, WW, HH, rho, Q, α)
    ig_time_limit = J * W_num * 0.02

    items = [Item(i, wi, hi) for (i, (wi, hi)) in zip(1:length(w), zip(w, h))]
    
    bins = packing_by_sequence(items, tal_seq, WW, HH)
    
    v_result = print_bins(bins)

    G = length(bins)

    bin_to_jobs = Dict{Int, Vector{Int}}()
    for pair in v_result
        job_id = pair[1]
        bin_id = pair[2]
        if haskey(bin_to_jobs, bin_id)
            push!(bin_to_jobs[bin_id], job_id)
        else
            bin_to_jobs[bin_id] = [job_id]
        end
    end

    p = zeros(G, 4)

    for (bin_id, jobs) in bin_to_jobs
        p1 = []
        p3 = []
        for j in jobs
            p[bin_id, 2] += pt[j, 2]
            push!(p1, pt[j, 1])
            push!(p3, pt[j, 3])
        end
        p[bin_id, 1] = maximum(p1)
        p[bin_id, 3] = maximum(p3)
    end

    p[:, 4] .= ptr_time

    group_to_mold = Dict{Int, Int}()
    mold_to_groups = Dict{Int, Vector{Int}}()
    mold_load = zeros(W_num)

    sorted_bins = sortperm([p[bin_id, 1] for bin_id in 1:G])

    for bin_id in sorted_bins
        lightest_mold = argmin(mold_load)
        group_to_mold[bin_id] = lightest_mold
        if haskey(mold_to_groups, lightest_mold)
            push!(mold_to_groups[lightest_mold], bin_id)
        else
            mold_to_groups[lightest_mold] = [bin_id]
        end
        mold_load[lightest_mold] += p[bin_id, 1]
    end

    
    mold_assignment_local_search!(
        group_to_mold, mold_to_groups, mold_load, p, G, W_num,
        beta, d, J, v_result, ptr_time
    )

    max_iteration = maxIter_tuning
    d_para = d_para_tuning
    T_para = T_para_tuning
    alpha_cooling = 0.995

    tal_sol_best, tardiness_cost = IG_twt(max_iteration, d_para, T_para, alpha_cooling, beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time, ig_time_limit)
    tal_sol_best = ndims(tal_sol_best) == 2 ? vec(tal_sol_best) : tal_sol_best

    v_cost, vehicle_num, v_status = yunshu(J, W_num, wg, rho, Q)

    group_activation_cost = G * α
    best_cost = v_cost + tardiness_cost + group_activation_cost

    return tal_sol_best, best_cost, G, tardiness_cost, v_result, p, group_to_mold, mold_to_groups, v_cost, tardiness_cost, group_activation_cost
end




# Main entry: repeated perturbation + BF_IG search
function main(filenm)
    best_seq = []
    best_group_sequence = Int[]
    best_G = typemax(Int)
    best_cost = 1e10
    best_v_result = []
    best_p = zeros(0, 0)
    best_group_to_mold = Dict{Int, Int}()
    best_mold_to_groups = Dict{Int, Vector{Int}}()
    best_v_cost = 0.0
    best_tardiness_cost = 0.0
    best_mold_activation_cost = 0.0
    best_stats = nothing

    J = load(filenm, "JJ")
    W = load(filenm, "WW_num")

    WW = load(filenm, "WW")
    HH = load(filenm, "HH")
    α = load(filenm, "alpha")

    w = load(filenm, "wj")
    h = load(filenm, "hj")

    pt = load(filenm, "pp")
    d = load(filenm, "dd")
    β = load(filenm, "betabeta")
    ptr = load(filenm, "ptr")

    wg = load(filenm, "wg")

    Q = load(filenm, "Q")
    rho = load(filenm, "rho")

    items = hcat(w, h)
    max_time = J * W * 0.5  
    start_time = time()

    
    init_seq = shuffle(1:J)
    try
        result = BF_IG(J, W, w, h, pt, d, β, ptr, wg, init_seq, WW, HH, rho, Q, α)
        current_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_mold_activation_cost = result
        current_group_sequence = current_seq
        if current_G < best_G
            best_seq = current_seq
            best_group_sequence = current_group_sequence
            best_G = current_G
            best_cost = current_cost
            best_v_result = current_v_result
            best_p = current_p
            best_group_to_mold = current_group_to_mold
            best_mold_to_groups = current_mold_to_groups
            best_v_cost = current_v_cost
            best_tardiness_cost = current_tardiness_cost
            best_mold_activation_cost = current_mold_activation_cost
        end
    catch e
        
    end

    empty_init_attempts = 0
    while time() - start_time < max_time
        if isempty(best_seq)
            empty_init_attempts += 1
            if empty_init_attempts > 10
                break  
            end
            perturb_seq = shuffle(1:J)
            try
                result = BF_IG(J, W, w, h, pt, d, β, ptr, wg, perturb_seq, WW, HH, rho, Q, α)
                current_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_mold_activation_cost = result
                current_group_sequence = current_seq
                if current_G < best_G
                    best_seq = current_seq
                    best_group_sequence = current_group_sequence
                    best_G = current_G
                    best_cost = current_cost
                    best_v_result = current_v_result
                    best_p = current_p
                    best_group_to_mold = current_group_to_mold
                    best_mold_to_groups = current_mold_to_groups
                    best_v_cost = current_v_cost
                    best_tardiness_cost = current_tardiness_cost
                    best_mold_activation_cost = current_mold_activation_cost
                    best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups, best_v_cost, best_tardiness_cost, best_mold_activation_cost)
                end
            catch e
                
            end
        else
            perturb_seq = copy(best_seq)
            
            perturb_seq, success = neighborhood_perturb(perturb_seq, w, h, WW, HH)
            if success
                try
                    result = BF_IG(J, W, w, h, pt, d, β, ptr, wg, perturb_seq, WW, HH, rho, Q, α)
                    current_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_mold_activation_cost = result
                    current_group_sequence = current_seq
                    if current_G <= best_G
                        best_seq = current_seq
                        best_group_sequence = current_group_sequence
                        best_G = current_G
                        best_cost = current_cost
                        best_v_result = current_v_result
                        best_p = current_p
                        best_group_to_mold = current_group_to_mold
                        best_mold_to_groups = current_mold_to_groups
                        best_v_cost = current_v_cost
                        best_tardiness_cost = current_tardiness_cost
                        best_mold_activation_cost = current_mold_activation_cost
                        continue
                    end
                catch e
                    
                end
            end
            
            ratio = rand() * 0.1 + 0.2
            k = max(1, floor(Int, J * ratio))
            idxs = shuffle(1:J)
            swap_idxs = idxs[1:k]
            swap_vals = perturb_seq[swap_idxs]
            shuffle!(swap_vals)
            perturb_seq[swap_idxs] = swap_vals
            
            try
                result = BF_IG(J, W, w, h, pt, d, β, ptr, wg, perturb_seq, WW, HH, rho, Q, α)
                current_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_mold_activation_cost = result
                current_group_sequence = current_seq
                if current_G <= best_G
                    best_seq = current_seq
                    best_group_sequence = current_group_sequence
                    best_G = current_G
                    best_cost = current_cost
                    best_v_result = current_v_result
                    best_p = current_p
                    best_group_to_mold = current_group_to_mold
                    best_mold_to_groups = current_mold_to_groups
                    best_v_cost = current_v_cost
                    best_tardiness_cost = current_tardiness_cost
                    best_mold_activation_cost = current_mold_activation_cost
                    best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups, best_v_cost, best_tardiness_cost, best_mold_activation_cost)
                elseif current_cost < best_cost || rand() < exp(-α * (current_G - best_G))
                    best_seq = current_seq
                    best_group_sequence = current_group_sequence
                    best_G = current_G
                    best_cost = current_cost
                    best_v_result = current_v_result
                    best_p = current_p
                    best_group_to_mold = current_group_to_mold
                    best_mold_to_groups = current_mold_to_groups
                    best_v_cost = current_v_cost
                    best_tardiness_cost = current_tardiness_cost
                    best_mold_activation_cost = current_mold_activation_cost
                    best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups, best_v_cost, best_tardiness_cost, best_mold_activation_cost)
                end
            catch e
                
            end
        end
    end

    run_time = time() - start_time

    if best_stats === nothing && !isempty(best_seq)
        best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho,
            best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
            best_v_cost, best_tardiness_cost, best_mold_activation_cost)
    end

    result = (run_time, best_seq, best_cost, best_G,
              best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
              best_v_cost, best_tardiness_cost, best_mold_activation_cost, best_stats)

    return result
end

# Solution statistics builder
function build_solution_statistics(J, W, WW, HH, w, h, d, beta, rho,
    best_seq, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
    best_v_cost, best_tardiness_cost, mold_activation_cost)

    mold_area = WW * HH
    group_jobs = Dict{Int, Vector{Int}}()
    for pair in best_v_result
        job_id = pair[1]
        group_id = pair[2]
        if !haskey(group_jobs, group_id)
            group_jobs[group_id] = Int[]
        end
        push!(group_jobs[group_id], job_id)
    end

    mold_utilization = Dict{Int, Float64}()
    group_utilization = Dict{Int, Float64}()
    for (group_id, jobs) in group_jobs
        used_area = sum(w[j] * h[j] for j in jobs)
        group_utilization[group_id] = mold_area > 0 ? used_area / mold_area : 0.0
    end
    for mold in 1:W
        group_ids = get(best_mold_to_groups, mold, Int[])
        mold_utilization[mold] = isempty(group_ids) ? 0.0 : mean(get(group_utilization, group_id, 0.0) for group_id in group_ids)
    end

    vehicle_assignments = Dict{Int, Int}()
    max_vehicle_id = 0
    if best_v_result isa AbstractVector
        for item in best_v_result
            if item isa Tuple && length(item) >= 3
                vehicle_id = item[3]
                if vehicle_id isa Number && vehicle_id > 0
                    vehicle_assignments[item[1]] = Int(vehicle_id)
                    max_vehicle_id = max(max_vehicle_id, Int(vehicle_id))
                end
            end
        end
    end

    vehicle_count = max_vehicle_id > 0 ? max_vehicle_id : (rho > 0 ? Int(round(best_v_cost / rho)) : 0)

    tardy_jobs = Vector{NamedTuple{(:job_id, :completion_time, :due_date, :tardiness, :penalty), Tuple{Int, Float64, Float64, Float64, Float64}}}()

    if !isempty(best_seq) && !isempty(best_p) && !isempty(best_group_to_mold) && !isempty(best_mold_to_groups)
        seq_vec = best_seq isa AbstractVector ? collect(best_seq) : vec(best_seq)
        ct, _, _ = makespan(best_p, size(best_p, 1), W, best_mold_to_groups, best_group_to_mold, seq_vec, best_p[1, 4])

        for j in 1:J
            group_id = get(Dict(pair[1] => pair[2] for pair in best_v_result), j, 0)
            
            if group_id >= 1 && group_id <= length(ct)
                completion_time = ct[group_id]
            else
                completion_time = 0.0
            end
            tardiness = max(completion_time - d[j], 0.0)
            penalty = beta[j] * tardiness
            if tardiness > 1e-6
                push!(tardy_jobs, (
                    job_id = j,
                    completion_time = completion_time,
                    due_date = d[j],
                    tardiness = tardiness,
                    penalty = penalty,
                ))
            end
        end
    end

    total_tardy_penalty = sum(item.penalty for item in tardy_jobs)

    return (
        mold_utilization = mold_utilization,
        group_utilization = group_utilization,
        average_mold_utilization = isempty(group_utilization) ? 0.0 : mean(values(group_utilization)),
        vehicle_count = vehicle_count,
        vehicle_cost = best_v_cost,
        tardy_jobs = tardy_jobs,
        total_tardy_penalty = total_tardy_penalty,
        mold_activation_cost = mold_activation_cost,
    )
end

# Print solution statistics
function print_solution_statistics(stats, G, alpha)
    println("  工件组面积利用率:")
    for group_id in sort(collect(keys(stats.group_utilization)))
        println("    工件组 $(group_id): $(round(stats.group_utilization[group_id] * 100, digits=2))%")
    end
    println("  平均工件组面积利用率 = $(round(stats.average_mold_utilization * 100, digits=2))%")
    println("  使用车辆数量 = $(stats.vehicle_count)")
    println("  拖期工件数量 = $(length(stats.tardy_jobs))")
    println("  总拖期费用 = $(round(stats.total_tardy_penalty, digits=2))")

    println("\n  成本分解:")
    println("    车辆成本 (V) = $(round(stats.vehicle_cost, digits=2))")
    println("    拖期成本 (T) = $(round(stats.total_tardy_penalty, digits=2))")
    println("    模台激活成本 (M = G × α = $G × $alpha) = $(round(stats.mold_activation_cost, digits=2))")
    total_cost = stats.vehicle_cost + stats.total_tardy_penalty + stats.mold_activation_cost
    println("    总成本 = $(round(total_cost, digits=2))")

    if isempty(stats.tardy_jobs)
        println("  无拖期工件")
    else
        println("  拖期工件明细:")
        for item in stats.tardy_jobs
            println("    工件 $(item.job_id): 完工=$(round(item.completion_time, digits=2)), 交期=$(round(item.due_date, digits=2)), 拖期=$(round(item.tardiness, digits=2)), 费用=$(round(item.penalty, digits=2))")
        end
    end
end

# Test drivers
function single_instance_test(filenm; num_runs=5)
    println("=" ^ 70)
    println("PRHBF-IG 单实例测试 (集成版)")
    println("=" ^ 70)
    println("实例文件: $(basename(filenm))")
    println("运行次数: $num_runs")
    println("=" ^ 70)

    J = load(filenm, "JJ")
    WW_num = load(filenm, "WW_num")
    WW = load(filenm, "WW")
    HH = load(filenm, "HH")
    α = load(filenm, "alpha")
    wg = load(filenm, "wg")
    Q = load(filenm, "Q")
    rho = load(filenm, "rho")

    println("\n实例参数:")
    println("  工件数 J = $J")
    println("  模台数 WW_num = $WW_num")
    println("  模台尺寸 WW × HH = $WW × $HH")
    println("  模台激活成本 α = $α")
    println("  总重量 = $(sum(wg))")
    println("  车辆载量 Q = $Q, 固定成本 ρ = $rho")
    println("  最小车辆数 = $(ceil(Int, sum(wg)/Q))")

    check_out = zeros(num_runs)
    check_time = zeros(num_runs)
    check_vehicle_count = fill(NaN, num_runs)
    check_vehicle_cost = fill(NaN, num_runs)
    check_mold_utilization = fill(NaN, num_runs)
    check_tardy_penalty = fill(NaN, num_runs)
    check_mold_activation_cost = fill(NaN, num_runs)

    for op in 1:num_runs
        println("\n--- 第 $op/$num_runs 次运行 ---")
        try
            r = main(filenm)
            run_time, best_tal, best_cost, best_bin_num = r[1:4]
            stats = r[end]
            check_out[op] = best_cost
            check_time[op] = run_time
            if stats !== nothing
                check_vehicle_count[op] = stats.vehicle_count
                check_vehicle_cost[op] = stats.vehicle_cost
                check_mold_utilization[op] = stats.average_mold_utilization
                check_tardy_penalty[op] = stats.total_tardy_penalty
                check_mold_activation_cost[op] = stats.mold_activation_cost
            end
            println("  组数 G = $best_bin_num")
            println("  成本 = $best_cost")
            println("  运行时间 = $(round(run_time, digits=2))s")
            println("  最优序列 = $best_tal")
            if stats !== nothing
                print_solution_statistics(stats, best_bin_num, α)
            end
        catch e
            println("  错误: $e")
            check_out[op] = NaN
            check_time[op] = NaN
        end
    end

    println("\n" * "=" ^ 70)
    println("统计结果")
    println("=" ^ 70)

    valid_costs = filter(!isnan, check_out)
    valid_times = filter(!isnan, check_time)

    if !isempty(valid_costs)
        println("  成本: 最小=$(minimum(valid_costs)), 最大=$(maximum(valid_costs)), 平均=$(round(mean(valid_costs), digits=2))")
        println("  时间: 最小=$(round(minimum(valid_times), digits=2))s, 最大=$(round(maximum(valid_times), digits=2))s, 平均=$(round(mean(valid_times), digits=2))s")

        best_run_idx = argmin(valid_costs)
        best_cost = valid_costs[best_run_idx]
        avg_vehicle_cost = mean(filter(!isnan, check_vehicle_cost))
        avg_tardy_penalty = mean(filter(!isnan, check_tardy_penalty))
        avg_mold_activation_cost = mean(filter(!isnan, check_mold_activation_cost))

        println("\n  最佳成本分解 (第 $(findfirst(x -> x == valid_costs[best_run_idx], check_out)) 次运行):")
        println("    总成本 = $best_cost")
        println("    平均车辆成本 = $(round(avg_vehicle_cost, digits=2))")
        println("    平均拖期惩罚 = $(round(avg_tardy_penalty, digits=2))")
        println("    平均模台激活成本 = $(round(avg_mold_activation_cost, digits=2))")
    else
        println("  所有运行都失败了！")
    end

    println("=" ^ 70)

    return (costs=check_out, times=check_time)
end

# Batch test
function batch_test(; num_runs=5)
    data_dir = joinpath(@__DIR__, "DATA_Instances")
    results_dir = joinpath(@__DIR__, "results")
    if !isdir(results_dir)
        mkdir(results_dir)
    end

    timestamp = Dates.format(now(), "YYYYMMDD_HHmmss")
    output_file = joinpath(results_dir, "PRHBF_IG_$(timestamp).csv")

    if !isdir(data_dir)
        error("数据目录不存在: $data_dir")
    end

    local all_files = []
    direct_files = [joinpath(data_dir, f) for f in readdir(data_dir) if endswith(f, ".jld2")]
    all_files = vcat(all_files, direct_files)

    for subdir in readdir(data_dir)
        subpath = joinpath(data_dir, subdir)
        if isdir(subpath)
            files = [joinpath(subpath, f) for f in readdir(subpath) if endswith(f, ".jld2")]
            all_files = vcat(all_files, files)
        end
    end
    all_files = sort(all_files)

    println("共找到 $(length(all_files)) 个数据集文件")
    println("每个实例运行 $num_runs 次")
    println("=" ^ 70)

    results = []

    total = length(all_files)
    for (idx, filenm) in enumerate(all_files)
        println("[$idx/$total] 正在测试: $(basename(filenm))")

        check_out = zeros(num_runs)
        check_time = zeros(num_runs)
        check_vehicle_count = fill(NaN, num_runs)
        check_vehicle_cost = fill(NaN, num_runs)
        check_mold_utilization = fill(NaN, num_runs)
        check_tardy_penalty = fill(NaN, num_runs)
        check_mold_activation_cost = fill(NaN, num_runs)

        for op in 1:num_runs
            try
                r = main(filenm)
                check_out[op] = r[3]
                check_time[op] = r[1]
                if r[12] !== nothing
                    check_vehicle_count[op] = r[12].vehicle_count
                    check_vehicle_cost[op] = r[12].vehicle_cost
                    check_mold_utilization[op] = r[12].average_mold_utilization
                    check_tardy_penalty[op] = r[12].total_tardy_penalty
                    check_mold_activation_cost[op] = r[12].mold_activation_cost
                end
            catch e
                println("  错误: $e")
                check_out[op] = NaN
                check_time[op] = NaN
            end
        end

        val_cost = mean(filter(!isnan, check_out))
        val_time = mean(filter(!isnan, check_time))
        avg_vehicle_count = mean(filter(!isnan, check_vehicle_count))
        avg_vehicle_cost = mean(filter(!isnan, check_vehicle_cost))
        avg_mold_utilization = mean(filter(!isnan, check_mold_utilization))
        avg_tardy_penalty = mean(filter(!isnan, check_tardy_penalty))
        avg_mold_activation_cost = mean(filter(!isnan, check_mold_activation_cost))

        push!(results, (instance=basename(filenm),
            (Symbol("cost$i") => check_out[i] for i in 1:num_runs)...,
            avg_cost=val_cost, avg_time=val_time,
            (Symbol("vehicle_count$i") => check_vehicle_count[i] for i in 1:num_runs)...,
            avg_vehicle_count=avg_vehicle_count,
            (Symbol("util$i") => (isnan(check_mold_utilization[i]) ? NaN : round(Int, check_mold_utilization[i] * 100)) for i in 1:num_runs)...,
            avg_mold_utilization=(isnan(avg_mold_utilization) ? NaN : round(Int, avg_mold_utilization * 100)),
            (Symbol("tardy$i") => check_tardy_penalty[i] for i in 1:num_runs)...,
            avg_tardy_penalty=avg_tardy_penalty))

        println("  -> 平均成本: $(round(val_cost, digits=2)), 平均时间: $(round(val_time, digits=2))s")
        println("     平均车辆数: $(round(avg_vehicle_count, digits=2)), 平均车辆成本: $(round(avg_vehicle_cost, digits=2)), 平均工件组面积利用率: $(round(Int, avg_mold_utilization * 100))%")
        println("     平均拖期惩罚: $(round(avg_tardy_penalty, digits=2)), 平均模台激活成本: $(round(avg_mold_activation_cost, digits=2))")
    end

    df = DataFrame(results)
    CSV.write(output_file, df)
    println("\n测试完成！结果已保存到: $output_file")
end


if abspath(PROGRAM_FILE) == @__FILE__
    if length(ARGS) == 0
        
        test_file = joinpath(INSTANCE_DIR, "S_10_2_1.jld2")
        println("测试单个实例: $test_file")
        result = main(test_file)
        println("\n结果:")
        println("  运行时间: $(round(result[1], digits=2))s")
        println("  组序列: $(result[2])")
        println("  组数 G: $(result[4])")
        println("  总成本: $(round(result[3], digits=2))")
    elseif ARGS[1] == "single"
        filenm = length(ARGS) >= 2 ? ARGS[2] : joinpath(INSTANCE_DIR, "S_10_2_1.jld2")
        num_runs = length(ARGS) >= 3 ? parse(Int, ARGS[3]) : 5
        single_instance_test(filenm; num_runs=num_runs)
    elseif ARGS[1] == "batch"
        num_runs = length(ARGS) >= 2 ? parse(Int, ARGS[2]) : 5
        batch_test(; num_runs=num_runs)
    elseif ARGS[1] == "help"
        println()
    else
        println("未知命令: $(ARGS[1])")
        println("输入 'julia PRHBF_IG_Integrated.jl help' 查看帮助")
    end
end