using JuMP
using Gurobi
using JLD2
using CSV
using DataFrames
using Dates
using XLSX
using Statistics

# Directory where this script is located
const SCRIPT_DIR = @__DIR__

# ===================================================================
# Instance data loader
# ===================================================================

# Load a .jld2 instance file
function load_instance(filepath::String)::Dict{String,Any}
    data = JLD2.load(filepath)
    return Dict(data)
end

# ===================================================================
# MILP model builder
# ===================================================================

# Build the MILP model for the DNPFSPHRC problem.
# Variables: J=jobs, W=molds, G=groups, V=vehicles
function build_milp_model(data::Dict{String,Any}; time_limit::Float64 = 1800.0, output::Bool = false)

    # --- Instance parameters ---
    J = data["JJ"]                     # Number of jobs
    W = data["WW_num"]                 # Number of molds
    G = J                              # Upper bound on number of groups
    V = J                              # Upper bound on number of vehicles

    WW_bin = data["WW"]                # Mold width
    HH_bin = data["HH"]                # Mold height

    wj = data["wj"]                    # Job widths
    hj = data["hj"]                    # Job heights
    wg = data["wg"]                    # Job weights

    pp = data["pp"]                    # Processing times (3 phases per job)
    ptr = data["ptr"]                  # Transportation time per mold

    dd = data["dd"]                    # Due dates
    betabeta = data["betabeta"]        # Tardiness penalty weights

    Q = data["Q"]                      # Vehicle capacity
    rho = data["rho"]                  # Vehicle fixed cost
    load_rate = get(data, "load_rate", 0.0)

    α = data["alpha"]                  # Mold activation cost

    # --- Big-M constants ---
    M = 10^5                           # Big-M for packing / non-overlap constraints
    M_group = 10^8                     # Big-M for group activation constraints

    # --- Set definitions ---
    jobs = 1:J
    bins = 1:W
    groups = 1:G
    vehicles = 1:V

    # --- Create model ---
    model = Model(Gurobi.Optimizer)

    # --- Gurobi solver settings ---
    set_optimizer_attribute(model, "Heuristics", 0.5)     # Heuristic solution effort
    set_optimizer_attribute(model, "MIPFocus", 2)          # Focus on bound improvement
    set_optimizer_attribute(model, "Cuts", 2)             # Moderate cut generation
    set_optimizer_attribute(model, "Presolve", 2)            # Aggressive presolve

    if !output
        set_silent(model)
    else
        set_optimizer_attribute(model, "OutputFlag", 1)
    end

    set_time_limit_sec(model, time_limit)

    # ===================================================================
    # Decision variables
    # ===================================================================

    # --- Packing / layout variables ---
    @variable(model, v[j=jobs, g=groups], Bin)          # v[j,g]=1 if job j assigned to group g
    @variable(model, o[j=jobs], Bin)                      # o[j]=1 if job j rotated 90°
    @variable(model, x[j=jobs] >= 0)                      # Lower-left x coordinate of job j
    @variable(model, y[j=jobs] >= 0)                      # Lower-left y coordinate of job j
    @variable(model, pl[i=jobs, j=jobs; i != j], Bin)    # pl[i,j]=1 if job i is left of job j
    @variable(model, pu[i=jobs, j=jobs; i != j], Bin)    # pu[i,j]=1 if job i is below job j
    @variable(model, θ[g=groups], Bin)                   # θ[g]=1 if group g is activated
    @variable(model, δ[g=groups, w=bins], Bin)            # δ[g,w]=1 if group g assigned to mold w

    # --- Scheduling variables ---
    @variable(model, c[g=groups, s=1:4] >= 0)           # Completion time of phase s for group g
    @variable(model, p[g=groups, s=1:4] >= 0)            # Processing time of phase s for group g
    @variable(model, z[g=groups, k=groups; g != k], Bin)         # z[g,k]=1 if group g precedes group k on same mold

    # --- Tardiness variables ---
    @variable(model, ct[j=jobs] >= 0)                      # Completion time of job j
    @variable(model, T[j=jobs] >= 0)                       # Tardiness of job j

    # --- Vehicle routing variables ---
    @variable(model, X[j=jobs, v=vehicles], Bin)          # X[j,v]=1 if job j assigned to vehicle v
    @variable(model, γ[v=vehicles], Bin)                   # γ[v]=1 if vehicle v is used

    # ===================================================================
    # Objective: Minimize total cost = tardiness + vehicle + mold activation
    # ===================================================================
    println("  Setting objective function...")
    @objective(model, Min,
        sum(betabeta[j] * T[j] for j in jobs) +
        sum(γ[v] * rho for v in vehicles) +
        sum(θ[g] * α for g in groups)
    )

    # ===================================================================
    # Constraints
    # ===================================================================

    # --- Mold boundary: each job must fit within the mold (with optional 90° rotation) ---
    println("  Adding mold boundary constraints...")
    for j in jobs
        @constraint(model, x[j] + (wj[j] * o[j] + hj[j] * (1 - o[j])) <= WW_bin + M * (1 - sum(v[j, g] for g in groups)))
        @constraint(model, y[j] + (hj[j] * o[j] + wj[j] * (1 - o[j])) <= HH_bin + M * (1 - sum(v[j, g] for g in groups)))
    end

    # --- Non-overlap: enforce left/right and above/below via binary indicators pl, pu ---
    println("  Adding non-overlap constraints...")
    for i in jobs, j in jobs
        if i != j
            @constraint(model, x[i] + (wj[i] * o[i] + hj[i] * (1 - o[i])) <= x[j] + M * (1 - pl[i, j]))
            @constraint(model, y[i] + (hj[i] * o[i] + wj[i] * (1 - o[i])) <= y[j] + M * (1 - pu[i, j]))
        end
    end

    # --- Relative position: at least one directional indicator must be set when two jobs share a mold ---
    println("  Adding relative position constraints...")
    for i in jobs, j in jobs, g in groups
        if i != j
            @constraint(model, pl[i, j] + pl[j, i] + pu[i, j] + pu[j, i] >= v[i, g] + v[j, g] - 1)
        end
    end

    # --- Job assignment: each job belongs to exactly one group ---
    println("  Adding job assignment constraints...")
    for j in jobs
        @constraint(model, sum(v[j, g] for g in groups) == 1)
    end

    # --- Group activation: θ[g]=1 iff at least one job assigned to group g ---
    println("  Adding group activation constraints...")
    for j in jobs, g in groups
        @constraint(model, v[j, g] <= θ[g])
    end
    for g in groups
        @constraint(model, θ[g] <= sum(v[j, g] for j in jobs))
    end

    # --- Group-to-mold: each group to exactly one mold; groups numbered monotonically ---
    println("  Adding group-to-mold assignment constraints...")
    for g in groups
        @constraint(model, sum(δ[g, w] for w in bins) == θ[g])
    end
    for g in 1:(G-1)
        @constraint(model, θ[g+1] <= θ[g])
    end

    # --- Big-M: processing/completion times are zero when group is inactive ---
    println("  Adding group activation big-M constraints...")
    for g in groups, s in 1:4
        @constraint(model, p[g, s] <= M_group * θ[g])
        @constraint(model, c[g, s] <= M_group * θ[g])
    end

    # --- Processing times per phase ---
    println("  Adding processing time constraints...")
    # Phase 1: max casting time among jobs in group
    for g in groups, j in jobs
        @constraint(model, p[g, 1] >= pp[j, 1] * v[j, g])
    end
    # Phase 2: total surface treatment time
    for g in groups
        @constraint(model, p[g, 2] >= sum(pp[j, 2] * v[j, g] for j in jobs))
    end
    # Phase 3: max curing time
    for g in groups, j in jobs
        @constraint(model, p[g, 3] >= pp[j, 3] * v[j, g])
    end
    # Phase 4: fixed transportation time
    for g in groups
        @constraint(model, p[g, 4] == ptr)
    end

    # --- Phase 1 (casting) sequencing ---
    println("  Adding Phase 1 sequencing constraints...")
    # Adjacent groups on same mold must respect casting precedence
    for g in groups, k in groups, w in bins
        if g != k
            @constraint(model, c[k, 1] >= c[g, 3] + p[k, 1] - M * (3 - δ[g, w] - δ[k, w] - z[g, k]))
            @constraint(model, c[g, 1] >= c[k, 3] + p[g, 1] - M * (3 - δ[g, w] - δ[k, w] - z[k, g]))
        end
    end
    # Minimum phase 1 start time
    for g in groups
        @constraint(model, c[g, 1] >= p[g, 1])
    end

    # --- Phase 2 (surface treatment) sequencing ---
    println("  Adding Phase 2 sequencing constraints...")
    # z[g,k]=1 iff group g precedes group k; exactly one direction per pair
    for g in groups, k in groups
        if g != k
            @constraint(model, z[g, k] + z[k, g] == 1)
        end
    end
    # Phase 2 starts after phase 1 completes
    for g in groups
        @constraint(model, c[g, 2] >= c[g, 1] + p[g, 2])
    end
    # Phase 2 respects group-to-group precedence on the shared mold
    for g in groups, k in groups
        if g != k
            @constraint(model, c[k, 2] - p[k, 2] >= c[g, 2] + M * (z[g, k] - 1))
            @constraint(model, c[g, 2] - p[g, 2] >= c[k, 2] + M * (z[k, g] - 1))
        end
    end

    # --- Phase 3 (curing) ---
    println("  Adding Phase 3 constraints...")
    for g in groups
        @constraint(model, c[g, 3] >= c[g, 2] + p[g, 3])
    end
    # Phase 4 (transportation) starts after phase 3
    for g in groups
        @constraint(model, c[g, 4] >= c[g, 3] + p[g, 4])
    end

    # --- Job completion time: group phase 3 finish + transportation ---
    println("  Adding job completion time constraints...")
    for j in jobs, g in groups
        @constraint(model, ct[j] >= (c[g, 3] + p[g, 4]) - M * (1 - v[j, g]))
        @constraint(model, ct[j] <= (c[g, 3] + p[g, 4]) + M * (1 - v[j, g]))
    end

    # --- Tardiness: T[j] = max(0, ct[j] - due_date[j]) ---
    println("  Adding tardiness constraints...")
    for j in jobs
        @constraint(model, T[j] >= ct[j] - dd[j])
    end
    for j in jobs
        @constraint(model, T[j] >= 0)
    end

    # --- Vehicle routing ---
    println("  Adding vehicle routing constraints...")
    # Each job assigned to exactly one vehicle
    for j in jobs
        @constraint(model, sum(X[j, v] for v in vehicles) == 1)
    end
    # Vehicle active iff any job assigned to it
    for j in jobs, v in vehicles
        @constraint(model, X[j, v] <= γ[v])
    end
    # Vehicle capacity
    for v in vehicles
        @constraint(model, sum(wg[j] * X[j, v] for j in jobs) <= Q * γ[v])
    end
    # Vehicles numbered monotonically (no gaps)
    for v in 2:V
        @constraint(model, γ[v] <= γ[v-1])
    end

    println("  Model built successfully!")

    return model
end

# ===================================================================
# Solve the MILP model
# ===================================================================

function solve_milp(data::Dict{String,Any}; time_limit::Float64 = 1800.0, output::Bool = false, instance_name::String = "unknown")

    println("Building model...")
    model = build_milp_model(data; time_limit=time_limit, output=output)

    println("Starting optimization...")
    start_time = time()

    println("  Variables: $(num_variables(model))")
    flush(stdout)

    optimize!(model)

    println("  Optimization finished!")
    flush(stdout)

    end_time = time()
    solve_time = end_time - start_time

    results = Dict{String,Any}()

    status = termination_status(model)
    results["status"] = status

    # Check for feasible solution
    has_feasible_solution = false
    if status == MOI.OPTIMAL || status == MOI.FEASIBLE_POINT || status == MOI.LOCALLY_SOLVED
        has_feasible_solution = has_values(model)
    elseif status == MOI.TIME_LIMIT && has_values(model)
        has_feasible_solution = true
    end

    if has_feasible_solution
        # UB = best solution found; LB = best bound
        ub = MOI.get(model, MOI.ObjectiveValue())
        lb = MOI.get(model, MOI.ObjectiveBound())

        results["objective"] = ub
        results["upper_bound"] = ub
        results["lower_bound"] = lb

        # Optimality gap
        if isfinite(lb) && abs(lb) > 1e-9
            results["gap"] = abs(ub - lb) / abs(lb) * 100
        elseif isfinite(ub) && ub == lb
            results["gap"] = 0.0
        else
            results["gap"] = Inf
        end

        results["solve_time"] = solve_time
        results["node_count"] = node_count(model)
        results["simplex_iterations"] = barrier_iterations(model)

        # Extract solution
        sol = nothing
        try
            sol = extract_solution(model, data)
        catch e
            println("  Solution extraction failed: $e")
        end

        if sol !== nothing && !haskey(sol, "error")
            results["job_to_group"] = sol["job_to_group"]
            results["active_groups"] = sol["active_groups"]
            results["rotation"] = sol["rotation"]
            results["x_coords"] = sol["x_coords"]
            results["y_coords"] = sol["y_coords"]
            results["job_completion_time"] = sol["job_completion_time"]
            results["tardiness"] = sol["tardiness"]
            results["job_to_vehicle"] = sol["job_to_vehicle"]
            results["active_vehicles"] = sol["active_vehicles"]
            results["cost"] = sol["cost"]
            results["group_jobs"] = sol["group_jobs"]
            results["vehicle_jobs"] = sol["vehicle_jobs"]

            # Vehicles used per group
            group_to_vehicle_count = Dict{Int,Int}()
            for g in results["active_groups"]
                jobs_in_g = results["group_jobs"][g]
                vehicles_used = Set{Int}()
                for j in jobs_in_g
                    push!(vehicles_used, results["job_to_vehicle"][j])
                end
                group_to_vehicle_count[g] = length(vehicles_used)
            end
            results["group_to_vehicle_count"] = group_to_vehicle_count

            # Extract group sequence from z[g,k] precedence variables
            z_var = model[:z]
            group_seq = Int[]
            remaining = Set(results["active_groups"])
            current = nothing
            max_iterations = length(remaining) * length(remaining)
            iteration_count = 0
            while !isempty(remaining)
                iteration_count += 1
                if iteration_count > max_iterations
                    append!(group_seq, sort(collect(remaining)))
                    break
                end
                if current === nothing
                    found = false
                    for g in results["active_groups"]
                        if g in remaining
                            is_first = true
                            for k in results["active_groups"]
                                if k != g && k in remaining
                                    if value(z_var[k, g]) > 0.5
                                        is_first = false
                                        break
                                    end
                                end
                            end
                            if is_first
                                current = g
                                found = true
                                break
                            end
                        end
                    end
                    if !found
                        current = first(remaining)
                    end
                end
                if current !== nothing
                    push!(group_seq, current)
                    delete!(remaining, current)
                    next_found = false
                    for g in results["active_groups"]
                        if g in remaining
                            if value(z_var[current, g]) > 0.5
                                current = g
                                next_found = true
                                break
                            end
                        end
                    end
                    if !next_found
                        current = nothing
                    end
                end
            end
            results["group_sequence"] = group_seq

            results["avg_group_utilization"] = sol["avg_group_utilization"]
            results["tardy_job_count"] = sol["tardy_job_count"]

            # Save XLSX solution file
            try
                xlsx_dir = joinpath(SCRIPT_DIR, "MILP_Results", "xlsx")
                mkpath(xlsx_dir)
                instance_safe = replace(instance_name, r"[<>:\"/\\|?*]" => "_")
                xlsx_path = joinpath(xlsx_dir, "$(instance_safe)_solution.xlsx")
                save_solution_to_xlsx(model, data, xlsx_path, results)
                results["xlsx_path"] = xlsx_path
            catch e
                println("  XLSX save failed: $e")
            end

        else
            println("  Solution extraction failed.")
            return model, results
        end

        println("\nSolved!")
        println("  Status: $(results["status"])")
        println("  UB: $(round(results["upper_bound"], digits=2))")
        println("  LB: $(round(results["lower_bound"], digits=2))")
        println("  Gap: $(round(results["gap"], digits=2))%")
        println("  Time: $(round(solve_time, digits=2))s")
        if haskey(results, "active_groups")
            println("  Groups G: $(length(results["active_groups"]))")
            println("  Vehicles: $(length(get(results, "active_vehicles", Int[])))")
            println("  Avg utilization (%): $(round(get(results, "avg_group_utilization", 0.0), digits=2))")
            cost_dict = get(results, "cost", Dict())
            println("  Tardiness cost: $(round(get(cost_dict, "tardiness_cost", 0.0), digits=2))")
            println("  Tardy jobs: $(get(results, "tardy_job_count", 0))")
        end
    else
        println("  Warning: no feasible solution, status: $status")
        results["status"] = string(status)
        results["objective"] = Inf
        results["upper_bound"] = Inf
        results["lower_bound"] = Inf
        results["gap"] = Inf
        results["solve_time"] = solve_time
        results["node_count"] = get(results, "node_count", 0)
        results["simplex_iterations"] = get(results, "simplex_iterations", 0)
    end

    return model, results
end

# ===================================================================
# Extract solution values from the optimized model
# ===================================================================

function extract_solution(model::Model, data::Dict{String,Any})

    try
        J = data["JJ"]; W = data["WW_num"]; G = data["GG"]; V = data["VV"]
        jobs = 1:J; bins = 1:W; groups = 1:G; vehicles = 1:V
        wj = data["wj"]; hj = data["hj"]; wg = data["wg"]

        result = Dict{String,Any}()

        # Job -> group assignment
        job_to_group = Int[]
        v_var = model[:v]
        for j in jobs
            best_g = 0; best_val = 0.0
            for g in groups
                val = value(v_var[j, g])
                if val > best_val; best_val = val; best_g = g; end
            end
            push!(job_to_group, best_g)
        end
        result["job_to_group"] = job_to_group

        # Active groups and their mold assignments
        active_groups = Int[]
        group_to_bin = Int[]
        θ_var = model[:θ]; δ_var = model[:δ]
        for g in groups
            if value(θ_var[g]) > 0.5
                push!(active_groups, g)
                for w in bins
                    if value(δ_var[g, w]) > 0.5; push!(group_to_bin, w); break; end
                end
            end
        end
        result["active_groups"] = active_groups
        result["group_to_bin"] = group_to_bin

        # Rotation decisions
        o_var = model[:o]
        result["rotation"] = [round(Int, value(o_var[j])) for j in jobs]

        # Coordinates
        x_var = model[:x]; y_var = model[:y]
        result["x_coords"] = [value(x_var[j]) for j in jobs]
        result["y_coords"] = [value(y_var[j]) for j in jobs]

        # Group -> jobs mapping
        group_jobs = Dict{Int,Vector{Int}}()
        for g in active_groups
            group_jobs[g] = Int[j for j in jobs if job_to_group[j] == g]
        end
        result["group_jobs"] = group_jobs

        # Mold -> jobs mapping
        bin_jobs = Dict{Int,Vector{Int}}()
        for w in bins; bin_jobs[w] = Int[]; end
        for (idx, g) in enumerate(active_groups)
            w = group_to_bin[idx]
            for j in group_jobs[g]; push!(bin_jobs[w], j); end
        end
        result["bin_jobs"] = bin_jobs

        # Completion times and tardiness
        c_var = model[:c]; p_var = model[:p]; ct_var = model[:ct]; T_var = model[:T]
        result["completion_time"] = Dict{Int,Dict{Int,Float64}}()
        result["phase_time"] = Dict{Int,Dict{Int,Float64}}()
        for g in groups
            result["completion_time"][g] = Dict{Int,Float64}()
            result["phase_time"][g] = Dict{Int,Float64}()
            for s in 1:4; result["completion_time"][g][s] = value(c_var[g, s]); end
            for s in 1:3; result["phase_time"][g][s] = value(p_var[g, s]); end
        end
        result["job_completion_time"] = [value(ct_var[j]) for j in jobs]
        result["tardiness"] = [value(T_var[j]) for j in jobs]

        # Vehicle assignment
        X_var = model[:X]; γ_var = model[:γ]
        job_to_vehicle = Int[]
        for j in jobs
            push!(job_to_vehicle, 0)
            for v in vehicles
                if value(X_var[j, v]) > 0.5; job_to_vehicle[end] = v; break; end
            end
        end
        result["job_to_vehicle"] = job_to_vehicle

        active_vehicles = Int[]
        vehicle_jobs = Dict{Int,Vector{Int}}()
        for v in vehicles
            if value(γ_var[v]) > 0.5
                push!(active_vehicles, v)
                vehicle_jobs[v] = Int[j for j in jobs if job_to_vehicle[j] == v]
            else
                vehicle_jobs[v] = Int[]
            end
        end
        result["active_vehicles"] = active_vehicles
        result["vehicle_jobs"] = vehicle_jobs

        # Cost breakdown
        tard_val = [value(T_var[j]) for j in jobs]
        tard_sum = sum(data["betabeta"][j] * tard_val[j] for j in jobs if !isnan(tard_val[j]))
        tardiness_cost = isnan(tard_sum) ? 0.0 : tard_sum
        vehicle_sum = sum(value(γ_var[v]) * data["rho"] for v in vehicles)
        vehicle_cost = isnan(vehicle_sum) ? 0.0 : vehicle_sum
        mold_sum = sum(value(θ_var[g]) * data["alpha"] for g in groups)
        mold_cost = isnan(mold_sum) ? 0.0 : mold_sum
        total_cost = tardiness_cost + vehicle_cost + mold_cost
        result["cost"] = Dict(
            "tardiness_cost" => tardiness_cost,
            "vehicle_fixed_cost" => vehicle_cost,
            "mold_activation_cost" => mold_cost,
            "total_cost" => total_cost
        )

        # Group utilization (area usage)
        WW_bin = data["WW"]; HH_bin = data["HH"]
        group_utilizations = Float64[]
        for g in active_groups
            jobs_in_g = get(group_jobs, g, Int[])
            isempty(jobs_in_g) && continue
            bin_area = WW_bin * HH_bin
            used_area = sum(
                (result["rotation"][j] == 1 ? hj[j] : wj[j]) *
                (result["rotation"][j] == 1 ? wj[j] : hj[j])
                for j in jobs_in_g
            )
            push!(group_utilizations, used_area / bin_area * 100)
        end
        avg_group_utilization = isempty(group_utilizations) ? 0.0 : mean(group_utilizations)

        tardy_job_count = count(v -> v > 1e-6, tard_val)

        result["avg_group_utilization"] = avg_group_utilization
        result["tardy_job_count"] = tardy_job_count

        return result
    catch e
        return Dict("error" => string(e))
    end
end

# ===================================================================
# Save solution to XLSX file
# ===================================================================

function save_solution_to_xlsx(model::Model, data::Dict{String,Any}, output_path::String, results::Dict{String,Any})

    J = data["JJ"]; W = data["WW_num"]; G = data["GG"]; V = data["VV"]
    jobs = 1:J; bins = 1:W; groups = 1:G; vehicles = 1:V
    wj = data["wj"]; hj = data["hj"]; wg = data["wg"]
    pp = data["pp"]; dd = data["dd"]; betabeta = data["betabeta"]
    WW_bin = data["WW"]; HH_bin = data["HH"]
    ptr = data["ptr"]; rho = data["rho"]
    α = data["alpha"]

    sol = extract_solution(model, data)
    job_to_group = sol["job_to_group"]
    active_groups = sol["active_groups"]
    group_to_bin = sol["group_to_bin"]
    group_jobs = sol["group_jobs"]
    bin_jobs = sol["bin_jobs"]
    rotation = sol["rotation"]
    x_coords = sol["x_coords"]
    y_coords = sol["y_coords"]
    job_to_vehicle = sol["job_to_vehicle"]
    active_vehicles = sol["active_vehicles"]
    cost = sol["cost"]

    mkpath(dirname(output_path))

    # Sheet 1: Job summary
    sheet1_headers = ["Job ID", "Width", "Height", "Weight",
                      "Rotated(0=no,1=yes)", "Group", "Mold",
                      "Due Date", "Penalty", "Completion Time", "Tardiness"]
    sheet1_rows = Any[]
    for j in jobs
        g = job_to_group[j]
        bin_w = "-"
        if g in active_groups
            idx_g = findfirst(==(g), active_groups)
            if idx_g !== nothing && idx_g <= length(group_to_bin)
                bin_w = group_to_bin[idx_g]
            end
        end
        push!(sheet1_rows, Any[
            j, wj[j], hj[j], wg[j], rotation[j], g, bin_w,
            round(dd[j], digits=2), betabeta[j],
            round(sol["job_completion_time"][j], digits=2),
            round(sol["tardiness"][j], digits=2)
        ])
    end

    # Sheet 2: Mold layout
    sheet2_headers = ["Mold ID", "Mold Width", "Mold Height", "Job ID",
                      "Orig Width", "Orig Height", "Rot Width", "Rot Height",
                      "X", "Y", "Group ID"]
    sheet2_rows = Any[]
    for b in bins
        if haskey(bin_jobs, b) && !isempty(bin_jobs[b])
            for j in bin_jobs[b]
                rot = rotation[j]
                w_rot = rot == 1 ? hj[j] : wj[j]
                h_rot = rot == 1 ? wj[j] : hj[j]
                push!(sheet2_rows, Any[
                    b, WW_bin, HH_bin, j, wj[j], hj[j], w_rot, h_rot,
                    round(x_coords[j], digits=2), round(y_coords[j], digits=2),
                    job_to_group[j]
                ])
            end
        end
    end

    # Sheet 3: Vehicle routing
    sheet3_headers = ["Vehicle ID", "Capacity", "Fixed Cost",
                      "Used(0=no,1=yes)", "Load",
                      "Group ID", "Mold ID", "Jobs"]
    sheet3_rows = Any[]
    for (idx, g) in enumerate(active_groups)
        isempty(group_jobs[g]) && continue
        v_of_g = job_to_vehicle[group_jobs[g][1]]
        w_of_g = group_to_bin[idx]
        jobs_in_g = group_jobs[g]
        wg_sum = sum(wg[j] for j in jobs_in_g)
        push!(sheet3_rows, Any[
            v_of_g, data["Q"], rho, 1, round(wg_sum, digits=2),
            g, w_of_g, join(jobs_in_g, ",")
        ])
    end

    # Sheet 4: Group schedule (Gantt data)
    sheet4_headers = ["Group ID", "Mold", "Jobs", "Job Count",
                      "Ph1 Start", "Ph1 End", "Ph1 Dur",
                      "Ph2 Start", "Ph2 End", "Ph2 Dur",
                      "Ph3 Start", "Ph3 End", "Ph3 Dur",
                      "Ph4 Start", "Ph4 End", "Ph4 Dur"]
    sheet4_rows = Any[]
    for (idx, g) in enumerate(active_groups)
        if !haskey(sol["completion_time"], g)
            continue
        end
        c_times = sol["completion_time"][g]
        phase_t = sol["phase_time"][g]
        gbin = group_to_bin[idx]

        s1 = get(c_times, 1, 0.0) - get(phase_t, 1, 0.0)
        s2 = get(c_times, 2, 0.0) - get(phase_t, 2, 0.0)
        s3 = get(c_times, 3, 0.0) - get(phase_t, 3, 0.0)
        s4 = get(c_times, 4, 0.0) - ptr
        push!(sheet4_rows, Any[
            g, gbin, join(get(group_jobs, g, Int[]), ","), length(get(group_jobs, g, Int[])),
            round(s1, digits=2),
            round(get(c_times, 1, 0.0), digits=2),
            round(get(phase_t, 1, 0.0), digits=2),
            round(s2, digits=2),
            round(get(c_times, 2, 0.0), digits=2),
            round(get(phase_t, 2, 0.0), digits=2),
            round(s3, digits=2),
            round(get(c_times, 3, 0.0), digits=2),
            round(get(phase_t, 3, 0.0), digits=2),
            round(s4, digits=2),
            round(get(c_times, 4, 0.0), digits=2),
            ptr
        ])
    end

    # Sheet 5: Cost summary
    tard_cost = cost["tardiness_cost"]
    veh_cost = cost["vehicle_fixed_cost"]
    mold_cost = cost["mold_activation_cost"]
    total_cost = cost["total_cost"]
    sheet5_rows = Any[
        ["Tardiness Cost", (isnothing(tard_cost) ? "N/A" : round(tard_cost, digits=2)), "Currency", "Sum of β_j × T_j"],
        ["Vehicle Fixed Cost", (isnothing(veh_cost) ? "N/A" : round(veh_cost, digits=2)), "Per Vehicle", "Used vehicles × ρ"],
        ["Mold Activation Cost", (isnothing(mold_cost) ? "N/A" : round(mold_cost, digits=2)), "Per Mold", "Used molds × α"],
        ["Total Cost", (isnothing(total_cost) ? "N/A" : round(total_cost, digits=2)), "Currency", "Tardiness + Vehicle + Mold"],
        ["Number of Molds Used", length(active_groups), "Count", ""],
        ["Number of Vehicles Used", length(active_vehicles), "Count", ""],
        ["Tardy Jobs", count(>(0), sol["tardiness"]), "Count", ""],
        ["Total Tardiness", round(sum(sol["tardiness"]), digits=2), "Time Units", ""],
    ]

    # Sheet 6: Instance info and solver statistics
    sheet6_rows = Any[
        ["Number of Jobs J", J],
        ["Number of Molds W", W],
        ["Job Width Range", "$(minimum(wj))~$(maximum(wj))"],
        ["Job Height Range", "$(minimum(hj))~$(maximum(hj))"],
        ["Mold Size", "$(WW_bin) × $(HH_bin)"],
        ["Mold Activation Cost α", α],
        ["Vehicle Fixed Cost ρ", rho],
        ["Vehicle Capacity Q", data["Q"]],
        ["Transportation Time ptr", ptr],
        ["Due Date Range", "$(round(minimum(dd),digits=2))~$(round(maximum(dd),digits=2))"],
        ["Penalty Range", "$(round(minimum(betabeta),digits=2))~$(round(maximum(betabeta),digits=2))"],
        ["Solver Status", string(termination_status(model))],
        ["Upper Bound (UB)", results["upper_bound"]],
        ["Lower Bound (LB)", results["lower_bound"]],
        ["Gap (%)", round(results["gap"], digits=4)],
        ["Solve Time (s)", round(results["solve_time"], digits=2)],
        ["Tardy Job Count", count(>(0), sol["tardiness"])],
    ]

    # Write all sheets
    mkpath(dirname(output_path))
    XLSX.openxlsx(output_path, mode="w") do xf
        for (sheetname, headers, rows) in [
            ("Grouping",       sheet1_headers, sheet1_rows),
            ("Mold Layout",    sheet2_headers, sheet2_rows),
            ("Vehicle Routing", sheet3_headers, sheet3_rows),
            ("Schedule Gantt", sheet4_headers, sheet4_rows),
            ("Cost Breakdown", sheet5_headers, sheet5_rows),
            ("Solver Info",    sheet6_headers, sheet6_rows),
        ]
            sheet = XLSX.addsheet!(xf, sheetname)
            for (col_idx, h) in enumerate(headers)
                sheet[1, col_idx] = h
            end
            for (row_idx, row_data) in enumerate(rows)
                for (col_idx, val) in enumerate(row_data)
                    sheet[row_idx + 1, col_idx] = val
                end
            end
        end
    end
end

# ===================================================================
# Batch solve multiple instances
# ===================================================================

# Determine time limit based on instance name prefix (S/M/L)
function get_time_limit_by_instance(filename::String)::Float64
    fname = splitext(last(splitdir(filename)))[1]
    if startswith(fname, "S_")
        return 600.0    # Small: 10 min
    elseif startswith(fname, "M_")
        return 1000.0   # Medium: ~17 min
    elseif startswith(fname, "L_")
        return 1800.0   # Large: 30 min
    else
        return 1800.0
    end
end

# Append results of a single instance to CSV
function save_results(results::Dict{String,Any}, instance_name::String, output_path::String)

    active_groups_count = length(get(results, "active_groups", Int[]))
    active_vehicles_count = length(get(results, "active_vehicles", Int[]))

    cost_dict = get(results, "cost", Dict{String,Any}())
    tardiness_cost = get(cost_dict, "tardiness_cost", 0.0)
    vehicle_cost = get(cost_dict, "vehicle_fixed_cost", 0.0)
    mold_cost = get(cost_dict, "mold_activation_cost", 0.0)

    group_jobs = get(results, "group_jobs", Dict{Int,Vector{Int}}())
    jobs_per_group = join(["$g:$(length(get(group_jobs, g, Int[])))" for g in sort(collect(keys(group_jobs)))], ";")

    group_to_vehicle_count = get(results, "group_to_vehicle_count", Dict{Int,Int}())
    vehicles_per_group = join(["$g:$(get(group_to_vehicle_count, g, 0))" for g in sort(collect(keys(group_to_vehicle_count)))], ";")

    group_sequence = get(results, "group_sequence", Int[])
    group_seq_str = join(group_sequence, "->")

    df = DataFrame(
        instance = [instance_name],
        status = [string(results["status"])],
        objective = [results["objective"]],
        upper_bound = [results["upper_bound"]],
        lower_bound = [results["lower_bound"]],
        gap = [results["gap"]],
        solve_time = [results["solve_time"]],
        node_count = [get(results, "node_count", 0)],
        group_count = [active_groups_count],
        vehicle_count = [active_vehicles_count],
        avg_group_utilization = [round(get(results, "avg_group_utilization", 0.0), digits=2)],
        tardiness_cost = [tardiness_cost],
        tardy_job_count = [get(results, "tardy_job_count", 0)],
        jobs_per_group = [jobs_per_group],
        vehicles_per_group = [vehicles_per_group],
        group_sequence = [group_seq_str],
        vehicle_cost = [vehicle_cost],
        mold_cost = [mold_cost],
        timestamp = [Dates.format(now(), "yyyy-mm-dd HH:MM:SS")]
    )

    if isfile(output_path)
        existing_df = CSV.read(output_path, DataFrame)
        df = vcat(existing_df, df)
    end

    CSV.write(output_path, df)
    println("  Results saved to: $output_path")
end

# Batch solve all .jld2 instances in a directory
function batch_solve(data_dir::String; time_limit::Float64 = 1800.0, output_dir::String = joinpath(SCRIPT_DIR, "MILP_Results"), output::Bool = false, only_small::Bool = false)

    mkpath(output_dir)

    if !isabspath(data_dir)
        data_dir = joinpath(SCRIPT_DIR, data_dir)
    end

    if !isdir(data_dir)
        println("Error: directory not found: $data_dir")
        return
    end

    instance_files = filter(f -> endswith(f, ".jld2"), readdir(data_dir, join=true))

    if isempty(instance_files)
        println("No .jld2 instance files found in $data_dir")
        return
    end

    instance_files = unique(instance_files)

    # Parse instance size from filename (e.g., S_10_2_1, M_20_4_3)
    function parse_instance_size(filename)
        fname = splitext(last(splitdir(filename)))[1]
        m = match(r"[SML]_(\d+)_(\d+)_(\d+)", fname)
        if m !== nothing
            J = parse(Int, m.captures[1]); W = parse(Int, m.captures[2]); idx = parse(Int, m.captures[3])
            prefix = fname[1]
            return (J, W, idx, fname, prefix)
        end
        m = match(r"I_(\d+)_(\d+)_(\d+)", fname)
        if m !== nothing
            J = parse(Int, m.captures[1]); W = parse(Int, m.captures[2]); idx = parse(Int, m.captures[3])
            return (J, W, idx, fname, 'I')
        end
        return (999, 999, 0, fname, '?')
    end

    parsed = [parse_instance_size(f) for f in instance_files]

    if only_small
        instance_files = [f for (f, p) in zip(instance_files, parsed) if p[5] == 'S']
        parsed = filter(p -> p[5] == 'S', parsed)
    end

    # Sort by size (small to large)
    sorted_indices = sortperm(parsed, by=x->(x[1], x[2], x[3]))
    instance_files = instance_files[sorted_indices]
    parsed = parsed[sorted_indices]

    sizes = unique([(p[1], p[2], string(p[5])) for p in parsed])
    sort!(sizes, by=x->(x[3], x[1], x[2]))
    println("Found $(length(instance_files)) instance files:")
    for (J, W, prefix) in sizes
        count = sum(1 for p in parsed if p[1]==J && p[2]==W && string(p[5])==prefix)
        println("  $(prefix)_$(J)_$(W): $count instances")
    end
    println("Solving order: small → large")
    println("=" ^ 70)

    timestamp = Dates.format(Dates.now(), "yyyy-mm-dd_HH-MM-SS")
    results_file = joinpath(output_dir, "milp_results_$timestamp.csv")

    all_results = []

    for (i, filepath) in enumerate(instance_files)
        instance_name = splitext(last(splitdir(filepath)))[1]
        instance_time_limit = get_time_limit_by_instance(instance_name)
        println("\n[$i/$(length(instance_files))] Solving $instance_name (time limit: $(Int(instance_time_limit))s)")

        try
            data = load_instance(filepath)
            model, results = solve_milp(data; time_limit=instance_time_limit, output=output, instance_name=instance_name)
            results["instance"] = instance_name
            push!(all_results, results)
            save_results(results, instance_name, results_file)
        catch e
            println("  Error: $e")
            push!(all_results, Dict(
                "instance" => instance_name,
                "status" => "ERROR", "objective" => Inf, "upper_bound" => Inf,
                "lower_bound" => Inf, "gap" => Inf, "solve_time" => 0.0,
                "node_count" => 0, "simplex_iterations" => 0,
                "active_groups" => Int[], "active_vehicles" => Int[],
                "group_sequence" => Int[], "group_jobs" => Dict{Int,Vector{Int}}(),
                "vehicle_jobs" => Dict{Int,Vector{Int}}(),
                "group_to_vehicle_count" => Dict{Int,Int}(),
                "avg_group_utilization" => 0.0, "tardy_job_count" => 0
            ))
        end
    end

    df = DataFrame(all_results)
    summary_file = joinpath(output_dir, "milp_summary_$timestamp.csv")
    CSV.write(summary_file, df)

    println("\n" * "=" ^ 70)
    println("Batch solve complete!")
    println("  Total instances: $(length(instance_files))")
    println("  Results file: $results_file")
    println("  Summary file: $summary_file")
    println("=" ^ 70)
end

# ===================================================================
# Entry point
# ===================================================================
if abspath(PROGRAM_FILE) == @__FILE__
    println("\nStarting batch solve...")
    println("Solving all instances in DATA_Instances directory.")
    println("Time limits: S_=600s, M_=1000s, L_=1800s")
    data_dir = joinpath(SCRIPT_DIR, "DATA_Instances")
    batch_solve(data_dir; time_limit=1800.0, output_dir=joinpath(SCRIPT_DIR, "MILP_Results"), output=true, only_small=false)
end
