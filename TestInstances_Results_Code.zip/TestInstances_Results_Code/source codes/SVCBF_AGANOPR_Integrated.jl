"""

BF_AGANOPR_Integrated.jl

BF-AGA算法 (无扰动重启) - 完全集成版本

将所有子程序整合到一个文件中，无需外部include



主要特点:

- 调度算法: GA + VNS (遗传算法)

- 运输求解: CPLEX

- 无扰动重启机制

"""



using JLD2, HDF5, LinearAlgebra, Plots, Statistics, DataFrames, Random

using JuMP, JLD, StatsBase, CSV, Dates, CPUTime

using Gurobi



# ============================================================

# CPLEX 环境设置

# ============================================================

ENV["CPLEX_LICENSE_DEBUG"] = "0"



# ============================================================

# SVC 全局参数注册（运行时由 main 设置）

# ============================================================

const WW_HH_global = Ref(0)

const w_global     = Ref(Vector{Int}())

const h_global     = Ref(Vector{Int}())



function set_svc_globals(WW_val::Int, HH_val::Int, w_val::Vector{Int}, h_val::Vector{Int})

    WW_HH_global[] = WW_val * HH_val

    w_global[] = w_val

    h_global[] = h_val

end



# ============================================================

# SVC 伪价格初始化

# ============================================================

function init_lambda_vec(J::Int, d, w::Vector{Int}, h::Vector{Int};

                            WW::Int=0, HH::Int=0)

    """

    参考 Arbib et al. (2020) 论文公式 (4) 初始化伪价格:

        p_i := W*H / (d_i + 1) + w_i * h_i

    促进紧迫工件（大 d 小 → 大伪价格）和大面积工件优先装箱

    """

    WW_HH = WW * HH

    lambda_vec = zeros(Float64, J)

    for i in 1:J

        di_safe = max(d[i], 1e-6)

        lambda_vec[i] = WW_HH / (di_safe + 1.0) + w[i] * h[i]

    end

    return lambda_vec

end



# ============================================================

# SVC 伪价格更新

# ============================================================

function update_lambda_vec!(lambda_vec::Vector{Float64},

                               v_result::Vector{Vector{Int}},

                               p::Matrix{Float64},

                               J::Int, G::Int,

                               nLB::Int, tau::Float64,

                               d,

                               wg::Vector{Int}, hg::Vector{Int},

                               delta::Float64;

                               WW::Int=0, HH::Int=0)

    """

    参考 Arbib et al. (2020) 论文公式 (5)(6) 更新伪价格



    公式 (5): 对所有工件 i

        p_i := p_i * (1 + δ * nLB / J)^( (ω(i) - ω̄) / (J * WW * HH) )

    其中:

        ω(i)  = 当前 bin 中工件 i 的剩余空间（由 v_result 反推）

        ω̄     = 整体相对残差下界 = WW*HH*nLB - sum(w_i*h_i) / nLB



    公式 (6): 对 tardiest 工件 h 额外增加延迟惩罚

        p_h := p_h * (1 + (1 + δ * LB / (τ * nLB)) * [(C_h - LB)/τ / (d_h + 1)])

    """

    WW_HH = WW * HH



    # 计算 ω̄（整体残差下界）

    total_area = 0.0

    for i in 1:J

        total_area += wg[i] * hg[i]

    end

    omega_bar = (WW_HH * nLB - total_area) / nLB



    # 从 v_result 重建 bin -> jobs 映射，计算每个 bin 的残差空间 ω(i)

    bin_jobs = Dict{Int, Vector{Int}}()

    for pair in v_result

        job_id = pair[1]

        group_id = pair[2]

        if !haskey(bin_jobs, group_id)

            bin_jobs[group_id] = Int[]

        end

        push!(bin_jobs[group_id], job_id)

    end



    # 计算每个工件的 bin 残差空间 ω(i)

    job_to_bin_residual = zeros(Float64, J)

    for (bin_id, jobs) in bin_jobs

        used_area = 0.0

        for j in jobs

            used_area += wg[j] * hg[j]

        end

        residual = max(WW_HH - used_area, 0.0)

        for j in jobs

            job_to_bin_residual[j] = residual

        end

    end



    # 公式 (5): 对所有工件更新

    factor_base = 1.0 + delta * nLB / J

    for i in 1:J

        omega_i = job_to_bin_residual[i]

        exponent = (omega_i - omega_bar) / (J * WW_HH)

        lambda_vec[i] *= (factor_base ^ exponent)

    end



    # 公式 (6): 对 tardiest 工件额外增加惩罚

    if G > 0 && !isempty(p)

        tardiest_job = 0

        max_ct = -Inf

        for pair in v_result

            job_id = pair[1]

            group_id = pair[2]

            if group_id <= size(p, 1)

                ct = p[group_id, 1] + p[group_id, 2] + p[group_id, 3] + p[group_id, 4]

                if ct > max_ct

                    max_ct = ct

                    tardiest_job = job_id

                end

            end

        end



        if tardiest_job > 0

            LB = tau * nLB

            C_h = max_ct

            d_h = max(d[tardiest_job], 1e-6)

            lateness = max(C_h - d_h, 0.0)

            extra_factor = 1.0 + (1.0 + delta * LB / (tau * nLB)) *

                                 (lateness / tau) / (d_h + 1.0)

            lambda_vec[tardiest_job] *= extra_factor

        end

    end



    # 防止伪价格过小/过大

    for i in 1:J

        if lambda_vec[i] < 1e-8

            lambda_vec[i] = 1e-8

        end

        if lambda_vec[i] > 1e12

            lambda_vec[i] = 1e12

        end

    end



    return lambda_vec

end



# ============================================================

# 用伪价格排序生成装箱序列

# ============================================================

function sort_by_lambda_vec(lambda_vec::Vector{Float64})

    """

    按伪价格降序排列工件，伪价格高 → 优先装箱（大面积/紧迫）

    返回 Vector{Int}：原始工件索引（1-based），按伪价格从高到低

    """

    return sortperm(lambda_vec, rev=true)

end



# ============================================================

# 读取调参得到的最优参数

# ============================================================

const SCRIPT_DIR = @__DIR__

const TUNING_DIR = joinpath(SCRIPT_DIR, "..", "tuning_irace", "R", "results")



function load_tuning_params()

    try

        params_aga = CSV.File(joinpath(TUNING_DIR, "PRHBF_AGA", "best_params_PRHBF_AGA.csv")) |> first

        return (

            max_iteration = params_aga.max_iteration,

            pop_size = params_aga.pop_size,

            pc = params_aga.pc,

            pm = params_aga.pm

        )

    catch e

        @warn "无法读取调参参数文件，使用默认参数: $e"

        return (

            max_iteration = 59,

            pop_size = 4,

            pc = 0.2164,

            pm = 0.8558

        )

    end

end



const params_aga = load_tuning_params()

const maxIter_tuning = params_aga.max_iteration

const popSize_tuning = params_aga.pop_size

const pc_tuning = params_aga.pc

const pm_tuning = params_aga.pm



# ============================================================

# 数据结构 - SkylineBF.jl

# ============================================================

mutable struct SkylineSegment

    x::Int; width::Int; height::Int

end



mutable struct RectangleItem

    index::Int; width::Int; height::Int; rotated::Bool

end



mutable struct PackingItem

    id::Int; width::Int; height::Int

end



mutable struct PackingBin

    width::Int; height::Int

    items::Vector{Tuple{PackingItem,Tuple{Int,Int}}}

    remaining_width::Int; remaining_height::Int

end



PackingBin(width::Int, height::Int) = PackingBin(width, height, [], width, height)



function can_place(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int})

    x, y = position

    x + item.width <= bin.width && y + item.height <= bin.height || return false

    for (pi, pp) in bin.items

        px, py = pp

        x < px + pi.width && x + item.width > px &&

        y < py + pi.height && y + item.height > py && return false

    end

    true

end



place_item!(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int}) =

    push!(bin.items, (item, position))



function find_position_skyline(bin::PackingBin, item::PackingItem)

    for y in 0:(bin.height - item.height)

        for x in 0:(bin.width - item.width)

            can_place(bin, item, (x, y)) && return (x, y)

        end

    end

    nothing

end



# ============================================================

# Skyline 辅助函数

# ============================================================

function merge_adjacent_segments(segments::Vector{SkylineSegment})

    isempty(segments) && return segments

    merged = SkylineSegment[]; current = segments[1]

    for i in 2:length(segments)

        if segments[i].height == current.height

            current = SkylineSegment(current.x, current.width + segments[i].width, current.height)

        else

            push!(merged, current); current = segments[i]

        end

    end

    push!(merged, current); merged

end



function place_rectangle_on_skyline(

    segments::Vector{SkylineSegment}, item_w::Int, item_h::Int, x_pos::Int)

    new_segments = SkylineSegment[]

    cur_x = 0; seg_idx = 0

    for (i, seg) in enumerate(segments)

        if x_pos >= cur_x && x_pos < cur_x + seg.width

            seg_idx = i; break

        end

        cur_x += seg.width

    end

    seg_idx == 0 && (seg_idx = length(segments))

    left_w = x_pos - cur_x

    right_w = segments[seg_idx].width - left_w - item_w

    for i in 1:(seg_idx-1); push!(new_segments, segments[i]); end

    if left_w > 0

        push!(new_segments, SkylineSegment(segments[seg_idx].x, left_w, segments[seg_idx].height))

    end

    push!(new_segments, SkylineSegment(x_pos, item_w, segments[seg_idx].height + item_h))

    if right_w > 0

        push!(new_segments, SkylineSegment(x_pos + item_w, right_w, segments[seg_idx].height))

    end

    for i in (seg_idx+1):length(segments); push!(new_segments, segments[i]); end

    merge_adjacent_segments(new_segments)

end



# ============================================================

# BFP 算法 - 基于论文的修正版本

# ============================================================

function bfp_packing(Item, ran, pallet_width, pallet_height)

    itemNum = size(Item, 1)

    ansBXY = zeros(Int, itemNum, 6)

    result = zeros(Int, itemNum, 2)

    rotated = zeros(Int, itemNum)

    placed = Vector{Tuple{Int,Int,Int,Int,Int,Int}}()



    R = RectangleItem[]

    for i in ran

        w, h = Item[i,1], Item[i,2]; rf = false

        if h > w; w, h = h, w; rf = true; end

        push!(R, RectangleItem(i, w, h, rf))

    end



    bin_num = 0

    pallet_area = pallet_width * pallet_height



    while !isempty(R)

        bin_num += 1

        skyline = [SkylineSegment(0, pallet_width, 0)]



        L = RectangleItem[]

        total_area = 0

        idx = 1

        while idx <= length(R) && total_area < pallet_area

            total_area += R[idx].width * R[idx].height

            push!(L, R[idx])

            idx += 1

        end



        for r in L

            if r.height > r.width

                r.width, r.height = r.height, r.width

                r.rotated = !r.rotated

            end

        end

        sort!(L, by=r -> (-r.width, -r.height))



        for r in L

            rmi = findfirst(x -> x.index == r.index, R)

            if rmi !== nothing

                deleteat!(R, rmi)

            end

        end



        while !isempty(L)

            min_seg_idx = 0

            min_seg_h = typemax(Int)

            for (i, seg) in enumerate(skyline)

                if seg.height < min_seg_h

                    min_seg_h = seg.height

                    min_seg_idx = i

                end

            end



            seg = skyline[min_seg_idx]

            gap_h = seg.height

            gap_x = seg.x

            avail_w = seg.width

            avail_h = pallet_height - gap_h



            sky_dif = pallet_height - min_seg_h



            hwmin = minimum(min(r.height, r.width) for r in L)



            if sky_dif < hwmin

                reverse!(L)

                for r in L

                    insert!(R, 1, r)

                end

                break

            end



            best_rect = nothing

            best_idx = 0

            best_score = -1



            for (idx, r) in enumerate(L)

                if r.width <= avail_w && r.height <= avail_h

                    score = r.width * r.height

                    if score > best_score

                        best_score = score

                        best_rect = r

                        best_idx = idx

                    end

                end

            end



            if best_rect !== nothing

                push!(placed, (best_rect.index, gap_x, gap_h,

                    best_rect.width, best_rect.height,

                    best_rect.rotated ? 1 : 0))

                ansBXY[best_rect.index, :] =

                    [bin_num, best_rect.index, best_rect.width,

                     best_rect.height, gap_x, gap_h]

                rotated[best_rect.index] = best_rect.rotated ? 1 : 0

                result[best_rect.index, :] = [best_rect.index, bin_num]



                deleteat!(L, best_idx)



                skyline = place_rectangle_on_skyline(skyline,

                    best_rect.width, best_rect.height, gap_x)

            else

                if avail_w > 0 && avail_h > 0

                    skyline = place_rectangle_on_skyline(skyline, avail_w, avail_h, gap_x)

                end

            end

        end

    end



    boxes_dict = Dict{Int,Vector{Any}}()

    for b in 1:bin_num; boxes_dict[b] = []; end

    for i in 1:itemNum

        b = ansBXY[i,1]

        if b > 0; push!(boxes_dict[b], (Item[result[i,1],:], ran[i])); end

    end



    bin_of = [ansBXY[i,1] for i in 1:itemNum]

    sorted_idx = sortperm(bin_of)

    final_result = zeros(Int, itemNum, 2)

    for (pos, i) in enumerate(sorted_idx)

        final_result[pos, 1] = result[i, 1]

        final_result[pos, 2] = result[i, 2]

    end



    wasted_space = 0

    return boxes_dict, ansBXY, ran, bin_num, final_result, rotated, wasted_space

end



const skyline_bf_packing_v2 = bfp_packing



function fast_packing_algorithm(items::Vector{PackingItem}, bin_width::Int, bin_height::Int)

    items = shuffle(items)

    J = length(items)

    Item_matrix = zeros(Int, J, 2)

    for (idx, item) in enumerate(items)

        Item_matrix[idx,1] = item.width; Item_matrix[idx,2] = item.height

    end

    ran = shuffle(1:J)

    boxes_dict, ansBXY, ran_out, BinNum, result, rotated, wasted_space =

        skyline_bf_packing_v2(Item_matrix, ran, bin_width, bin_height)

    bins = PackingBin[]

    for bin_id in 1:BinNum

        bin = PackingBin(bin_width, bin_height)

        for i in 1:size(ansBXY,1)

            if ansBXY[i,1] == bin_id

                item_id = ansBXY[i,2]; w = ansBXY[i,3]; h = ansBXY[i,4]

                x = ansBXY[i,5]; y = ansBXY[i,6]

                item = PackingItem(item_id, w, h)

                place_item!(bin, item, (x, y))

            end

        end

        push!(bins, bin)

    end

    bins

end



function print_bins(bins::Vector{PackingBin})

    result = []

    for (i, bin) in enumerate(bins)

        for (item, position) in bin.items

            push!(result, [item.id, i])

        end

    end

    result

end



calculate_utilization(placed, pallet_width, pallet_height) =

    sum(p[4]*p[5] for p in placed) / (pallet_width * pallet_height)



const packing_algorithm = skyline_bf_packing_v2

const Item = PackingItem

const Bin = PackingBin



# ============================================================

# packing_with_seq.jl

# ============================================================

function packing_by_sequence_aga(items, seq, WW::Int, HH::Int)

    if isempty(seq)

        ran = shuffle(1:size(items, 1))

        return packing_algorithm(items, ran, WW, HH)

    else

        return packing_algorithm(items, seq, WW, HH)

    end

end



# ============================================================

# Makespan.jl

# ============================================================

function makespan(p, G, W, mold_to_groups, group_to_mold, sequence_chromosome, ptr_time)

    phase2_complete_global = 0.0

    phase3_finish = zeros(Float64, G)

    ct = zeros(Float64, G)



    for g in sequence_chromosome

        if g < 1 || g > G

            continue

        end



        mold = group_to_mold[g]

        mold_groups_list = mold_to_groups[mold]

        g_idx_in_mold = findfirst(==(g), mold_groups_list)



        if g_idx_in_mold == 1

            phase1_start = 0.0

        else

            prev_group = mold_groups_list[g_idx_in_mold - 1]

            phase1_start = phase3_finish[prev_group]

        end



        phase1_complete = phase1_start + p[g, 1]

        phase2_start = max(phase1_complete, phase2_complete_global)

        phase2_complete = phase2_start + p[g, 2]

        phase2_complete_global = phase2_complete

        phase3_complete = phase2_complete + p[g, 3]

        phase3_finish[g] = phase3_complete

        ct[g] = phase3_complete + ptr_time

    end



    C = zeros(Float64, W)

    for mold in 1:W

        if haskey(mold_to_groups, mold) && !isempty(mold_to_groups[mold])

            C[mold] = maximum(ct[g] for g in mold_to_groups[mold])

        end

    end



    MK = maximum(C)

    return ct, C, MK

end



# ============================================================

# TWT.jl

# ============================================================

function TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, tal_sol, v_result, ptr_time; verbose::Bool=false)

    ct, C, MK = makespan(p, G, W, mold_to_groups, group_to_mold, tal_sol, ptr_time)



    if isempty(ct) || any(isnan, ct) || any(isinf, ct)

        return Inf

    end



    ct_jobs = zeros(Int64, J)

    for pair in v_result

        job_id = pair[1]

        group_id = pair[2]

        if group_id <= length(ct)

            ct_jobs[job_id] = Int(ct[group_id])

        end

    end



    T = zeros(Int64, J)

    late_jobs = 0

    total_delay = 0

    for j in 1:J

        T[j] = ct_jobs[j] - d[j]

        if T[j] < 0

            T[j] = 0

        else

            late_jobs += 1

            total_delay += T[j]

        end

    end



    del_punish = sum(beta[j] * T[j] for j in 1:J)

    return del_punish

end



# ============================================================

# 变异操作 - mutation.jl

# ============================================================

function swap_mutation(seq_chromosome, alloc_chromosome)

    n = length(seq_chromosome)

    i, j = rand(1:n, 2)

    if i != j

        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]

        alloc_chromosome[i], alloc_chromosome[j] = alloc_chromosome[j], alloc_chromosome[i]

    end

    return seq_chromosome, alloc_chromosome

end



function swap_mutation1(seq_chromosome)

    n = length(seq_chromosome)

    i, j = rand(1:n, 2)

    if i != j

        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]

    end

    return seq_chromosome

end



function insert_mutation1(seq_chromosome)

    n = length(seq_chromosome)

    i, j = rand(1:n, 2)

    if i != j

        seq_elem = splice!(seq_chromosome, i)[1]

        insert!(seq_chromosome, j, seq_elem)

    end

    return seq_chromosome

end



function reverse_mutation1(seq_chromosome)

    n = length(seq_chromosome)

    i, j = sort(rand(1:n, 2))

    if i != j

        seq_chromosome[i:j] = reverse(seq_chromosome[i:j])

    end

    return seq_chromosome

end



# ============================================================

# VNS.jl

# ============================================================

function VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_chromosome)

    if G < 2

        TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)

        return copy(seq_chromosome), TWT_VALUE

    end



    k = 1

    TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)



    best_seq_chromosome = copy(seq_chromosome)

    new_seq_chromosome = copy(seq_chromosome)



    while k <= 3

        if k == 1

            new_seq_chromosome = swap_mutation1(copy(best_seq_chromosome))

        elseif k == 2

            new_seq_chromosome = insert_mutation1(copy(best_seq_chromosome))

        else

            new_seq_chromosome = reverse_mutation1(copy(best_seq_chromosome))

        end



        new_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_chromosome, 1, length(new_seq_chromosome)), v_result, ptr_time)



        if new_TWT < TWT_VALUE

            TWT_VALUE = new_TWT

            best_seq_chromosome = copy(new_seq_chromosome)

            k = 1

        else

            k += 1

        end

    end

    return best_seq_chromosome, TWT_VALUE

end



# ============================================================

# 精英选择 - elite.jl

# ============================================================

function select_elite(population, fitness)

    elite_ratio = 0.2

    elite_size = round(Int, elite_ratio * length(population))

    sorted_indices = sortperm(fitness, rev=true)

    elite_indices = sorted_indices[1:elite_size]

    sorted_population = population[elite_indices]

    return sorted_population, sorted_indices[1]

end



# ============================================================

# 适应度计算 - fitness.jl

# ============================================================

function calculate_fitness1(population)

    population_size = length(population)

    fitness = zeros(Float64, population_size)

    twt_value = zeros(Float64, population_size)

    for i in 1:population_size

        twt_value[i] = population[i][2]

        fitness[i] = 1 / (1 + twt_value[i])

    end

    return fitness

end



# ============================================================

# 轮盘赌选择 - selection.jl

# ============================================================

function select_one(roulette, population)

    r = rand()

    selected_index = findfirst(x -> x >= r, roulette)

    return population[selected_index]

end



function roulette_selection(population)

    n = length(population)

    num_parents = 2

    fitness = calculate_fitness1(population)

    total_fitness = sum(fitness)

    probabilities = zeros(Float64, n)

    for i in 1:n

        probabilities[i] = fitness[i] / total_fitness

    end

    roulette = cumsum(probabilities)

    parents = []

    for _ in 1:num_parents

        push!(parents, select_one(roulette, population))

    end

    return parents

end



# ============================================================

# 顺序交叉 - crossover_seq.jl

# ============================================================

function sequence_crossover(parent1, parent2)

    n = length(parent1)

    cp1 = rand(1:n)

    cp2 = rand(1:n)

    if cp1 > cp2

        cp1, cp2 = cp2, cp1

    end



    cross_section1 = parent1[cp1:cp2]

    cross_section2 = parent2[cp1:cp2]



    child1 = Int[]

    child2 = Int[]

    sorted_child1 = Int[]

    sorted_child2 = Int[]

    sorted_parent1 = Int[]

    sorted_parent2 = Int[]



    start_index = cp2 % length(parent1) + 1

    if start_index == 1

        for i in 1:cp2

            push!(sorted_parent1, parent1[i])

        end

    else

        for i in start_index:length(parent1)

            push!(sorted_parent1, parent1[i])

        end

        for i in 1:cp2

            push!(sorted_parent1, parent1[i])

        end

    end



    if start_index == 1

        for i in 1:cp2

            push!(sorted_parent2, parent2[i])

        end

    else

        for i in start_index:length(parent2)

            push!(sorted_parent2, parent2[i])

        end

        for i in 1:cp2

            push!(sorted_parent2, parent2[i])

        end

    end



    for i in 1:length(sorted_parent2)

        if !(sorted_parent2[i] in cross_section1)

            push!(sorted_child1, sorted_parent2[i])

        end

    end

    append!(sorted_child1, cross_section1)



    for i in (length(sorted_child1)-cp2+1):length(sorted_child1)

        push!(child1, sorted_child1[i])

    end

    for i in 1:(length(sorted_child1)-cp2)

        push!(child1, sorted_child1[i])

    end



    for i in 1:length(sorted_parent1)

        if !(sorted_parent1[i] in cross_section2)

            push!(sorted_child2, sorted_parent1[i])

        end

    end

    append!(sorted_child2, cross_section2)



    for i in (length(sorted_child2)-cp2+1):length(sorted_child2)

        push!(child2, sorted_child2[i])

    end

    for i in 1:(length(sorted_child2)-cp2)

        push!(child2, sorted_child2[i])

    end



    return child1, child2

end



# ============================================================

# NEH_TWT.jl

# ============================================================

function NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)

    if G < 2

        if G == 1

            sol_NEH_sequence = [1]

        else

            return [1, 2], 0

        end

        TWT_sol = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH_sequence, 1, length(sol_NEH_sequence)), v_result, ptr_time)

        return sol_NEH_sequence, TWT_sol

    end



    sequence_chromosome = zeros(Int, G)

    PT = sum(p, dims=2)

    PT1 = PT[:, 1]

    sol3 = sortperm(PT1)



    for i = 1:G

        sequence_chromosome[i] = sol3[i]

    end



    sol_NEH_sequence = zeros(Int, 2)

    sol_NEH_sequence[1] = sequence_chromosome[1]

    sol_NEH_sequence[2] = sequence_chromosome[2]



    TWT_sol_NEH = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH_sequence, 1, length(sol_NEH_sequence)), v_result, ptr_time)



    sol_NEH_sequence2 = zeros(Int, 2)

    sol_NEH_sequence2[1] = sequence_chromosome[2]

    sol_NEH_sequence2[2] = sequence_chromosome[1]



    TWT_sol_NEH2 = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH_sequence2, 1, length(sol_NEH_sequence2)), v_result, ptr_time)



    if TWT_sol_NEH2 < TWT_sol_NEH

        sol_NEH_sequence = sol_NEH_sequence2

        TWT_sol_NEH = TWT_sol_NEH2

    end



    for k in 3:G

        Seq = zeros(Int64, k, k)

        TWT_Seq = zeros(Int64, k)



        for i in 1:k

            New_sol_NEH = zeros(Int64, length(sol_NEH_sequence))

            for u in 1:length(sol_NEH_sequence)

                New_sol_NEH[u] = sol_NEH_sequence[u]

            end

            insert!(New_sol_NEH, i, sequence_chromosome[k])

            Seq[i, :] = New_sol_NEH

            TWT_Seq[i] = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(New_sol_NEH, 1, length(New_sol_NEH)), v_result, ptr_time)

        end



        min_val, best_index = findmin(TWT_Seq)

        sol_NEH_sequence = zeros(Int, k)

        sol_NEH_sequence = Seq[best_index, :]

        TWT_sol_NEH = min_val

    end



    return sol_NEH_sequence, TWT_sol_NEH

end



function Random_solution(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)

    if G < 2

        if G == 1

            sequence_chromosome = [1]

        else

            sequence_chromosome = [1, 2]

        end

    else

        sequence_chromosome = randperm(G)

    end



    ct, C, MK = makespan(p, G, W, mold_to_groups, group_to_mold, sequence_chromosome, ptr_time)



    ct_jobs = zeros(Int64, J)

    for pair in v_result

        job_id = pair[1]

        group_id = pair[2]

        if group_id <= length(ct)

            ct_jobs[job_id] = Int(ct[group_id])

        end

    end



    T = zeros(Int64, J)

    for j in 1:J

        T[j] = ct_jobs[j] - d[j]

        if T[j] < 0

            T[j] = 0

        end

    end



    del_punish = sum(beta[j] * T[j] for j in 1:J)

    return sequence_chromosome, del_punish

end



function initial_solution(population_size, beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)

    population = []

    neh_count = div(population_size * 6, 10)

    random_count = div(population_size * 4, 10)



    for i in 1:neh_count

        sol_NEH_sequence, TWT_sol_NEH = NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)

        push!(population, (sol_NEH_sequence, TWT_sol_NEH))

    end



    for i in 1:random_count

        sol_Random_sequence, TWT_sol_Random = Random_solution(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)

        push!(population, (sol_Random_sequence, TWT_sol_Random))

    end



    return population

end



# ============================================================

# GA_VNS.jl

# ============================================================

function GA_VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, population, population_size, crossover_prob, mutation_prob, v_result, max_iteration, ptr_time, time_limit)

    fitness = [1.0 / (1.0 + pop[2]) for pop in population]

    sorted_population, sorted_indice = select_elite(population, fitness)

    best_fitness = fitness[sorted_indice]

    best_TWT = population[sorted_indice][2]

    best_solution = population[sorted_indice][1]



    iteration = 1

    T_para = 0.4

    Temp = T_para * sum(p) / (10 * J * G)



    start_time = time()



    while iteration < max_iteration && (time() - start_time < time_limit)

        new_population = []



        for i in 1:length(sorted_population)

            push!(new_population, sorted_population[i])

        end



        while length(new_population) < population_size

            selected_parent = roulette_selection(population)

            seq_parent1 = selected_parent[1][1]

            seq_parent2 = selected_parent[2][1]

            par1_TWT = selected_parent[1][2]

            par2_TWT = selected_parent[2][2]

            par1_fit = 1.0 / (1.0 + par1_TWT)

            par2_fit = 1.0 / (1.0 + par2_TWT)



            if rand() < crossover_prob

                seq_child1, seq_child2 = sequence_crossover(seq_parent1, seq_parent2)

            else

                seq_child1 = copy(seq_parent1)

                seq_child2 = copy(seq_parent2)

            end



            if rand() < mutation_prob

                new_seq_child1, child1_TWT = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_child1)

                new_seq_child2, child2_TWT = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_child2)

            else

                new_seq_child1 = copy(seq_child1)

                new_seq_child2 = copy(seq_child2)

                child1_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_child1, 1, length(new_seq_child1)), v_result, ptr_time)

                child2_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_child2, 1, length(new_seq_child2)), v_result, ptr_time)

            end



            child1_fit = 1.0 / (1.0 + child1_TWT)

            child2_fit = 1.0 / (1.0 + child2_TWT)



            g = rand()

            sa1 = exp((child1_fit - par1_fit) / Temp)

            sa2 = exp((child2_fit - par2_fit) / Temp)



            if child1_fit > par1_fit || g <= sa1

                seq_child1 = copy(new_seq_child1)

            end



            if child2_fit > par2_fit || g <= sa2

                seq_child2 = copy(new_seq_child2)

            end



            final_child1_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_child1, 1, length(seq_child1)), v_result, ptr_time)

            final_child2_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_child2, 1, length(seq_child2)), v_result, ptr_time)



            push!(new_population, (seq_child1, final_child1_TWT))

            push!(new_population, (seq_child2, final_child2_TWT))

        end



        population = copy(new_population)

        fitnesses = [1.0 / (1.0 + pop[2]) for pop in population]

        current_best_fitness = maximum(fitnesses)



        if current_best_fitness > best_fitness

            best_idx = argmax(fitnesses)

            best_fitness = current_best_fitness

            best_TWT = population[best_idx][2]

            best_solution = population[best_idx][1]

        end



        sorted_population, sorted_indice = select_elite(population, fitnesses)

        iteration += 1

    end



    return best_solution, best_TWT

end



# ============================================================

# yunshu.jl - 车辆分配优化 (CPLEX)

# ===================================================================
# VLSP: Vehicle Loading Subproblem (MILP, per-group)
# ===================================================================

function VLSP(group_jobs::Vector{Int}, all_weights, rho, Q;
              time_limit::Float64=60.0, verbose::Bool=false)
    n_jobs = length(group_jobs)
    if n_jobs == 0
        return 0.0, 0, Int[]
    end
    weights = Float64[all_weights[j] for j in group_jobs]
    min_vehicles = ceil(Int, sum(weights) / Q)
    V = min(n_jobs, min_vehicles + 3)
    model = Model(Gurobi.Optimizer)
    if verbose
        println("    [VLSP] 组内作业数=$n_jobs, 车辆上限=$V, 最小所需车辆=$min_vehicles")
    end
    @variable(model, X[j=1:n_jobs, v=1:V], Bin)
    @variable(model, γ[v=1:V], Bin)
    @objective(model, Min, sum(rho * γ[v] for v in 1:V))
    @constraint(model, [j in 1:n_jobs], sum(X[j, v] for v in 1:V) == 1)
    @constraint(model, [j in 1:n_jobs, v in 1:V], X[j, v] <= γ[v])
    @constraint(model, [v in 1:V], sum(weights[j] * X[j, v] for j in 1:n_jobs) <= Q * γ[v])
    for vv in 2:V
        @constraint(model, γ[vv] <= γ[vv-1])
    end
    set_optimizer_attribute(model, "OutputFlag", 0)
    set_time_limit_sec(model, time_limit)
    set_silent(model)
    optimize!(model)
    status = termination_status(model)
    if status == OPTIMAL || status == TIME_LIMIT || status == FEASIBLE_POINT
        v_cost = objective_value(model)
        vehicle_count = sum(value(γ[v]) for v in 1:V) |> value |> Int
        assignment_vector = zeros(Int, n_jobs)
        X_val = value.(X)
        for j in 1:n_jobs
            for v in 1:V
                if X_val[j, v] > 0.5
                    assignment_vector[j] = v
                    break
                end
            end
        end
        return v_cost, vehicle_count, assignment_vector
    else
        if verbose
            println("    [VLSP] 警告: 求解状态=$status")
        end
        return Inf, 0, zeros(Int, n_jobs)
    end
end

function yunshu(J, W, wg, rho, Q; verbose::Bool=false)
    time_limit = W > 0 ? J * W * 0.02 : 60.0
    total_cost, vehicle_count, assignment_vector = VLSP(
        collect(1:J), wg, rho, Q; time_limit=time_limit, verbose=verbose)
    return total_cost, vehicle_count, assignment_vector
end



# ============================================================

# BF_GA_NOPR 主函数 (无扰动重启)

# ============================================================

function BF_GA_NOPR(J, W_num, w, h, pt, d, beta, ptr_time, wg, tal_seq, WW, HH, rho, Q, alpha, lambda_vec)

    items = hcat(w, h)

    boxes_dict, ansBXY, ran, BinNum, result = packing_by_sequence_aga(items, tal_seq, WW, HH)



    raw_bin_ids = result[:, 2]

    sorted_keys = sort(collect(Set(raw_bin_ids)))

    G = length(sorted_keys)

    bin_id_map = Dict(old_id => new_id for (new_id, old_id) in enumerate(sorted_keys))



    v_result = [[Int(result[i, 1]), bin_id_map[result[i, 2]]] for i in 1:size(result, 1)]



    bin_to_jobs = Dict{Int, Vector{Int}}()

    for pair in v_result

        job_id = pair[1]

        group_id = pair[2]

        if haskey(bin_to_jobs, group_id)

            push!(bin_to_jobs[group_id], job_id)

        else

            bin_to_jobs[group_id] = [job_id]

        end

    end



    p = zeros(G, 4)

    for (group_id, jobs) in bin_to_jobs

        p1 = []

        p3 = []

        for j in jobs

            p[group_id, 2] += pt[j, 2]

            push!(p1, pt[j, 1])

            push!(p3, pt[j, 3])

        end

        p[group_id, 1] = maximum(p1)

        p[group_id, 3] = maximum(p3)

    end

    p[:, 4] .= ptr_time



    group_to_mold = Dict{Int, Int}()

    mold_to_groups = Dict{Int, Vector{Int}}()

    mold_load = zeros(W_num)



    sorted_bins = sortperm([p[bin_id, 1] for bin_id in 1:G])

    for bin_id in sorted_bins

        lightest_mold = argmin(mold_load)

        group_to_mold[bin_id] = lightest_mold

        if haskey(mold_to_groups, lightest_mold)

            push!(mold_to_groups[lightest_mold], bin_id)

        else

            mold_to_groups[lightest_mold] = [bin_id]

        end

        mold_load[lightest_mold] += p[bin_id, 1]

    end



    if G >= 2 && W_num >= 2

        perturb_count = min(rand(1:3), G)

        for _ in 1:perturb_count

            all_groups = collect(1:G)

            if isempty(all_groups)

                break

            end

            g = rand(all_groups)

            old_mold = group_to_mold[g]

            possible_molds = [m for m in 1:W_num if m != old_mold]

            if !isempty(possible_molds)

                new_mold = rand(possible_molds)

                group_to_mold[g] = new_mold

                filter!(x -> x != g, mold_to_groups[old_mold])

                if haskey(mold_to_groups, new_mold)

                    push!(mold_to_groups[new_mold], g)

                else

                    mold_to_groups[new_mold] = [g]

                end

                mold_load[old_mold] -= p[g, 1]

                mold_load[new_mold] += p[g, 1]

            end

        end

    end



    group_to_mold_remap = group_to_mold

    mold_to_groups_remap = mold_to_groups



    max_iteration = maxIter_tuning

    population_size = popSize_tuning * G

    crossover_prob = pc_tuning

    mutation_prob = pm_tuning



    ga_time_limit = J * W_num * 0.02



    population = initial_solution(population_size, beta, d, p, J, G, W_num, mold_to_groups_remap, group_to_mold_remap, v_result, ptr_time)



    best_group_seq, best_TWT = GA_VNS(beta, d, p, J, G, W_num, mold_to_groups_remap, group_to_mold_remap, population, population_size, crossover_prob, mutation_prob, v_result, max_iteration, ptr_time, ga_time_limit)

    total_v_cost = 0.0
    job_to_vehicle = zeros(Int, J)
    global_vehicle_counter = 0
    for group_id in sort(collect(keys(bin_to_jobs)))
        group_jobs = bin_to_jobs[group_id]
        group_time_limit = length(group_jobs) * W_num * 0.02
        g_cost, g_vehicles, g_assignment = VLSP(group_jobs, wg, rho, Q; time_limit=group_time_limit, verbose=false)
        total_v_cost += g_cost
        for (idx, job_id) in enumerate(group_jobs)
            job_to_vehicle[job_id] = g_assignment[idx] + global_vehicle_counter
        end
        global_vehicle_counter += g_vehicles
    end
    v_result_with_vehicle = [[pair[1], pair[2], job_to_vehicle[pair[1]]] for pair in v_result]

    group_activation_cost = G * alpha

    twt_value = best_TWT

    best_cost = total_v_cost + twt_value + group_activation_cost

    return best_group_seq, best_cost, G, best_group_seq, v_result_with_vehicle, p, group_to_mold, mold_to_groups, total_v_cost, twt_value, group_activation_cost, job_to_vehicle

end



# ============================================================

# main 函数 (SVC 迭代版本)

# ============================================================

function main(filenm)

    J = load(filenm, "JJ")

    W = load(filenm, "WW_num")



    WW = load(filenm, "WW")

    HH = load(filenm, "HH")

    α = load(filenm, "alpha")



    w = load(filenm, "wj")

    h = load(filenm, "hj")



    pt = load(filenm, "pp")

    d = load(filenm, "dd")

    β = load(filenm, "betabeta")

    ptr_time = load(filenm, "ptr")



    wg = load(filenm, "wg")



    Q = load(filenm, "Q")

    rho = load(filenm, "rho")



    # SVC 时间限制：J × W_num × 0.5 秒

    svc_time_limit = J * W * 0.5



    # SVC 伪价格初始化

    lambda_vec = init_lambda_vec(J, d, w, h; WW=WW, HH=HH)



    # 计算 bin 数量下界 nLB（面积下界）

    total_area = sum(w[i] * h[i] for i in 1:J)

    nLB = ceil(Int, total_area / (WW * HH))



    start_time = time()



    # 全局最优解

    best_cost = Inf

    best_result = nothing



    svc_iteration = 0



    while (time() - start_time) < svc_time_limit

        svc_iteration += 1

        iter_start = time()



        # ── ① 用伪价格排序 → BF 装箱 ──────────────────────

        tal_seq = sort_by_lambda_vec(lambda_vec)



        # ── ② AGA 调度 + yunshu 车辆分配 ──────────────────

        result = BF_GA_NOPR(J, W, w, h, pt, d, β, ptr_time, wg,
                            tal_seq, WW, HH, rho, Q, α, lambda_vec)



        # 解包 result

        if length(result) == 12

            grp_seq, cur_cost, cur_bin_num, _,

            v_result, p_mat, grp_to_mold, mold_to_grps,

            v_cost, tard_cost, mold_act_cost, job_to_vehicle_arr = result

        else

            grp_seq, cur_cost, cur_bin_num, _,

            v_result, p_mat, grp_to_mold, mold_to_grps,

            v_cost, tard_cost, mold_act_cost, job_to_vehicle_arr = result[1:12]

        end



        iter_time = time() - iter_start



        # ── ③ 记录全局最优 ────────────────────────────────

        if cur_cost < best_cost

            best_cost = cur_cost

            best_result = (grp_seq, cur_cost, cur_bin_num,

                          v_result, p_mat, grp_to_mold, mold_to_grps,

                          v_cost, tard_cost, mold_act_cost, job_to_vehicle_arr)

            println("  [SVC iter $svc_iteration] ★ 新最优 cost=$(round(cur_cost,digits=2)) "

                  * "G=$cur_bin_num v_cost=$(round(v_cost,digits=2)) "

                  * "tard=$(round(tard_cost,digits=2)) [$(round(iter_time,digits=2))s]")

        else

            if svc_iteration % 5 == 0

                println("  [SVC iter $svc_iteration] cost=$(round(cur_cost,digits=2)) "

                      * "G=$cur_bin_num [$(round(iter_time,digits=2))s]")

            end

        end



        # ── ④ 更新伪价格 ────────────────────────────────────

        G_val = cur_bin_num

        delta = rand()  # 论文中 δ ∈ (0, 1]



        update_lambda_vec!(lambda_vec,

                              v_result, p_mat,

                              J, G_val, nLB, Float64(ptr_time),

                              d, w, h,

                              delta;

                              WW=WW, HH=HH)

    end



    total_runtime = time() - start_time

    println("  [SVC] 共迭代 $svc_iteration 轮，总耗时 $(round(total_runtime,digits=2))s，"

           * "最优 cost=$(round(best_cost,digits=2))")



    # 解包最优解

    best_grp_seq, _, best_bin_num,

    best_v_result, best_p, best_grp_to_mold, best_mold_to_grps,

    best_v_cost, best_tard_cost,

    best_mold_act_cost, best_job_to_vehicle_arr = best_result



    stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho,

        best_grp_seq, best_v_result, best_p, best_grp_to_mold, best_mold_to_grps,

        best_v_cost, best_tard_cost, best_mold_act_cost)

    total_vehicles_used = isempty(best_job_to_vehicle_arr) ? 0 : length(filter(!iszero, unique(best_job_to_vehicle_arr)))

    return (total_runtime, best_grp_seq, best_cost, best_bin_num,

            best_v_result, best_p, best_grp_to_mold, best_mold_to_grps,

            best_v_cost, best_tard_cost,

            stats, total_vehicles_used, best_mold_act_cost)

end



# ============================================================

# 结果统计

# ============================================================

function build_solution_statistics(J, W, WW, HH, w, h, d, beta, rho,

    best_seq, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,

    best_v_cost, best_tardiness_cost, mold_activation_cost)



    mold_area = WW * HH

    group_jobs = Dict{Int, Vector{Int}}()

    for item in best_v_result

        if item isa AbstractVector && length(item) >= 2

            job_id = item[1]

            group_id = item[2]

        else

            continue

        end

        if !haskey(group_jobs, group_id)

            group_jobs[group_id] = Int[]

        end

        push!(group_jobs[group_id], job_id)

    end



    mold_utilization = Dict{Int, Float64}()

    group_utilization = Dict{Int, Float64}()

    for (group_id, jobs) in group_jobs

        used_area = sum(w[j] * h[j] for j in jobs)

        group_utilization[group_id] = mold_area > 0 ? used_area / mold_area : 0.0

    end

    for mold in 1:W

        group_ids = get(best_mold_to_groups, mold, Int[])

        if isempty(group_ids)

            mold_utilization[mold] = 0.0

        else

            total_util = sum(get(group_utilization, group_id, 0.0) for group_id in group_ids)

            mold_utilization[mold] = total_util / length(group_ids)

        end

    end



    vehicle_assignments = Dict{Int, Int}()

    if best_v_result isa AbstractVector

        for item in best_v_result

            if item isa AbstractVector && length(item) >= 3

                job_id = item[1]

                vehicle_id = item[3]

                if vehicle_id isa Number && vehicle_id > 0

                    vehicle_assignments[job_id] = Int(vehicle_id)

                end

            end

        end

    end



    vehicle_count = length(filter(!iszero, unique(values(vehicle_assignments))))



    tardy_jobs = Vector{NamedTuple{(:job_id, :completion_time, :due_date, :tardiness, :penalty), Tuple{Int, Float64, Float64, Float64, Float64}}}()



    G = size(best_p, 1)

    if !isempty(best_seq) && !isempty(best_p) && !isempty(best_group_to_mold) && !isempty(best_mold_to_groups)

        seq_vec = best_seq isa AbstractVector ? collect(best_seq) : vec(best_seq)

        ct, _, _ = makespan(best_p, G, W, best_mold_to_groups, best_group_to_mold, seq_vec, best_p[1, 4])



        job_to_group = Dict(pair[1] => pair[2] for pair in best_v_result)

        for j in 1:J

            group_id = get(job_to_group, j, 0)

            if group_id <= 0 || group_id > length(ct)

                continue  # 跳过无效的工件-组映射

            end

            completion_time = ct[group_id]

            tardiness = max(completion_time - d[j], 0.0)

            penalty = beta[j] * tardiness

            if tardiness > 1e-6

                push!(tardy_jobs, (

                    job_id = j,

                    completion_time = completion_time,

                    due_date = d[j],

                    tardiness = tardiness,

                    penalty = penalty,

                ))

            end

        end

    end



    total_tardy_penalty = sum(item.penalty for item in tardy_jobs)



    return (

        mold_utilization = mold_utilization,

        group_utilization = group_utilization,

        average_mold_utilization = isempty(group_utilization) ? 0.0 : sum(values(group_utilization)) / length(group_utilization),

        vehicle_count = vehicle_count,

        vehicle_cost = best_v_cost,

        mold_activation_cost = mold_activation_cost,

        tardy_jobs = tardy_jobs,

        total_tardy_penalty = total_tardy_penalty,

    )

end



function print_solution_statistics(stats, G, alpha)

    println("  工件组面积利用率:")

    for group_id in sort(collect(keys(stats.group_utilization)))

        println("    工件组 $(group_id): $(round(stats.group_utilization[group_id] * 100, digits=2))%")

    end

    println("  平均工件组面积利用率 = $(round(stats.average_mold_utilization * 100, digits=2))%")

    println("  使用车辆数量 = $(stats.vehicle_count)")

    println("  拖期工件数量 = $(length(stats.tardy_jobs))")

    println("  总拖期费用 = $(round(stats.total_tardy_penalty, digits=2))")

    println("  成本分解:")

    println("    车辆成本 (vehicle_cost) = $(round(stats.vehicle_cost, digits=2))")

    println("    模台激活成本 (mold_activation_cost) = $(round(stats.mold_activation_cost, digits=2)) (G=$G, alpha=$alpha)")

    println("    拖期惩罚 (tardiness_cost) = $(round(stats.total_tardy_penalty, digits=2))")



    if isempty(stats.tardy_jobs)

        println("  无拖期工件")

    else

        println("  拖期工件明细:")

        for item in stats.tardy_jobs

            println("    工件 $(item.job_id): 完工=$(round(item.completion_time, digits=2)), 交期=$(round(item.due_date, digits=2)), 拖期=$(round(item.tardiness, digits=2)), 费用=$(round(item.penalty, digits=2))")

        end

    end

end



# ============================================================

# 测试接口

# ============================================================

const INSTANCE_DIR = joinpath(SCRIPT_DIR, "DATA_Instances")



function single_instance_test(filenm; num_runs=5)

    println("=" ^ 70)

    println("BF-AGANOPR 单实例测试 (集成版)")

    println("=" ^ 70)

    println("实例文件: $(basename(filenm))")

    println("运行次数: $num_runs")

    println("=" ^ 70)



    J = load(filenm, "JJ")

    WW_num = load(filenm, "WW_num")

    WW = load(filenm, "WW")

    HH = load(filenm, "HH")

    α = load(filenm, "alpha")

    wg = load(filenm, "wg")

    Q = load(filenm, "Q")

    rho = load(filenm, "rho")



    println("\n实例参数:")

    println("  工件数 J = $J")

    println("  模台数 WW_num = $WW_num")

    println("  模台尺寸 WW × HH = $WW × $HH")

    println("  模台激活成本 α = $α")

    println("  总重量 = $(sum(wg))")

    println("  车辆载量 Q = $Q, 固定成本 ρ = $rho")

    println("  最小车辆数 = $(ceil(Int, sum(wg)/Q))")



    check_out = zeros(num_runs)

    check_time = zeros(num_runs)

    check_vehicle_count = fill(NaN, num_runs)

    check_vehicle_cost = fill(NaN, num_runs)

    check_mold_activation_cost = fill(NaN, num_runs)

    check_mold_utilization = fill(NaN, num_runs)

    check_tardy_penalty = fill(NaN, num_runs)



    for op in 1:num_runs

        println("\n--- 第 $op/$num_runs 次运行 ---")

        try

            r = main(filenm)

            run_time, current_tal, current_cost, current_bin_num = r[1:4]

            stats = r[11]  # stats is at position 11 in the return tuple

            check_out[op] = current_cost

            check_time[op] = run_time

            println("  组数 G = $current_bin_num")

            println("  成本 = $current_cost")

            println("  运行时间 = $(round(run_time, digits=2))s")

            println("  最优序列 = $current_tal")

            if stats !== nothing

                print_solution_statistics(stats, current_bin_num, α)

            end

        catch e

            println("  错误: $e")

            check_out[op] = NaN

            check_time[op] = NaN

        end

    end



    println("\n" * "=" ^ 70)

    println("统计结果")

    println("=" ^ 70)



    valid_costs = filter(!isnan, check_out)

    valid_times = filter(!isnan, check_time)



    if !isempty(valid_costs)

        println("  成本: 最小=$(minimum(valid_costs)), 最大=$(maximum(valid_costs)), 平均=$(round(mean(valid_costs), digits=2))")

        println("  时间: 最小=$(round(minimum(valid_times), digits=2))s, 最大=$(round(maximum(valid_times), digits=2))s, 平均=$(round(mean(valid_times), digits=2))s")

    else

        println("  所有运行都失败了！")

    end



    println("=" ^ 70)

    return (costs=check_out, times=check_time)

end



# ============================================================

# 批量测试接口

# ============================================================

function batch_test(; num_runs=5)

    data_dir = INSTANCE_DIR

    results_dir = joinpath(SCRIPT_DIR, "results")

    if !isdir(results_dir)

        mkdir(results_dir)

    end



    all_files = String[]

    for f in readdir(data_dir)

        if endswith(f, ".jld2")

            push!(all_files, joinpath(data_dir, f))

        end

    end

    all_files = sort(all_files)



    timestamp = Dates.format(now(), "yyyy-mm-dd_HHMMSS")

    output_file = joinpath(results_dir, "AGA_NOPR_results_$timestamp.csv")



    println("=" ^ 70)

    println("BF-AGA-NOPR 批量测试")

    println("=" ^ 70)

    println("数据目录: $data_dir")

    println("共找到 $(length(all_files)) 个数据集文件")

    println("每个实例运行 $num_runs 次")

    println("结果输出: $output_file")

    println("=" ^ 70)



    results = []

    total = length(all_files)



    for (idx, filenm) in enumerate(all_files)

        println("\n[$idx/$total] 正在测试: $(basename(filenm))")



        α = load(filenm, "alpha")



        check_out = zeros(num_runs)

        check_time = zeros(num_runs)

        check_vehicle_count = fill(NaN, num_runs)

        check_vehicle_cost = fill(NaN, num_runs)

        check_mold_activation_cost = fill(NaN, num_runs)

        check_mold_utilization = fill(NaN, num_runs)

        check_tardy_penalty = fill(NaN, num_runs)



        for op in 1:num_runs

            try

                r = main(filenm)

                run_time, best_tal, best_cost, best_bin_num = r[1:4]

                stats = r[11]  # stats is at position 11

                mold_act_cost = r[12]  # best_mold_activation_cost is at position 12

                check_out[op] = best_cost

                check_time[op] = run_time

                if stats !== nothing

                    check_vehicle_count[op] = stats.vehicle_count

                    check_vehicle_cost[op] = stats.vehicle_cost

                    check_mold_activation_cost[op] = mold_act_cost

                    check_mold_utilization[op] = stats.average_mold_utilization

                    check_tardy_penalty[op] = stats.total_tardy_penalty

                end

            catch e

                println("  运行 $op 错误: $e")

                check_out[op] = NaN

                check_time[op] = NaN

            end

        end



        val_cost = mean(filter(!isnan, check_out))

        val_time = mean(filter(!isnan, check_time))

        avg_vehicle_count = mean(filter(!isnan, check_vehicle_count))

        avg_vehicle_cost = mean(filter(!isnan, check_vehicle_cost))

        avg_mold_activation_cost = mean(filter(!isnan, check_mold_activation_cost))

        avg_mold_utilization = mean(filter(!isnan, check_mold_utilization))

        avg_tardy_penalty = mean(filter(!isnan, check_tardy_penalty))



        push!(results, (instance=basename(filenm),

            (Symbol("cost$i") => check_out[i] for i in 1:num_runs)...,

            avg_cost=val_cost, avg_time=val_time,

            (Symbol("vehicle_count$i") => check_vehicle_count[i] for i in 1:num_runs)...,

            avg_vehicle_count=avg_vehicle_count,

            (Symbol("vehicle_cost$i") => check_vehicle_cost[i] for i in 1:num_runs)...,

            avg_vehicle_cost=avg_vehicle_cost,

            (Symbol("mold_act_cost$i") => check_mold_activation_cost[i] for i in 1:num_runs)...,

            avg_mold_activation_cost=avg_mold_activation_cost,

            (Symbol("util$i") => (isnan(check_mold_utilization[i]) ? NaN : round(Int, check_mold_utilization[i] * 100)) for i in 1:num_runs)...,

            avg_mold_utilization=(isnan(avg_mold_utilization) ? NaN : round(Int, avg_mold_utilization * 100)),

            (Symbol("tardy$i") => check_tardy_penalty[i] for i in 1:num_runs)...,

            avg_tardy_penalty=avg_tardy_penalty))



        println("  -> 平均成本: $(round(val_cost, digits=2)), 平均时间: $(round(val_time, digits=2))s")

        println("     平均车辆数: $(round(avg_vehicle_count, digits=2)), 平均车辆成本: $(round(avg_vehicle_cost, digits=2)), 平均模台激活成本: $(round(avg_mold_activation_cost, digits=2)), 平均工件组面积利用率: $(round(Int, avg_mold_utilization * 100))%, 平均拖期惩罚: $(round(avg_tardy_penalty, digits=2))")

    end



    df = DataFrame(results)

    CSV.write(output_file, df)

    println("\n" * "=" ^ 70)

    println("批量测试完成！")

    println("结果已保存到: $output_file")

    println("=" ^ 70)



    return df

end



# ============================================================

# 命令行接口

# ============================================================

if abspath(PROGRAM_FILE) == @__FILE__

    if length(ARGS) == 0

        batch_test()

    elseif ARGS[1] == "single"

        filenm = length(ARGS) >= 2 ? ARGS[2] : joinpath(INSTANCE_DIR, "S_10_2_1.jld2")

        num_runs = length(ARGS) >= 3 ? parse(Int, ARGS[3]) : 5

        single_instance_test(filenm; num_runs=num_runs)

    elseif ARGS[1] == "batch"

        num_runs = length(ARGS) >= 2 ? parse(Int, ARGS[2]) : 5

        batch_test(; num_runs=num_runs)

    elseif ARGS[1] == "help"

        println("""

        使用方法:

          julia BF_AGANOPR_Integrated.jl           # 批量测试所有实例（默认）

          julia BF_AGANOPR_Integrated.jl batch     # 批量测试（默认5次/实例）

          julia BF_AGANOPR_Integrated.jl batch 5   # 批量测试（指定运行次数）

          julia BF_AGANOPR_Integrated.jl single    # 单实例测试（使用默认文件）

          julia BF_AGANOPR_Integrated.jl single S_10_2_1.jld2  # 测试指定文件

          julia BF_AGANOPR_Integrated.jl single S_10_2_1.jld2 5  # 指定文件和次数

          julia BF_AGANOPR_Integrated.jl help       # 显示帮助

        """)

    else

        println("未知命令: $(ARGS[1])")

        println("输入 'julia BF_AGANOPR_Integrated.jl help' 查看帮助")

    end

end

