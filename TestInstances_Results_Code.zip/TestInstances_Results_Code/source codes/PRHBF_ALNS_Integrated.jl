"""
PRHBF_ALNS_Integrated.jl
PRHBF-ALNS算法 - 完全集成版本
将所有子程序整合到一个文件中，无需外部include
"""

using JLD2, HDF5, LinearAlgebra, Plots, Statistics, DataFrames, Random
using JuMP, JLD, StatsBase, CSV, Dates, CPUTime
using Gurobi

ENV["CPLEX_LICENSE_DEBUG"] = "0"

# ============================================================
# 读取调参得到的最优参数
# ============================================================
const SCRIPT_DIR = @__DIR__
const TUNING_DIR = joinpath(SCRIPT_DIR, "..", "tuning_irace", "R", "results")

function load_tuning_params()
    try
        params_alns = CSV.File(joinpath(TUNING_DIR, "PRHBF_ALNS", "best_params_PRHBF_ALNS.csv")) |> first
        return (
            max_iteration = params_alns.max_iteration,
            d_para = params_alns.d_para,
            T_para = params_alns.T_para,
            alpha_cooling = params_alns.alpha_cooling,
            sigma1 = params_alns.sigma1,
            sigma2 = params_alns.sigma2,
            sigma3 = params_alns.sigma3,
            reaction_factor = params_alns.reaction_factor
        )
    catch e
        @warn "无法读取调参参数文件，使用默认参数: $e"
        return (
            max_iteration = 169,
            d_para = 3,
            T_para = 0.5406,
            alpha_cooling = 0.9649,
            sigma1 = 8.0,
            sigma2 = 18.0,
            sigma3 = 3.5405,
            reaction_factor = 0.2641
        )
    end
end

const params_alns = load_tuning_params()
const maxIter_tuning = params_alns.max_iteration
const d_para_tuning = params_alns.d_para
const T_para_tuning = params_alns.T_para
const alpha_cooling_tuning = params_alns.alpha_cooling
const sigma1_tuning = params_alns.sigma1
const sigma2_tuning = params_alns.sigma2
const sigma3_tuning = params_alns.sigma3
const reaction_factor_tuning = params_alns.reaction_factor

# ============================================================
# SkylineBF.jl - 装箱数据结构与算法
# ============================================================
mutable struct SkylineSegment
    x::Int; width::Int; height::Int
end

mutable struct RectangleItem
    index::Int; width::Int; height::Int; rotated::Bool
end

mutable struct PackingItem
    id::Int; width::Int; height::Int
end

mutable struct PackingBin
    width::Int; height::Int
    items::Vector{Tuple{PackingItem,Tuple{Int,Int}}}
    remaining_width::Int; remaining_height::Int
end

PackingBin(width::Int, height::Int) = PackingBin(width, height, [], width, height)

function can_place(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int})
    x, y = position
    x + item.width <= bin.width && y + item.height <= bin.height || return false
    for (pi, pp) in bin.items
        px, py = pp
        x < px + pi.width && x + item.width > px &&
        y < py + pi.height && y + item.height > py && return false
    end
    true
end

place_item!(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int}) =
    push!(bin.items, (item, position))

function find_position_skyline(bin::PackingBin, item::PackingItem)
    for y in 0:(bin.height - item.height)
        for x in 0:(bin.width - item.width)
            can_place(bin, item, (x, y)) && return (x, y)
        end
    end
    nothing
end

function merge_adjacent_segments(segments::Vector{SkylineSegment})
    isempty(segments) && return segments
    merged = SkylineSegment[]; current = segments[1]
    for i in 2:length(segments)
        if segments[i].height == current.height
            current = SkylineSegment(current.x, current.width + segments[i].width, current.height)
        else
            push!(merged, current); current = segments[i]
        end
    end
    push!(merged, current); merged
end

function place_rectangle_on_skyline(
    segments::Vector{SkylineSegment}, item_w::Int, item_h::Int, x_pos::Int)
    new_segments = SkylineSegment[]
    cur_x = 0; seg_idx = 0
    for (i, seg) in enumerate(segments)
        if x_pos >= cur_x && x_pos < cur_x + seg.width
            seg_idx = i; break
        end
        cur_x += seg.width
    end
    seg_idx == 0 && (seg_idx = length(segments))
    left_w = x_pos - cur_x
    right_w = segments[seg_idx].width - left_w - item_w
    for i in 1:(seg_idx-1); push!(new_segments, segments[i]); end
    if left_w > 0
        push!(new_segments, SkylineSegment(segments[seg_idx].x, left_w, segments[seg_idx].height))
    end
    push!(new_segments, SkylineSegment(x_pos, item_w, segments[seg_idx].height + item_h))
    if right_w > 0
        push!(new_segments, SkylineSegment(x_pos + item_w, right_w, segments[seg_idx].height))
    end
    for i in (seg_idx+1):length(segments); push!(new_segments, segments[i]); end
    merge_adjacent_segments(new_segments)
end

# ============================================================
# BFP 算法 - 基于论文的修正版本
# ============================================================

"""
修正后的 BFP 装箱算法
主要改进:
1. 使用滑动窗口机制 (Step 1)
2. 计算 sky_dif (最小间隙与机器高度差) (Step 2, 6)
3. 计算 hwmin (待放置工件中最小高度和宽度的最小值) (Step 3, 6)
4. 主动换组判断 (Step 6: if sky_dif < hwmin, close group)
5. 找不到合适工件时填隙 (Step 5)
"""
function skyline_bf_packing_v2(Item, ran, pallet_width, pallet_height)
    itemNum = size(Item, 1)
    ansBXY = zeros(Int, itemNum, 6)
    result = zeros(Int, itemNum, 2)
    rotated = zeros(Int, itemNum)
    placed = Vector{Tuple{Int,Int,Int,Int,Int,Int}}()

    R = RectangleItem[]
    for i in ran
        w, h = Item[i,1], Item[i,2]; rf = false
        if h > w; w, h = h, w; rf = true; end
        push!(R, RectangleItem(i, w, h, rf))
    end

    bin_num = 0
    pallet_area = pallet_width * pallet_height

    while !isempty(R)
        bin_num += 1
        skyline = [SkylineSegment(0, pallet_width, 0)]

        # Step 1: 提取滑动窗口中的工件
        L = RectangleItem[]
        total_area = 0
        idx = 1
        while idx <= length(R) && total_area < pallet_area
            total_area += R[idx].width * R[idx].height
            push!(L, R[idx])
            idx += 1
        end

        # Step 4: 旋转并排序 (宽度降序，高度降序)
        for r in L
            if r.height > r.width
                r.width, r.height = r.height, r.width
                r.rotated = !r.rotated
            end
        end
        sort!(L, by=r -> (-r.width, -r.height))

        # 从 R 中移除已放入 L 的工件
        for r in L
            rmi = findfirst(x -> x.index == r.index, R)
            if rmi !== nothing
                deleteat!(R, rmi)
            end
        end

        # 放置循环 (Step 5-6)
        while !isempty(L)
            # Step 2: 计算 sky_dif (最小间隙与机器高度之差)
            min_seg_idx = 0
            min_seg_h = typemax(Int)
            for (i, seg) in enumerate(skyline)
                if seg.height < min_seg_h
                    min_seg_h = seg.height
                    min_seg_idx = i
                end
            end

            seg = skyline[min_seg_idx]
            gap_h = seg.height
            gap_x = seg.x
            avail_w = seg.width
            avail_h = pallet_height - gap_h

            sky_dif = pallet_height - min_seg_h  # 剩余高度

            # Step 3: 计算 hwmin (L 中最小的尺寸)
            hwmin = minimum(min(r.height, r.width) for r in L)

            # Step 6: 主动换组判断
            if sky_dif < hwmin
                # 当前组装满，将 L 中的工件放回 R 头部
                reverse!(L)
                for r in L
                    insert!(R, 1, r)
                end
                break  # 关闭当前组
            end

            # Step 5: 基于 BF 思想选择最合适的工件
            best_rect = nothing
            best_idx = 0
            best_score = -1

            for (idx, r) in enumerate(L)
                if r.width <= avail_w && r.height <= avail_h
                    score = r.width * r.height
                    if score > best_score
                        best_score = score
                        best_rect = r
                        best_idx = idx
                    end
                end
            end

            if best_rect !== nothing
                push!(placed, (best_rect.index, gap_x, gap_h,
                    best_rect.width, best_rect.height,
                    best_rect.rotated ? 1 : 0))
                ansBXY[best_rect.index, :] =
                    [bin_num, best_rect.index, best_rect.width,
                     best_rect.height, gap_x, gap_h]
                rotated[best_rect.index] = best_rect.rotated ? 1 : 0
                result[best_rect.index, :] = [best_rect.index, bin_num]

                deleteat!(L, best_idx)

                skyline = place_rectangle_on_skyline(skyline,
                    best_rect.width, best_rect.height, gap_x)
            else
                # 填隙
                if avail_w > 0 && avail_h > 0
                    skyline = place_rectangle_on_skyline(skyline, avail_w, avail_h, gap_x)
                end
            end
        end
    end

    boxes_dict = Dict{Int,Vector{Any}}()
    for b in 1:bin_num; boxes_dict[b] = []; end
    for i in 1:itemNum
        b = ansBXY[i,1]
        if b > 0; push!(boxes_dict[b], (Item[result[i,1],:], ran[i])); end
    end

    bin_of = [ansBXY[i,1] for i in 1:itemNum]
    sorted_idx = sortperm(bin_of)
    final_result = zeros(Int, itemNum, 2)
    for (pos, i) in enumerate(sorted_idx)
        final_result[pos, 1] = result[i, 1]
        final_result[pos, 2] = result[i, 2]
    end

    wasted_space = 0
    return boxes_dict, ansBXY, ran, bin_num, final_result, rotated, wasted_space
end

function fast_packing_algorithm(items::Vector{PackingItem}, bin_width::Int, bin_height::Int)
    items = shuffle(items)
    J = length(items)
    Item_matrix = zeros(Int, J, 2)
    for (idx, item) in enumerate(items)
        Item_matrix[idx,1] = item.width; Item_matrix[idx,2] = item.height
    end
    ran = shuffle(1:J)
    boxes_dict, ansBXY, ran_out, BinNum, result, rotated, wasted_space =
        skyline_bf_packing_v2(Item_matrix, ran, bin_width, bin_height)
    bins = PackingBin[]
    for bin_id in 1:BinNum
        bin = PackingBin(bin_width, bin_height)
        for i in 1:size(ansBXY,1)
            if ansBXY[i,1] == bin_id
                item_id = ansBXY[i,2]; w = ansBXY[i,3]; h = ansBXY[i,4]
                x = ansBXY[i,5]; y = ansBXY[i,6]
                item = PackingItem(item_id, w, h)
                place_item!(bin, item, (x, y))
            end
        end
        push!(bins, bin)
    end
    bins
end

function print_bins(bins::Vector{PackingBin})
    result = []
    for (i, bin) in enumerate(bins)
        for (item, position) in bin.items
            push!(result, [item.id, i])
        end
    end
    result
end

calculate_utilization(placed, pallet_width, pallet_height) =
    sum(p[4]*p[5] for p in placed) / (pallet_width * pallet_height)

const packing_algorithm = skyline_bf_packing_v2
const Item = PackingItem
const Bin = PackingBin

# ============================================================
# packing_with_seq.jl - 带序列的装箱
# ============================================================
function packing_by_sequence(items, seq, WW::Int, HH::Int)
    J = length(items)
    if isempty(seq)
        return fast_packing_algorithm(items, WW, HH)
    else
        return custom_packing_algorithm(items, seq, WW, HH)
    end
end

function custom_packing_algorithm(items, seq, WW::Int, HH::Int)
    J = length(items)
    Item_matrix = zeros(Int, J, 2)
    for (idx, item) in enumerate(items)
        Item_matrix[idx, 1] = item.width
        Item_matrix[idx, 2] = item.height
    end
    boxes_dict, ansBXY, ran_out, BinNum, result, rotated, wasted_space =
        skyline_bf_packing_v2(Item_matrix, seq, WW, HH)
    bins = Bin[]
    for bin_id in 1:BinNum
        bin = Bin(WW, HH)
        for i in 1:size(ansBXY, 1)
            if ansBXY[i, 1] == bin_id
                item_id = ansBXY[i, 2]
                w = ansBXY[i, 3]
                h = ansBXY[i, 4]
                x = ansBXY[i, 5]
                y = ansBXY[i, 6]
                item = PackingItem(item_id, w, h)
                place_item!(bin, item, (x, y))
            end
        end
        push!(bins, bin)
    end
    return bins
end

# ============================================================
# makespan.jl - 完工时间计算
# ============================================================
function makespan(p, G, W, mold_to_groups, group_to_mold, sequence_chromosome, ptr_time)
    phase2_complete_global = 0.0
    phase3_finish = zeros(Float64, G)
    ct = zeros(Float64, G)

    for g in sequence_chromosome
        if g < 1 || g > G
            continue
        end

        mold = group_to_mold[g]
        mold_groups_list = mold_to_groups[mold]
        g_idx_in_mold = findfirst(==(g), mold_groups_list)

        if g_idx_in_mold == 1
            phase1_start = 0.0
        else
            prev_group = mold_groups_list[g_idx_in_mold - 1]
            phase1_start = phase3_finish[prev_group]
        end

        phase1_complete = phase1_start + p[g, 1]
        phase2_start = max(phase1_complete, phase2_complete_global)
        phase2_complete = phase2_start + p[g, 2]
        phase2_complete_global = phase2_complete
        phase3_complete = phase2_complete + p[g, 3]
        phase3_finish[g] = phase3_complete
        ct[g] = phase3_complete + ptr_time
    end

    C = zeros(Float64, W)
    for mold in 1:W
        if haskey(mold_to_groups, mold) && !isempty(mold_to_groups[mold])
            C[mold] = maximum(ct[g] for g in mold_to_groups[mold])
        end
    end

    MK = maximum(C)
    return ct, C, MK
end

# ============================================================
# TWT.jl - 总延迟惩罚计算
# ============================================================
function TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, tal_sol, v_result, ptr_time; verbose::Bool=false)
    ct, C, MK = makespan(p, G, W, mold_to_groups, group_to_mold, tal_sol, ptr_time)

    if isempty(ct) || any(isnan, ct) || any(isinf, ct)
        return Inf
    end

    ct_jobs = zeros(Int64, J)
    for pair in v_result
        job_id = pair[1]
        group_id = pair[2]
        if group_id <= length(ct)
            ct_jobs[job_id] = Int(ct[group_id])
        end
    end

    T = zeros(Int64, J)
    late_jobs = 0
    total_delay = 0
    for j in 1:J
        T[j] = ct_jobs[j] - d[j]
        if T[j] < 0
            T[j] = 0
        else
            late_jobs += 1
            total_delay += T[j]
        end
    end

    del_punish = sum(beta[j] * T[j] for j in 1:J)
    return del_punish
end

# ============================================================
# 组分配局部搜索 - mold_assignment_local_search.jl
# 在贪婪分配后进行局部搜索优化组分配
# ============================================================
function mold_assignment_local_search!(
    group_to_mold,
    mold_to_groups,
    mold_load,
    p,
    G,
    W_num,
    beta,
    d,
    J,
    v_result,
    ptr_time;
    max_iterations::Int=50
)
    if G < 2 || W_num < 2
        return
    end
    
    # 生成初始序列用于TWT计算（使用恒等映射）
    initial_seq = collect(1:G)
    
    # 计算初始TWT
    current_twt = TWT(beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, reshape(initial_seq, 1, length(initial_seq)), v_result, ptr_time)
    
    for iter in 1:max_iterations
        improved = false
        
        # 遍历每个组，尝试移动到其他模台
        for g in 1:G
            current_mold = group_to_mold[g]
            
            # 尝试移动到其他每个模台
            for target_mold in 1:W_num
                if target_mold == current_mold
                    continue
                end
                
                # 临时执行移动
                old_mold = current_mold
                
                # 更新group_to_mold
                group_to_mold[g] = target_mold
                
                # 更新mold_to_groups - 确保目标key存在
                if !haskey(mold_to_groups, old_mold)
                    mold_to_groups[old_mold] = []
                end
                filter!(x -> x != g, mold_to_groups[old_mold])
                if !haskey(mold_to_groups, target_mold)
                    mold_to_groups[target_mold] = []
                end
                push!(mold_to_groups[target_mold], g)
                
                # 更新mold_load
                mold_load[old_mold] -= p[g, 1]
                mold_load[target_mold] += p[g, 1]
                
                # 计算移动后的TWT
                new_twt = TWT(beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, reshape(initial_seq, 1, length(initial_seq)), v_result, ptr_time)
                
                if new_twt < current_twt - 1e-6  # 有改进
                    current_twt = new_twt  # 更新当前最优值
                    improved = true
                    # 保持这个移动
                else
                    # 回滚移动
                    group_to_mold[g] = old_mold
                    if !haskey(mold_to_groups, target_mold)
                        mold_to_groups[target_mold] = []
                    end
                    filter!(x -> x != g, mold_to_groups[target_mold])
                    if !haskey(mold_to_groups, old_mold)
                        mold_to_groups[old_mold] = []
                    end
                    push!(mold_to_groups[old_mold], g)
                    mold_load[old_mold] += p[g, 1]
                    mold_load[target_mold] -= p[g, 1]
                end
            end
        end
        
        if !improved
            break  # 没有改进，停止搜索
        end
    end
end

# ============================================================
# mutation.jl - 变异操作
# ============================================================
function swap_mutation(seq_chromosome, alloc_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]
        alloc_chromosome[i], alloc_chromosome[j] = alloc_chromosome[j], alloc_chromosome[i]
    end
    return seq_chromosome, alloc_chromosome
end

function swap_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]
    end
    return seq_chromosome
end

function insert_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_elem = splice!(seq_chromosome, i)[1]
        insert!(seq_chromosome, j, seq_elem)
    end
    return seq_chromosome
end

function reverse_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = sort(rand(1:n, 2))
    if i != j
        seq_chromosome[i:j] = reverse(seq_chromosome[i:j])
    end
    return seq_chromosome
end

# ============================================================
# VNS.jl - 变邻域搜索
# ============================================================
function VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_chromosome)
    if G < 2
        TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)
        return copy(seq_chromosome), TWT_VALUE
    end

    k = 1
    TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)

    best_seq_chromosome = copy(seq_chromosome)
    new_seq_chromosome = copy(seq_chromosome)

    while k <= 3
        if k == 1
            new_seq_chromosome = swap_mutation1(copy(best_seq_chromosome))
        elseif k == 2
            new_seq_chromosome = insert_mutation1(copy(best_seq_chromosome))
        else
            new_seq_chromosome = reverse_mutation1(copy(best_seq_chromosome))
        end

        new_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_chromosome, 1, length(new_seq_chromosome)), v_result, ptr_time)

        if new_TWT < TWT_VALUE
            TWT_VALUE = new_TWT
            best_seq_chromosome = copy(new_seq_chromosome)
            k = 1
        else
            k += 1
        end
    end
    return best_seq_chromosome, TWT_VALUE
end

# ============================================================
# NEH_TWT.jl - NEH构造方法
# ============================================================
function NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    if G < 2
        if G == 1
            sol_NEH = [1]
        else
            return [1, 2], 0
        end
        TWT_sol = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH, 1, length(sol_NEH)), v_result, ptr_time)
        return reshape(sol_NEH, 1, length(sol_NEH)), TWT_sol
    end

    PT = sum(p, dims=2)
    PT1 = PT[:, 1]
    sol3 = sortperm(PT1)

    sol_prime = Int[]
    for i in 1:G
        push!(sol_prime, sol3[i])
    end

    sol_NEH = zeros(Int, 2)
    sol_NEH[1] = sol_prime[1]
    sol_NEH[2] = sol_prime[2]

    TWT_sol_NEH = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH, 1, length(sol_NEH)), v_result, ptr_time)

    sol_NEH2 = zeros(Int, 2)
    sol_NEH2[1] = sol_prime[2]
    sol_NEH2[2] = sol_prime[1]

    TWT_sol_NEH2 = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH2, 1, length(sol_NEH2)), v_result, ptr_time)

    if TWT_sol_NEH2 < TWT_sol_NEH
        sol_NEH = sol_NEH2
        TWT_sol_NEH = TWT_sol_NEH2
    end

    for k in 3:G
        Seq = zeros(Int64, k, k)
        TWT_Seq = zeros(Int64, k)

        for i in 1:k
            New_sol_NEH = zeros(Int64, length(sol_NEH))
            for u in 1:length(sol_NEH)
                New_sol_NEH[u] = sol_NEH[u]
            end
            insert!(New_sol_NEH, i, sol_prime[k])
            Seq[i, :] = New_sol_NEH
            TWT_Seq[i] = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(New_sol_NEH, 1, length(New_sol_NEH)), v_result, ptr_time)
        end

        min_val, best_index = findmin(TWT_Seq)
        sol_NEH = zeros(Int, k)
        sol_NEH = Seq[best_index, :]
        TWT_sol_NEH = min_val
    end

    return reshape(sol_NEH, 1, length(sol_NEH)), TWT_sol_NEH
end

# ============================================================
# Destruction_operators.jl - ALNS销毁操作符
# D1: 随机移除若干组，增强分散扰动
# D2: 连续区段移除，打破局部相邻顺序结构
# ============================================================
function D1_destruct(sol::Vector{Int}, d::Int)
    n = length(sol)
    d = min(d, n)

    if n == 0 || d == 0
        return Int[], Int[]
    end

    remove_idx = randperm(n)[1:d]
    sort!(remove_idx)
    removed = sol[remove_idx]
    remaining = deleteat!(copy(sol), remove_idx)

    return remaining, removed
end

function D2_block_destruct(sol::Vector{Int}, d::Int)
    n = length(sol)
    d = min(d, n)

    if n == 0 || d == 0
        return Int[], Int[]
    end

    start_idx = rand(1:(n - d + 1))
    remove_idx = start_idx:(start_idx + d - 1)
    removed = sol[collect(remove_idx)]
    remaining = deleteat!(copy(sol), collect(remove_idx))

    return remaining, removed
end

const DESTRUCTION_OPERATORS = [D1_destruct, D2_block_destruct]
const DESTRUCTION_NAMES = ["D1_random", "D2_block"]

function select_destruction_operator(probabilities::Vector{Float64})
    r = rand()
    cum_prob = 0.0

    for (i, p) in enumerate(probabilities)
        cum_prob += p
        if r <= cum_prob
            return DESTRUCTION_OPERATORS[i], i
        end
    end

    return DESTRUCTION_OPERATORS[end], length(probabilities)
end

# ============================================================
# Repair_operators.jl - ALNS修复操作符
# ============================================================
function perturb_mold_assignment!(mold_to_groups, group_to_mold, mold_load, p, G, W_num; prob=0.3, max_perturb=2)
    if G < 2 || W_num < 2
        return
    end

    if rand() > prob
        return
    end

    perturb_count = rand(1:min(max_perturb, G))
    groups_to_move = randperm(G)[1:perturb_count]

    for g in groups_to_move
        old_mold = group_to_mold[g]
        possible_molds = filter(m -> m != old_mold, 1:W_num)
        if isempty(possible_molds)
            continue
        end

        new_mold = rand(possible_molds)
        group_to_mold[g] = new_mold
        filter!(x -> x != g, mold_to_groups[old_mold])
        push!(mold_to_groups[new_mold], g)
        mold_load[old_mold] -= p[g, 1]
        mold_load[new_mold] += p[g, 1]
    end
end

function R1_repair(removed::Vector{Int}, remaining::Vector{Int},
                   beta, d, p, J, G, W, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time)

    sol_Prime = copy(remaining)
    n1 = length(sol_Prime)
    d_para = length(removed)

    for k in 1:d_para
        TWT_Seq = zeros(n1 + k)

        for i in 1:(n1 + k)
            New_sol = [sol_Prime[j] for j in 1:length(sol_Prime)]
            insert!(New_sol, i, removed[k])
            TWT_Seq[i] = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold,
                             reshape(New_sol, 1, length(New_sol)), v_result, ptr_time)
        end

        min_val, best_index = findmin(TWT_Seq)
        sol_Prime = insert!(sol_Prime, best_index, removed[k])
    end

    perturb_mold_assignment!(mold_to_groups, group_to_mold, mold_load, p, G, W, prob=0.3, max_perturb=2)

    return sol_Prime
end

function R2_repair(removed::Vector{Int}, remaining::Vector{Int},
                   beta, d, p, J, G, W, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time)

    sol_Prime = copy(remaining)
    n1 = length(sol_Prime)
    d_para = length(removed)

    removed_shuffled = shuffle(removed)

    for k in 1:d_para
        insert_pos = rand(1:(n1 + k))
        sol_Prime = insert!(sol_Prime, insert_pos, removed_shuffled[k])
    end

    perturb_mold_assignment!(mold_to_groups, group_to_mold, mold_load, p, G, W, prob=0.3, max_perturb=2)

    return sol_Prime
end

const REPAIR_OPERATORS = [R1_repair, R2_repair]
const REPAIR_NAMES = ["R1_greedy", "R2_random"]

function select_repair_operator(probabilities::Vector{Float64})
    r = rand()
    cum_prob = 0.0

    for (i, p) in enumerate(probabilities)
        cum_prob += p
        if r <= cum_prob
            return REPAIR_OPERATORS[i], i
        end
    end

    return REPAIR_OPERATORS[end], length(probabilities)
end

# ============================================================
# ALNS.jl - 自适应大邻域搜索
# ============================================================
const DEFAULT_SIGMA1 = 15.0
const DEFAULT_SIGMA2 = 10.0
const DEFAULT_SIGMA3 = 2.0
const DEFAULT_REACTION_FACTOR = 0.2

function get_sigma1()
    if @isdefined(sigma1_tuning)
        return sigma1_tuning
    else
        return DEFAULT_SIGMA1
    end
end

function get_sigma2()
    if @isdefined(sigma2_tuning)
        return sigma2_tuning
    else
        return DEFAULT_SIGMA2
    end
end

function get_sigma3()
    if @isdefined(sigma3_tuning)
        return sigma3_tuning
    else
        return DEFAULT_SIGMA3
    end
end

function get_reaction_factor()
    if @isdefined(reaction_factor_tuning)
        return reaction_factor_tuning
    else
        return DEFAULT_REACTION_FACTOR
    end
end

function update_scores!(destroy_scores::Vector{Float64}, repair_scores::Vector{Float64},
                        destroy_idx::Int, repair_idx::Int,
                        new_cost, current_cost, best_cost)

    sigma1 = get_sigma1()
    sigma2 = get_sigma2()
    sigma3 = get_sigma3()

    new_cost = Float64(new_cost)
    current_cost = Float64(current_cost)
    best_cost = Float64(best_cost)

    if new_cost < best_cost
        destroy_scores[destroy_idx] += sigma1
        repair_scores[repair_idx] += sigma1
    elseif new_cost < current_cost
        destroy_scores[destroy_idx] += sigma2
        repair_scores[repair_idx] += sigma2
    else
        destroy_scores[destroy_idx] += sigma3
        repair_scores[repair_idx] += sigma3
    end
end

function update_probabilities!(probabilities::Vector{Float64}, scores::Vector{Float64},
                               reaction_factor::Float64=get_reaction_factor())
    n = length(probabilities)
    total_score = sum(scores)

    if total_score > 0
        new_probs = scores ./ total_score
        probabilities[:] = reaction_factor .* new_probs .+ (1 - reaction_factor) .* probabilities
    end

    prob_sum = sum(probabilities)
    if prob_sum > 0
        probabilities[:] = probabilities ./ prob_sum
    else
        probabilities[:] = fill(1.0/n, n)
    end

    for i in 1:n
        probabilities[i] = max(0.01, min(0.99, probabilities[i]))
    end

    probabilities[:] = probabilities ./ sum(probabilities)
end

function alns(max_iteration, d_para, T_para, alpha_cooling,
              beta, d, p, J, G, W, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time, time_limit)

    if G < 2
        if G == 1
            tal_sol_best = [1]
        else
            tal_sol_best = [1, 2]
        end
        TWT_sol_best = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold,
                           reshape(tal_sol_best, 1, length(tal_sol_best)), v_result, ptr_time)
        return tal_sol_best, TWT_sol_best
    end

    Temp = T_para * sum(p) / (10 * J * G)

    n_destroy = length(DESTRUCTION_OPERATORS)
    n_repair = length(REPAIR_OPERATORS)

    destroy_probs = fill(1.0/n_destroy, n_destroy)
    repair_probs = fill(1.0/n_repair, n_repair)

    destroy_scores = fill(1.0, n_destroy)
    repair_scores = fill(1.0, n_repair)

    tal_sol_0, tal_sol_TWT_0 = NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    tal_sol_0_vec = ndims(tal_sol_0) == 2 ? vec(tal_sol_0) : tal_sol_0

    tal_sol_0_vec, TWT_sol_0 = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, tal_sol_0_vec)

    tal_sol_best = copy(tal_sol_0_vec)
    TWT_sol_best = copy(TWT_sol_0)

    tal_sol_curr = copy(tal_sol_0_vec)
    TWT_sol_curr = copy(TWT_sol_0)

    iteration = 0
    segment_size = max_iteration ÷ 5
    start_time = time()

    while time() - start_time < time_limit
        destroy_func, destroy_idx = select_destruction_operator(destroy_probs)
        repair_func, repair_idx = select_repair_operator(repair_probs)

        remaining, removed = destroy_func(tal_sol_curr, d_para)

        tal_sol_prime = repair_func(removed, remaining, beta, d, p, J, G, W,
                                   mold_to_groups, group_to_mold, mold_load, v_result, ptr_time)
        TWT_prime = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold,
                        reshape(tal_sol_prime, 1, length(tal_sol_prime)), v_result, ptr_time)

        remaining_time = time_limit - (time() - start_time)
        tal_sol_prime, TWT_prime = VNS(beta, d, p, J, G, W,
                                        mold_to_groups, group_to_mold, v_result, ptr_time, tal_sol_prime)

        g = rand()
        sa = exp(-(TWT_sol_curr - TWT_prime) / Temp)

        accepted = false
        if TWT_prime < TWT_sol_curr
            accepted = true
        elseif g <= sa
            accepted = true
        end

        if accepted
            tal_sol_curr = tal_sol_prime
            TWT_sol_curr = TWT_prime

            if TWT_sol_curr < TWT_sol_best
                tal_sol_best = tal_sol_curr
                TWT_sol_best = TWT_sol_curr
            end
        end

        update_scores!(destroy_scores, repair_scores, destroy_idx, repair_idx,
                      TWT_prime, TWT_sol_curr, TWT_sol_best)

        if (iteration + 1) % segment_size == 0 || iteration == max_iteration - 1
            update_probabilities!(destroy_probs, destroy_scores, get_reaction_factor())
            update_probabilities!(repair_probs, repair_scores, get_reaction_factor())
        end

        Temp = alpha_cooling * Temp

        iteration += 1
    end

    return tal_sol_best, TWT_sol_best
end

# ============================================================
# yunshu.jl - 车辆分配优化
# ============================================================
# ===================================================================
# VLSP: Vehicle Loading Subproblem (MILP, per-group)
# Implements the model described in the paper (Section MILP-LT)
# ===================================================================

"""
    VLSP(group_jobs, all_weights, rho, Q; time_limit=60.0, verbose=false)

Per-group vehicle loading subproblem MILP model.

# Returns
- `(total_cost, vehicle_count, assignment_vector)` where assignment_vector[i]
  is the vehicle index (1-based) for the i-th job in group_jobs.
"""
function VLSP(group_jobs::Vector{Int}, all_weights, rho, Q;
              time_limit::Float64=60.0, verbose::Bool=false)
    n_jobs = length(group_jobs)
    if n_jobs == 0
        return 0.0, 0, Int[]
    end
    weights = Float64[all_weights[j] for j in group_jobs]
    min_vehicles = ceil(Int, sum(weights) / Q)
    V = min(n_jobs, min_vehicles + 3)
    model = Model(Gurobi.Optimizer)
    if verbose
        println("    [VLSP] 组内作业数=$n_jobs, 车辆上限=$V, 最小所需车辆=$min_vehicles")
        println("    [VLSP] 组内总重量=$(round(sum(weights), digits=2)), ρ=$rho, Q=$Q")
    end
    @variable(model, X[j=1:n_jobs, v=1:V], Bin)
    @variable(model, γ[v=1:V], Bin)
    @objective(model, Min, sum(rho * γ[v] for v in 1:V))
    @constraint(model, [j in 1:n_jobs], sum(X[j, v] for v in 1:V) == 1)
    @constraint(model, [j in 1:n_jobs, v in 1:V], X[j, v] <= γ[v])
    @constraint(model, [v in 1:V], sum(weights[j] * X[j, v] for j in 1:n_jobs) <= Q * γ[v])
    for vv in 2:V
        @constraint(model, γ[vv] <= γ[vv-1])
    end
    set_optimizer_attribute(model, "OutputFlag", 0)
    set_time_limit_sec(model, time_limit)
    set_silent(model)
    optimize!(model)
    status = termination_status(model)
    if status == OPTIMAL || status == TIME_LIMIT || status == FEASIBLE_POINT
        v_cost = objective_value(model)
        vehicle_count = sum(value(γ[v]) for v in 1:V) |> value |> Int
        assignment_vector = zeros(Int, n_jobs)
        X_val = value.(X)
        for j in 1:n_jobs
            for v in 1:V
                if X_val[j, v] > 0.5
                    assignment_vector[j] = v
                    break
                end
            end
        end
        return v_cost, vehicle_count, assignment_vector
    else
        if verbose
            println("    [VLSP] 警告: 求解状态=$(status)")
        end
        return Inf, 0, zeros(Int, n_jobs)
    end
end

# Backward-compatible wrapper
function yunshu(J, W, wg, rho, Q; verbose::Bool=false)
    time_limit = W > 0 ? J * W * 0.02 : 60.0
    total_cost, vehicle_count, assignment_vector = VLSP(
        collect(1:J), wg, rho, Q; time_limit=time_limit, verbose=verbose)
    return total_cost, vehicle_count, assignment_vector
end

# ============================================================
# perturb_seq.jl - 序列扰动
# ============================================================
function perturb_sequence(seq; stagnate_limit::Int=5)
    if isempty(seq)
        return seq
    end

    n = length(seq)
    if n < 2
        return seq
    end

    idxs = shuffle(1:n)
    i, j = idxs[1], idxs[2]
    new_seq = copy(seq)
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    return new_seq
end

"""
    is_similar_item(item1, item2; δ_w=0.1, δ_h=0.1)

判断两个工件是否几何相似。
"""
function is_similar_item(item1, item2; δ_w::Float64=0.1, δ_h::Float64=0.1)
    w1, h1 = item1
    w2, h2 = item2
    return abs(w1 - w2) < δ_w && abs(h1 - h2) < δ_h
end

"""
    find_similar_pairs(seq, w, h; δ_w=0.1, δ_h=0.1)

在序列中查找所有几何相似工件对。
"""
function find_similar_pairs(seq, w, h; δ_w::Float64=0.1, δ_h::Float64=0.1)
    n = length(seq)
    similar_pairs = Vector{Tuple{Int, Int}}()
    for i in 1:n
        for j in (i+1):n
            job_i = seq[i]
            job_j = seq[j]
            item_i = (w[job_i], h[job_i])
            item_j = (w[job_j], h[job_j])
            if is_similar_item(item_i, item_j; δ_w=δ_w, δ_h=δ_h)
                push!(similar_pairs, (i, j))
            end
        end
    end
    return similar_pairs
end

"""
    neighborhood_perturb(seq, w, h, WW, HH)

基于邻域搜索的布局序列扰动。
"""
function neighborhood_perturb(seq, w, h, WW, HH; δ_w::Float64=0.1, δ_h::Float64=0.1)
    if isempty(seq)
        return seq, false
    end
    n = length(seq)
    if n < 2
        return seq, false
    end
    similar_pairs = find_similar_pairs(seq, w, h; δ_w=δ_w, δ_h=δ_h)
    if isempty(similar_pairs)
        return seq, false
    end
    i, j = rand(similar_pairs)
    new_seq = copy(seq)
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    items = [PackingItem(idx, wi, hi) for (idx, (wi, hi)) in enumerate(zip(w, h))]
    bins = packing_by_sequence(items, new_seq, WW, HH)
    if length(bins) > 0
        return new_seq, true
    end
    return seq, false
end

"""
    perturb_layout_sequence(seq, w, h, WW, HH; max_attempts=10)

布局序列扰动操作。
"""
function perturb_layout_sequence(seq, w, h, WW, HH; max_attempts::Int=10)
    if isempty(seq)
        return seq, false
    end
    n = length(seq)
    if n < 2
        return seq, false
    end
    for attempt in 1:max_attempts
        new_seq = copy(seq)
        success = false
        if attempt == 1
            new_seq, success = neighborhood_perturb(seq, w, h, WW, HH)
            if success
                return new_seq, true
            end
        end
        idxs = shuffle(1:n)
        i, j = idxs[1], idxs[2]
        new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
        items = [PackingItem(idx, wi, hi) for (idx, (wi, hi)) in enumerate(zip(w, h))]
        bins = packing_by_sequence(items, new_seq, WW, HH)
        if length(bins) > 0
            return new_seq, true
        end
    end
    return seq, false
end

# ============================================================
# BF_ALNS 主函数
# ============================================================
function BF_ALNS(J, W_num, w, h, pt, d, beta, ptr_time, wg, tal_seq, WW, HH, rho, Q, α)
    items = [Item(i, wi, hi) for (i, (wi, hi)) in zip(1:length(w), zip(w, h))]
    
    bins = packing_by_sequence(items, tal_seq, WW, HH)
    
    v_result = print_bins(bins)

    G = length(bins)

    bin_to_jobs = Dict{Int, Vector{Int}}()
    for pair in v_result
        job_id = pair[1]
        bin_id = pair[2]
        if haskey(bin_to_jobs, bin_id)
            push!(bin_to_jobs[bin_id], job_id)
        else
            bin_to_jobs[bin_id] = [job_id]
        end
    end

    p = zeros(G, 4)

    for (bin_id, jobs) in bin_to_jobs
        p1 = []
        p3 = []
        for j in jobs
            p[bin_id, 2] += pt[j, 2]
            push!(p1, pt[j, 1])
            push!(p3, pt[j, 3])
        end
        p[bin_id, 1] = maximum(p1)
        p[bin_id, 3] = maximum(p3)
    end

    p[:, 4] .= ptr_time

    group_to_mold = Dict{Int, Int}()
    mold_to_groups = Dict{Int, Vector{Int}}()
    mold_load = zeros(W_num)

    sorted_bins = sortperm([p[bin_id, 1] for bin_id in 1:G])

    for bin_id in sorted_bins
        lightest_mold = argmin(mold_load)
        group_to_mold[bin_id] = lightest_mold
        if haskey(mold_to_groups, lightest_mold)
            push!(mold_to_groups[lightest_mold], bin_id)
        else
            mold_to_groups[lightest_mold] = [bin_id]
        end
        mold_load[lightest_mold] += p[bin_id, 1]
    end

    # 组分配局部搜索优化（贪婪分配后）
    mold_assignment_local_search!(
        group_to_mold, mold_to_groups, mold_load, p, G, W_num,
        beta, d, J, v_result, ptr_time
    )

    max_iteration = maxIter_tuning
    d_para = d_para_tuning
    T_para = T_para_tuning
    alpha_cooling = alpha_cooling_tuning

    alns_time_limit = J * W_num * 0.02

    tal_sol_best, tardiness_cost = alns(max_iteration, d_para, T_para, alpha_cooling, beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, mold_load, v_result, ptr_time, alns_time_limit)
    tal_sol_best = ndims(tal_sol_best) == 2 ? vec(tal_sol_best) : tal_sol_best

    # Per-group VLSP: solve vehicle loading subproblem for each group independently
    total_v_cost = 0.0
    job_to_vehicle = zeros(Int, J)
    global_vehicle_counter = 0
    for group_id in sort(collect(keys(bin_to_jobs)))
        group_jobs = bin_to_jobs[group_id]
        group_time_limit = length(group_jobs) * W_num * 0.02
        g_cost, g_vehicles, g_assignment = VLSP(group_jobs, wg, rho, Q; time_limit=group_time_limit, verbose=false)
        total_v_cost += g_cost
        for (idx, job_id) in enumerate(group_jobs)
            job_to_vehicle[job_id] = g_assignment[idx] + global_vehicle_counter
        end
        global_vehicle_counter += g_vehicles
    end
    v_result_with_vehicle = [[pair[1], pair[2], job_to_vehicle[pair[1]]] for pair in v_result]

    group_activation_cost = G * α
    best_cost = total_v_cost + tardiness_cost + group_activation_cost

    return tal_sol_best, best_cost, G, tardiness_cost, v_result_with_vehicle, p, group_to_mold, mold_to_groups, total_v_cost, tardiness_cost, job_to_vehicle
end

# ============================================================
# main 函数
# ============================================================
function main(filenm)
    best_seq = []
    best_group_sequence = Int[]
    best_G = typemax(Int)
    best_cost = 1e10
    best_v_result = []
    best_p = zeros(0, 0)
    best_group_to_mold = Dict{Int, Int}()
    best_mold_to_groups = Dict{Int, Vector{Int}}()
    best_v_cost = 0.0
    best_tardiness_cost = 0.0
    best_mold_activation_cost = 0.0
    best_stats = nothing

    J = load(filenm, "JJ")
    best_job_to_vehicle = zeros(Int, J)
    W = load(filenm, "WW_num")

    WW = load(filenm, "WW")
    HH = load(filenm, "HH")
    α = load(filenm, "alpha")

    w = load(filenm, "wj")
    h = load(filenm, "hj")

    pt = load(filenm, "pp")
    d = load(filenm, "dd")
    β = load(filenm, "betabeta")
    ptr = load(filenm, "ptr")

    wg = load(filenm, "wg")

    Q = load(filenm, "Q")
    rho = load(filenm, "rho")

    items = hcat(w, h)
    max_time = J * W * 0.5
    start_time = time()

    # 先执行一次 BF_ALNS 初始化 best_seq
    init_seq = shuffle(1:J)
    result = BF_ALNS(J, W, w, h, pt, d, β, ptr, wg, init_seq, WW, HH, rho, Q, α)
    current_group_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_job_to_vehicle = result
    if current_G < best_G
        best_seq = init_seq
        best_group_sequence = current_group_seq
        best_G = current_G
        best_cost = current_cost
        best_v_result = current_v_result
        best_p = current_p
        best_group_to_mold = current_group_to_mold
        best_mold_to_groups = current_mold_to_groups
        best_v_cost = current_v_cost
        best_tardiness_cost = current_tardiness_cost
        best_mold_activation_cost = current_G * α
        best_job_to_vehicle = copy(current_job_to_vehicle)
        best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, α, best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups, best_v_cost, best_tardiness_cost, best_mold_activation_cost)
    end  # 关闭 outer "if current_G < best_G" in init block

    while time() - start_time < max_time
        if isempty(best_seq)
            perturb_seq = shuffle(1:J)
        else
            perturb_seq = copy(best_seq)
            
            perturb_seq, success = neighborhood_perturb(perturb_seq, w, h, WW, HH)
            if success
                result = BF_ALNS(J, W, w, h, pt, d, β, ptr, wg, perturb_seq, WW, HH, rho, Q, α)
                current_group_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_job_to_vehicle = result
                
                if current_G <= best_G
                    best_seq = perturb_seq
                    best_group_sequence = current_group_seq
                    best_G = current_G
                    best_cost = current_cost
                    best_v_result = current_v_result
                    best_p = current_p
                    best_group_to_mold = current_group_to_mold
                    best_mold_to_groups = current_mold_to_groups
                    best_v_cost = current_v_cost
                    best_tardiness_cost = current_tardiness_cost
                    best_mold_activation_cost = current_G * α
                    best_job_to_vehicle = copy(current_job_to_vehicle)
                    continue
                end
            end
            
            ratio = rand() * 0.1 + 0.2
            k = max(1, floor(Int, J * ratio))
            idxs = shuffle(1:J)
            swap_idxs = idxs[1:k]
            swap_vals = perturb_seq[swap_idxs]
            shuffle!(swap_vals)
            perturb_seq[swap_idxs] = swap_vals
            
            result = BF_ALNS(J, W, w, h, pt, d, β, ptr, wg, perturb_seq, WW, HH, rho, Q, α)
            current_group_seq, current_cost, current_G, _, current_v_result, current_p, current_group_to_mold, current_mold_to_groups, current_v_cost, current_tardiness_cost, current_job_to_vehicle = result
            
            if current_G <= best_G
                best_seq = perturb_seq
                best_group_sequence = current_group_seq
                best_G = current_G
                best_cost = current_cost
                best_v_result = current_v_result
                best_p = current_p
                best_group_to_mold = current_group_to_mold
                best_mold_to_groups = current_mold_to_groups
                best_v_cost = current_v_cost
                best_tardiness_cost = current_tardiness_cost
                best_mold_activation_cost = current_G * α
                best_job_to_vehicle = copy(current_job_to_vehicle)
                best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, α, best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups, best_v_cost, best_tardiness_cost, best_mold_activation_cost)
            elseif current_cost < best_cost || rand() < exp(-α * (current_G - best_G))
                best_seq = perturb_seq
                best_group_sequence = current_group_seq
                best_G = current_G
                best_cost = current_cost
                best_v_result = current_v_result
                best_p = current_p
                best_group_to_mold = current_group_to_mold
                best_mold_to_groups = current_mold_to_groups
                best_v_cost = current_v_cost
                best_tardiness_cost = current_tardiness_cost
                best_mold_activation_cost = current_G * α
                best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, α, best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups, best_v_cost, best_tardiness_cost, best_mold_activation_cost)
            end
        end
    end

    run_time = time() - start_time

    if best_stats === nothing && !isempty(best_seq)
        best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho, α,
            best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
            best_v_cost, best_tardiness_cost, best_mold_activation_cost)
    end

    result = (run_time, best_seq, best_cost, best_G,
              best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
              best_v_cost, best_tardiness_cost, best_mold_activation_cost, best_job_to_vehicle, best_stats)

    return result
end

# ============================================================
# 结果统计
# ============================================================
function build_solution_statistics(J, W, WW, HH, w, h, d, beta, rho, α,
    best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
    best_v_cost, best_tardiness_cost, mold_activation_cost)

    mold_area = WW * HH
    group_jobs = Dict{Int, Vector{Int}}()
    for item in best_v_result
        if item isa AbstractVector && length(item) >= 2
            job_id = item[1]
            group_id = item[2]
        else
            continue
        end
        if !haskey(group_jobs, group_id)
            group_jobs[group_id] = Int[]
        end
        push!(group_jobs[group_id], job_id)
    end

    mold_utilization = Dict{Int, Float64}()
    group_utilization = Dict{Int, Float64}()
    for (group_id, jobs) in group_jobs
        used_area = sum(w[j] * h[j] for j in jobs)
        group_utilization[group_id] = mold_area > 0 ? used_area / mold_area : 0.0
    end
    for mold in 1:W
        group_ids = get(best_mold_to_groups, mold, Int[])
        mold_utilization[mold] = isempty(group_ids) ? 0.0 : mean(get(group_utilization, group_id, 0.0) for group_id in group_ids)
    end

    vehicle_assignments = Dict{Int, Int}()
    if best_v_result isa AbstractVector
        for item in best_v_result
            if item isa AbstractVector && length(item) >= 3
                job_id = item[1]
                vehicle_id = item[3]
                if vehicle_id isa Number && vehicle_id > 0
                    vehicle_assignments[job_id] = Int(vehicle_id)
                end
            end
        end
    end

    vehicle_count = length(filter(!iszero, unique(values(vehicle_assignments))))

    tardy_jobs = Vector{NamedTuple{(:job_id, :completion_time, :due_date, :tardiness, :penalty), Tuple{Int, Float64, Float64, Float64, Float64}}}()

    G = size(best_p, 1)
    if !isempty(best_group_sequence) && !isempty(best_p) && !isempty(best_group_to_mold) && !isempty(best_mold_to_groups)
        seq_vec = best_group_sequence isa AbstractVector ? collect(best_group_sequence) : vec(best_group_sequence)
        ct, _, _ = makespan(best_p, G, W, best_mold_to_groups, best_group_to_mold, seq_vec, best_p[1, 4])

        for j in 1:J
            group_id = get(Dict(pair[1] => pair[2] for pair in best_v_result), j, 0)
            completion_time = ct[group_id]
            tardiness = max(completion_time - d[j], 0.0)
            penalty = beta[j] * tardiness
            if tardiness > 1e-6
                push!(tardy_jobs, (
                    job_id = j,
                    completion_time = completion_time,
                    due_date = d[j],
                    tardiness = tardiness,
                    penalty = penalty,
                ))
            end
        end
    end

    total_tardy_penalty = sum(item.penalty for item in tardy_jobs)

    return (
        mold_utilization = mold_utilization,
        group_utilization = group_utilization,
        average_mold_utilization = isempty(group_utilization) ? 0.0 : mean(values(group_utilization)),
        vehicle_count = vehicle_count,
        vehicle_cost = best_v_cost,
        mold_activation_cost = mold_activation_cost,
        tardy_jobs = tardy_jobs,
        total_tardy_penalty = total_tardy_penalty,
    )
end

function print_solution_statistics(stats, G, α)
    println("  工件组面积利用率:")
    for group_id in sort(collect(keys(stats.group_utilization)))
        println("    工件组 $(group_id): $(round(stats.group_utilization[group_id] * 100, digits=2))%")
    end
    println("  平均工件组面积利用率 = $(round(stats.average_mold_utilization * 100, digits=2))%")
    println("  使用车辆数量 = $(stats.vehicle_count)")
    println("  拖期工件数量 = $(length(stats.tardy_jobs))")
    println("  总拖期费用 = $(round(stats.total_tardy_penalty, digits=2))")

    println("\n  成本分解:")
    println("    车辆成本 (vehicle_cost) = $(round(stats.vehicle_cost, digits=2))")
    println("    拖期惩罚 (tardiness_cost) = $(round(stats.total_tardy_penalty, digits=2))")
    println("    模台激活成本 (mold_activation_cost) = $(round(stats.mold_activation_cost, digits=2)) (G=$G, α=$α)")
    println("    总成本 = $(round(stats.vehicle_cost + stats.total_tardy_penalty + stats.mold_activation_cost, digits=2))")

    if isempty(stats.tardy_jobs)
        println("  无拖期工件")
    else
        println("  拖期工件明细:")
        for item in stats.tardy_jobs
            println("    工件 $(item.job_id): 完工=$(round(item.completion_time, digits=2)), 交期=$(round(item.due_date, digits=2)), 拖期=$(round(item.tardiness, digits=2)), 费用=$(round(item.penalty, digits=2))")
        end
    end
end

# ============================================================
# 测试接口
# ============================================================
const SCRIPT_DIR = @__DIR__
const INSTANCE_DIR = joinpath(SCRIPT_DIR, "DATA_Instances")

function single_instance_test(filenm; num_runs=5)
    println("=" ^ 70)
    println("PRHBF-ALNS 单实例测试 (集成版)")
    println("=" ^ 70)
    println("实例文件: $(basename(filenm))")
    println("运行次数: $num_runs")
    println("=" ^ 70)

    J = load(filenm, "JJ")
    WW_num = load(filenm, "WW_num")
    WW = load(filenm, "WW")
    HH = load(filenm, "HH")
    α = load(filenm, "alpha")
    wg = load(filenm, "wg")
    Q = load(filenm, "Q")
    rho = load(filenm, "rho")

    println("\n实例参数:")
    println("  工件数 J = $J")
    println("  模台数 WW_num = $WW_num")
    println("  模台尺寸 WW × HH = $WW × $HH")
    println("  模台激活成本 α = $α")
    println("  总重量 = $(sum(wg))")
    println("  车辆载量 Q = $Q, 固定成本 ρ = $rho")
    println("  最小车辆数 = $(ceil(Int, sum(wg)/Q))")

    check_out = zeros(num_runs)
    check_time = zeros(num_runs)

    for op in 1:num_runs
        println("\n--- 第 $op/$num_runs 次运行 ---")
        try
            r = main(filenm)
            run_time, best_tal, best_cost, best_bin_num = r[1:4]
            stats = r[end]
            check_out[op] = best_cost
            check_time[op] = run_time
            println("  组数 G = $best_bin_num")
            println("  成本 = $best_cost")
            println("  运行时间 = $(round(run_time, digits=2))s")
            println("  工件序列 = $best_tal")
            if stats !== nothing
                print_solution_statistics(stats, best_bin_num, α)
            end
        catch e
            println("  错误: $e")
            check_out[op] = NaN
            check_time[op] = NaN
        end
    end

    println("\n" * "=" ^ 70)
    println("统计结果")
    println("=" ^ 70)

    valid_costs = filter(!isnan, check_out)
    valid_times = filter(!isnan, check_time)

    if !isempty(valid_costs)
        println("  成本: 最小=$(minimum(valid_costs)), 最大=$(maximum(valid_costs)), 平均=$(round(mean(valid_costs), digits=2))")
        println("  时间: 最小=$(round(minimum(valid_times), digits=2))s, 最大=$(round(maximum(valid_times), digits=2))s, 平均=$(round(mean(valid_times), digits=2))s")

        best_run_idx = argmin(valid_costs)
        best_cost = valid_costs[best_run_idx]
        vehicle_cost = ceil(Int, sum(wg)/Q) * rho

        println("\n  最佳成本分解 (第 $(findfirst(x -> x == valid_costs[best_run_idx], check_out)) 次运行):")
        println("    总成本 = $best_cost")
        println("    车辆成本 ≈ $vehicle_cost")
        println("    粗略估计其他成本 ≈ $(best_cost - vehicle_cost)")
    else
        println("  所有运行都失败了！")
    end

    println("=" ^ 70)

    return (costs=check_out, times=check_time)
end

function batch_test(; num_runs=5)
    data_dir = joinpath(@__DIR__, "DATA_Instances")
    results_dir = joinpath(@__DIR__, "results")
    if !isdir(results_dir)
        mkdir(results_dir)
    end

    timestamp = Dates.format(now(), "YYYYMMDD_HHmmss")
    output_file = joinpath(results_dir, "PRHBF_ALNS_$(timestamp).csv")

    if !isdir(data_dir)
        error("数据目录不存在: $data_dir")
    end

    local all_files = []
    direct_files = [joinpath(data_dir, f) for f in readdir(data_dir) if endswith(f, ".jld2")]
    all_files = vcat(all_files, direct_files)

    for subdir in readdir(data_dir)
        subpath = joinpath(data_dir, subdir)
        if isdir(subpath)
            files = [joinpath(subpath, f) for f in readdir(subpath) if endswith(f, ".jld2")]
            all_files = vcat(all_files, files)
        end
    end
    all_files = sort(all_files)

    println("共找到 $(length(all_files)) 个数据集文件")
    println("每个实例运行 $num_runs 次")
    println("=" ^ 70)

    results = []

    total = length(all_files)
    for (idx, filenm) in enumerate(all_files)
        println("[$idx/$total] 正在测试: $(basename(filenm))")

        check_out = zeros(num_runs)
        check_time = zeros(num_runs)
        check_vehicle_count = fill(NaN, num_runs)
        check_mold_utilization = fill(NaN, num_runs)
        check_tardy_penalty = fill(NaN, num_runs)
        check_mold_activation_cost = fill(NaN, num_runs)

        for op in 1:num_runs
            try
                r = main(filenm)
                check_out[op] = r[3]
                check_time[op] = r[1]
                stats = r[end]
                if stats !== nothing
                    check_vehicle_count[op] = stats.vehicle_count
                    check_mold_utilization[op] = stats.average_mold_utilization
                    check_tardy_penalty[op] = stats.total_tardy_penalty
                    check_mold_activation_cost[op] = stats.mold_activation_cost
                end
            catch e
                println("  错误: $e")
                check_out[op] = NaN
                check_time[op] = NaN
            end
        end

        val_cost = mean(filter(!isnan, check_out))
        val_time = mean(filter(!isnan, check_time))
        avg_vehicle_count = mean(filter(!isnan, check_vehicle_count))
        avg_mold_utilization = mean(filter(!isnan, check_mold_utilization))
        avg_tardy_penalty = mean(filter(!isnan, check_tardy_penalty))
        avg_mold_activation_cost = mean(filter(!isnan, check_mold_activation_cost))

        push!(results, (instance=basename(filenm),
            (Symbol("cost$i") => check_out[i] for i in 1:num_runs)...,
            avg_cost=val_cost, avg_time=val_time,
            (Symbol("vehicle_count$i") => check_vehicle_count[i] for i in 1:num_runs)...,
            avg_vehicle_count=avg_vehicle_count,
            (Symbol("util$i") => (isnan(check_mold_utilization[i]) ? NaN : round(Int, check_mold_utilization[i] * 100)) for i in 1:num_runs)...,
            avg_mold_utilization=(isnan(avg_mold_utilization) ? NaN : round(Int, avg_mold_utilization * 100)),
            (Symbol("tardy$i") => check_tardy_penalty[i] for i in 1:num_runs)...,
            avg_tardy_penalty=avg_tardy_penalty,
            (Symbol("mold_act_cost$i") => check_mold_activation_cost[i] for i in 1:num_runs)...,
            avg_mold_activation_cost=avg_mold_activation_cost))

        mold_util_pct = isnan(avg_mold_utilization) ? NaN : round(Int, avg_mold_utilization * 100)
        println("  -> 平均成本: $(round(val_cost, digits=2)), 平均时间: $(round(val_time, digits=2))s")
        println("     平均车辆数: $(round(avg_vehicle_count, digits=2)), 平均工件组面积利用率: $mold_util_pct%, 平均拖期惩罚: $(round(avg_tardy_penalty, digits=2)), 平均模台激活成本: $(round(avg_mold_activation_cost, digits=2))")
    end

    df = DataFrame(results)
    CSV.write(output_file, df)
    println("\n测试完成！结果已保存到: $output_file")
end

# 命令行接口
if abspath(PROGRAM_FILE) == @__FILE__
    if length(ARGS) == 0
        batch_test()
    elseif ARGS[1] == "single"
        filenm = length(ARGS) >= 2 ? ARGS[2] : joinpath(INSTANCE_DIR, "S_10_2_1.jld2")
        single_instance_test(filenm)
    elseif ARGS[1] == "batch"
        num_runs = length(ARGS) >= 2 ? parse(Int, ARGS[2]) : 5
        batch_test(; num_runs=num_runs)
    elseif ARGS[1] == "help"
        println("""
        使用方法:
          julia PRHBF_ALNS_Integrated.jl                    # 批量测试所有实例
          julia PRHBF_ALNS_Integrated.jl single              # 单实例测试 (使用默认文件)
          julia PRHBF_ALNS_Integrated.jl single <文件路径>   # 测试指定文件
          julia PRHBF_ALNS_Integrated.jl batch              # 批量测试 (默认5次/实例)
          julia PRHBF_ALNS_Integrated.jl batch <运行次数>    # 批量测试（指定运行次数）
          julia PRHBF_ALNS_Integrated.jl help                # 显示帮助信息

        示例:
          julia PRHBF_ALNS_Integrated.jl
          julia PRHBF_ALNS_Integrated.jl single
          julia PRHBF_ALNS_Integrated.jl single ../DATA_Instances/S_10_2_1.jld2
          julia PRHBF_ALNS_Integrated.jl batch
          julia PRHBF_ALNS_Integrated.jl batch 5
        """)
    else
        println("未知命令: $(ARGS[1])")
        println("输入 'julia PRHBF_ALNS_Integrated.jl help' 查看帮助")
    end
end
