using JuMP
using Gurobi
using JLD2
using CSV
using DataFrames
using Dates
using XLSX
using Statistics

# 脚本所在目录
const SCRIPT_DIR = @__DIR__

"""
    MILP求解器 - 二维装箱-批调度-运输集成优化问题
    基于 MILP_simplified.tex 模型
"""

# ==================== 数据加载 ====================
function load_instance(filepath::String)::Dict{String,Any}
    """
    从JLD2文件加载算例数据
    """
    data = JLD2.load(filepath)
    return Dict(data)
end

# ==================== MILP模型构建 ====================
function build_milp_model(data::Dict{String,Any}; time_limit::Float64 = 1800.0, output::Bool = false)
    """
    构建MILP模型

    # 参数
    - `data`: 算例数据字典
    - `time_limit`: 时间限制（秒）
    - `output`: 是否输出求解日志

    # 返回
    - `model`: JuMP模型
    - `results`: 包含求解结果的字典
    """
    # ==================== 提取数据 ====================
    J = data["JJ"]                    # 工件数量
    W = data["WW_num"]                # 模台数量上限
    G = J                             # 组数量上限（由模型决定，实际使用的组数会更少）
    V = J                             # 车辆数量上限

    WW_bin = data["WW"]               # 模台宽度尺寸
    HH_bin = data["HH"]               # 模台高度尺寸

    wj = data["wj"]                   # 工件宽度数组
    hj = data["hj"]                   # 工件高度数组
    wg = data["wg"]                   # 工件重量数组

    pp = data["pp"]                   # 加工时间矩阵 (J x 4)
    ptr = data["ptr"]                 # 运输时间

    dd = data["dd"]                   # 交货期数组
    betabeta = data["betabeta"]       # 延迟惩罚权重

    Q = data["Q"]                     # 车辆最大载重
    rho = data["rho"]                 # 车辆固定成本
    load_rate = get(data, "load_rate", 0.0)  # 单位运输成本（可能不存在，使用默认值0）

    α = data["alpha"]                 # 模台激活成本

    # Big-M 值
    M = 10^5
    # 紧凑组惩罚系数（促使模型合并工件）
    M_group = 10^8

    # 工件索引
    jobs = 1:J
    bins = 1:W
    groups = 1:G
    vehicles = 1:V

    # ==================== 创建模型 ====================
    model = Model(Gurobi.Optimizer)

    if !output
        set_silent(model)
    else
        # 启用 Gurobi 求解日志
        set_optimizer_attribute(model, "OutputFlag", 1)
    end

    set_time_limit_sec(model, time_limit)

    # ==================== 决策变量 ====================
    println("  定义决策变量...")

    # 2D装箱变量
    @variable(model, u[j=jobs, g=groups], Bin)          # 工件j分配到组g
    @variable(model, o[j=jobs], Bin)                     # 工件旋转
    @variable(model, x[j=jobs] >= 0)                     # 工件x坐标
    @variable(model, y[j=jobs] >= 0)                     # 工件y坐标
    @variable(model, pl[i=jobs, j=jobs; i != j], Bin)    # i在j左侧
    @variable(model, pu[i=jobs, j=jobs; i != j], Bin)    # i在j下方
    @variable(model, θ[g=groups], Bin)                  # 组激活
    @variable(model, δ[g=groups, w=bins], Bin)           # 组分配到模台

    # 调度变量
    @variable(model, c[g=groups, s=1:4] >= 0)           # 完成时间
    @variable(model, p[g=groups, s=1:4] >= 0)            # 加工时间（含阶段4运输时间）
    @variable(model, z[g=groups, k=groups; g != k], Bin)        # 阶段2顺序（全局）

    # 工件完成时间
    @variable(model, ct[j=jobs] >= 0)                     # 工件完成时间
    @variable(model, T[j=jobs] >= 0)                      # 延迟时间

    # 运输变量（原始 VLSP 变量 + 新增分组变量）
    @variable(model, X[j=jobs, v=vehicles], Bin)         # 工件j分配到车辆v
    @variable(model, γ[v=vehicles], Bin)                 # 车辆v激活
    @variable(model, Y[g=groups, v=vehicles], Bin)      # 组g是否分配到车辆v
    @variable(model, A[j=jobs, g=groups, v=vehicles], Bin)  # 辅助变量：线性化 u_{j,g}·Y_{g,v}

    # ==================== 目标函数 ====================
    println("  设置目标函数...")
    @objective(model, Min,
        sum(betabeta[j] * T[j] for j in jobs) +
        sum(γ[v] * rho for v in vehicles) +
        sum(θ[g] * α for g in groups)
        # 注：移除运输成本 sum(load_rate * wg[j] * X[j, v])
    )

    # ==================== 添加约束 ====================
    println("  添加模台边界约束...")
    # 约束(1)-(2): 工件不能超出模台边界
    for j in jobs
        @constraint(model, x[j] + (wj[j] * o[j] + hj[j] * (1 - o[j])) <= WW_bin + M * (1 - sum(u[j, g] for g in groups)))
        @constraint(model, y[j] + (hj[j] * o[j] + wj[j] * (1 - o[j])) <= HH_bin + M * (1 - sum(u[j, g] for g in groups)))
    end

    println("  添加工件不重叠约束...")
    # ==================== 约束(3)-(4): 工件间不重叠 ====================
    for i in jobs, j in jobs
        if i != j
            @constraint(model, x[i] + (wj[i] * o[i] + hj[i] * (1 - o[i])) <= x[j] + M * (1 - pl[i, j]))
            @constraint(model, y[i] + (hj[i] * o[i] + wj[i] * (1 - o[i])) <= y[j] + M * (1 - pu[i, j]))
        end
    end

    println("  添加相对位置约束...")
    # ==================== 约束(5): 相对位置约束 ====================
    for i in jobs, j in jobs, g in groups
        if i != j
            @constraint(model, pl[i, j] + pl[j, i] + pu[i, j] + pu[j, i] >= u[i, g] + u[j, g] - 1)
        end
    end

    println("  添加工件分配约束...")
    # ==================== 约束(6): 每个工件必须分配到一个组 ====================
    for j in jobs
        @constraint(model, sum(u[j, g] for g in groups) == 1)
    end

    println("  添加组激活约束...")
    # ==================== 约束(7): 组激活约束 ====================
    for j in jobs, g in groups
        @constraint(model, u[j, g] <= θ[g])
    end

    # ==================== 约束(8): 组激活反向约束 ====================
    for g in groups
        @constraint(model, θ[g] <= sum(u[j, g] for j in jobs))
    end

    println("  添加组-模台分配约束...")
    # ==================== 约束(9): 每组分配一个模台 ====================
    for g in groups
        @constraint(model, sum(δ[g, w] for w in bins) == θ[g])
    end

    # ==================== 约束(10): 组按顺序激活 ====================
    for g in 1:(G-1)
        @constraint(model, θ[g+1] <= θ[g])
    end

    println("  添加加工时间约束...")
    # ==================== 约束(11): 阶段1加工时间 ====================
    for g in groups, j in jobs
        @constraint(model, p[g, 1] >= pp[j, 1] * u[j, g])
    end

    # ==================== 约束(12): 阶段2加工时间 ====================
    for g in groups
        @constraint(model, p[g, 2] >= sum(pp[j, 2] * u[j, g] for j in jobs))
    end

    # ==================== 约束(13): 阶段3加工时间 ====================
    for g in groups, j in jobs
        @constraint(model, p[g, 3] >= pp[j, 3] * u[j, g])
    end

    # ==================== 约束(14): 阶段4加工时间（运输时间） ====================
    for g in groups
        @constraint(model, p[g, 4] == ptr)
    end

    println("  添加阶段1约束...")
    # ==================== 约束(14): 同一模台上的组在阶段1的顺序约束 ====================
    # 同一模台上的组不能同时进行阶段1加工，必须按浇筑顺序串行
    # 当g和k都在同一模台w上时，后浇筑的组必须等先浇筑的组完成阶段3后才能开始阶段1
    for g in groups, k in groups, w in bins
        if g != k
            # 当g和k都在同一模台w上，且g先于k浇筑（z[g,k]=1）时，k的阶段1开始时间 >= g的阶段3完成时间
            @constraint(model, c[k, 1] >= c[g, 3] + p[k, 1] - M * (3 - δ[g, w] - δ[k, w] - z[g, k]))
            # 当g和k都在同一模台w上，且k先于g浇筑（z[k,g]=1）时，g的阶段1开始时间 >= k的阶段3完成时间
            @constraint(model, c[g, 1] >= c[k, 3] + p[g, 1] - M * (3 - δ[g, w] - δ[k, w] - z[k, g]))
        end
    end

    # ==================== 约束(15): 阶段1完成时间 ====================
 
    for g in groups
        @constraint(model, c[g, 1] >= p[g, 1])
    end

    println("  添加阶段2约束...")
    # ==================== 约束(16): 阶段2顺序互斥 ====================
    for g in groups, k in groups
        if g != k
            @constraint(model, z[g, k] + z[k, g] == 1)
        end
    end

    # ==================== 约束(17): 阶段2完成时间 ====================

    for g in groups
        @constraint(model, c[g, 2] >= c[g, 1] + p[g, 2])
    end

    # # ==================== 约束(18): 阶段2顺序约束（全局） ====================
    # for g in groups, k in groups
    #     if g != k
    #         @constraint(model, c[k, 2] >= c[g, 2] + p[k, 2] - M * (1 - z[g, k]))
    #         @constraint(model, c[g, 2] >= c[k, 2] + p[g, 2] - M * z[g, k])
    #     end
    # end

    # ==================== 约束(19): 阶段2单机服务器约束 ====================
    # 同一服务器处理完作业组g后，才能处理作业组k
    # 注意：浇筑顺序是全局的，所有作业组共享一个浇筑机器
    for g in groups, k in groups
        if g != k
            # 浇筑顺序约束：如果g在k前浇筑(z[g,k]=1)，则k的开始时间不早于g的完成时间
            @constraint(model, c[k, 2] - p[k, 2] >= c[g, 2] + M * (z[g, k] - 1))
            # 如果k在g前浇筑(z[k,g]=1)，则g的开始时间不早于k的完成时间
            @constraint(model, c[g, 2] - p[g, 2] >= c[k, 2] + M * (z[k, g] - 1))
        end
    end

    println("  添加阶段3约束...")
    # ==================== 约束(20): 阶段3完成时间 ====================
    for g in groups
        @constraint(model, c[g, 3] >= c[g, 2] + p[g, 3])
    end

    # ==================== 【修改】约束(21): c[g,4] 定义 ====================
    # 每个作业组完成阶段3后独立运输，不再等待其他作业组
    for g in groups
        @constraint(model, c[g, 4] >= c[g, 3] + p[g, 4])
    end

    println("  添加组激活约束（未激活组的加工/完成时间归零）...")
    # 对应 tex 文件 eq:group_proc_activation + eq:group_completion_activation
    # 当 θ[g] = 0（组未激活）时，强制 p[g,s] = 0 且 c[g,s] = 0（s=1,2,3）
    for g in groups, s in 1:3
        @constraint(model, p[g, s] <= M * θ[g])
        @constraint(model, c[g, s] <= M * θ[g])
    end

    println("  添加工件完工时间约束...")
    # ==================== 【修改】约束(22): 工件完工时间 ====================
    # 每个作业组完成后独立运输，工件完工时间 = 阶段3完成时间 + 运输时间
    for j in jobs, g in groups
        @constraint(model, ct[j] >= (c[g, 3] + p[g, 4]) - M * (1 - u[j, g]))
        @constraint(model, ct[j] <= (c[g, 3] + p[g, 4]) + M * (1 - u[j, g]))
    end

    println("  添加延迟约束...")
    # ==================== 约束(23): 延迟定义 ====================
    for j in jobs
        @constraint(model, T[j] >= ct[j] - dd[j])
    end

    # ==================== 约束(24): 延迟非负 ====================
    for j in jobs
        @constraint(model, T[j] >= 0)
    end

    println("  添加车辆分组约束...")
    # ==================== 约束(25): 每个激活组至少分配一辆车 ====================
    for g in groups
        @constraint(model, sum(Y[g, v] for v in vehicles) >= θ[g])
    end

    # ==================== 约束(26): 组只能在激活后才能分配车辆 ====================
    for g in groups, v in vehicles
        @constraint(model, Y[g, v] <= θ[g])
    end

    # ==================== 约束(27): 工件只能加载到其组分配的车辆上 ====================
    # 原始非线性形式: X[j,v] <= sum(v[j,g] * Y[g,v] for g in groups)
    # 通过辅助变量 A[j,g,v] 线性化 (A[j,g,v] = v[j,g] * Y[g,v])
    for j in jobs, g in groups, v in vehicles
        @constraint(model, A[j, g, v] <= u[j, g])
        @constraint(model, A[j, g, v] <= Y[g, v])
        @constraint(model, A[j, g, v] >= u[j, g] + Y[g, v] - 1)
    end
    for j in jobs, v in vehicles
        @constraint(model, X[j, v] <= sum(A[j, g, v] for g in groups))
    end

    # ==================== 约束(28): 工件只能加载到激活组和激活车辆上 ====================
    for j in jobs, g in groups, v in vehicles
        @constraint(model, X[j, v] >= u[j, g] + Y[g, v] - 1)
    end

    # ==================== 约束(29): 每个工件恰好分配到一辆车 ====================
    for j in jobs
        @constraint(model, sum(X[j, v] for v in vehicles) == 1)
    end

    # ==================== 约束(30): 车辆载重约束 ====================
    for v in vehicles
        @constraint(model, sum(wg[j] * X[j, v] for j in jobs) <= Q)
    end

    # ==================== 约束(31): 组只能在激活车辆上 ====================
    for g in groups, v in vehicles
        @constraint(model, Y[g, v] <= γ[v])
    end

    # ==================== 约束(32): 车辆按顺序激活 ====================
    for v in 2:V
        @constraint(model, γ[v] <= γ[v-1])
    end

    # ==================== 约束(33): 每辆车最多服务一个生产组 ====================
    for v in vehicles
        @constraint(model, sum(Y[g, v] for g in groups) <= 1)
    end

    # ==================== 约束(34): 工件-车辆-组一致性 ====================
    # X_{j,v} <= Y_{g,v} + 1 - u_{j,g}  等价于  X_{j,v} - Y_{g,v} <= 1 - u_{j,g}
    for j in jobs, g in groups, v in vehicles
        @constraint(model, X[j, v] <= Y[g, v] + 1 - u[j, g])
    end



    println("  模型构建完成！")

    return model
end

# ==================== 模型求解 ====================
function solve_milp(data::Dict{String,Any}; time_limit::Float64 = 1800.0, output::Bool = false, instance_name::String = "unknown")
    """
    求解MILP模型

    # 返回
    - `results`: 包含求解结果的字典
    """
    println("开始构建模型...")
    model = build_milp_model(data; time_limit=time_limit, output=output)

    println("开始求解...")
    start_time = time()

    # 打印模型统计信息
    println("  模型变量数: $(num_variables(model))")
    println("  开始调用 optimize!...")

    flush(stdout)  # 强制刷新输出

    optimize!(model)

    println("  optimize! 执行完成!")
    flush(stdout)

    end_time = time()
    solve_time = end_time - start_time

    # 提取求解结果
    results = Dict{String,Any}()

    # 获取求解状态
    status = termination_status(model)
    results["status"] = status

    # 检查是否有可行解（包括达到时间限制但仍有可行解的情况）
    # 有效的终止状态：有最优解、或达到时间限制但有可行解
    has_feasible_solution = false
    if status == MOI.OPTIMAL || status == MOI.FEASIBLE_POINT || status == MOI.LOCALLY_SOLVED
        has_feasible_solution = has_values(model)
    elseif status == MOI.TIME_LIMIT && has_values(model)
        # 时间限制但仍有可行解
        has_feasible_solution = true
    end
    
    if has_feasible_solution
        # Gurobi: 使用原生属性获取上下界
        # BestObj: 当前可行解的目标值（上界 UB）
        # ObjBound: 搜索树最优下界（LB）
        ub = MOI.get(model, MOI.ObjectiveValue())
        lb = MOI.get(model, MOI.ObjectiveBound())

        results["objective"] = ub
        results["upper_bound"] = ub
        results["lower_bound"] = lb

        # 计算 Gap = (UB - LB) / UB × 100%  
        if isfinite(ub) && ub > 1e-9
            results["gap"] = (ub - lb) / ub * 100
        elseif isfinite(ub) && ub == lb
            results["gap"] = 0.0
        else
            results["gap"] = Inf
        end

        results["solve_time"] = solve_time
        results["node_count"] = node_count(model)
        results["simplex_iterations"] = barrier_iterations(model)

        # 提取详细解
        sol = nothing
        try
            sol = extract_solution(model, data)
        catch e
            println("  解提取失败: $e")
            println("  错误类型: $(typeof(e))")
        end

        if sol !== nothing && haskey(sol, "error")
            println("  解提取失败: $(sol["error"])")
            # 补全所有字段，避免 batch_solve 中 DataFrame schema 不全
            results["objective"] = Inf
            results["upper_bound"] = Inf
            results["lower_bound"] = Inf
            results["gap"] = Inf
            results["solve_time"] = solve_time
            results["node_count"] = 0
            results["simplex_iterations"] = 0
            results["job_to_group"] = Int[]
            results["active_groups"] = Int[]
            results["rotation"] = Int[]
            results["x_coords"] = Float64[]
            results["y_coords"] = Float64[]
            results["job_completion_time"] = Float64[]
            results["tardiness"] = Float64[]
            results["job_to_vehicle"] = Int[]
            results["active_vehicles"] = Int[]
            results["cost"] = Dict{String,Float64}()
            results["group_jobs"] = Dict{Int,Vector{Int}}()
            results["bin_jobs"] = Dict{Int,Vector{Int}}()
            results["vehicle_jobs"] = Dict{Int,Vector{Int}}()
            results["group_to_vehicle_count"] = Dict{Int,Int}()
            results["group_sequence"] = Int[]
            results["avg_group_utilization"] = 0.0
            results["tardy_job_count"] = 0
            results["xlsx_path"] = ""
            return model, results
        else
            results["job_to_group"] = sol["job_to_group"]
            results["active_groups"] = sol["active_groups"]
            results["rotation"] = sol["rotation"]
            results["x_coords"] = sol["x_coords"]
            results["y_coords"] = sol["y_coords"]
            results["job_completion_time"] = sol["job_completion_time"]
            results["tardiness"] = sol["tardiness"]
            results["job_to_vehicle"] = sol["job_to_vehicle"]
            results["active_vehicles"] = sol["active_vehicles"]
            results["cost"] = sol["cost"]
            results["group_jobs"] = sol["group_jobs"]
            results["bin_jobs"] = sol["bin_jobs"]
            results["vehicle_jobs"] = sol["vehicle_jobs"]

            # 提取每个组使用的车辆数
            group_to_vehicle_count = Dict{Int,Int}()
            for g in results["active_groups"]
                jobs_in_g = results["group_jobs"][g]
                vehicles_used = Set{Int}()
                for j in jobs_in_g
                    push!(vehicles_used, results["job_to_vehicle"][j])
                end
                group_to_vehicle_count[g] = length(vehicles_used)
            end
            results["group_to_vehicle_count"] = group_to_vehicle_count

            # 提取组在阶段2的加工顺序
            z_var = model[:z]
            group_seq = Int[]
            remaining = Set(results["active_groups"])
            current = nothing
            max_iterations = length(remaining) * length(remaining)
            iteration_count = 0
            while !isempty(remaining)
                iteration_count += 1
                if iteration_count > max_iterations
                    println("  警告: 组顺序提取达到最大迭代次数")
                    append!(group_seq, sort(collect(remaining)))
                    break
                end
                if current === nothing
                    found = false
                    for g in results["active_groups"]
                        if g in remaining
                            is_first = true
                            for k in results["active_groups"]
                                if k != g && k in remaining
                                    if value(z_var[k, g]) > 0.5
                                        is_first = false
                                        break
                                    end
                                end
                            end
                            if is_first
                                current = g
                                found = true
                                break
                            end
                        end
                    end
                    if !found
                        current = first(remaining)
                    end
                end
                if current !== nothing
                    push!(group_seq, current)
                    delete!(remaining, current)
                    next_found = false
                    for g in results["active_groups"]
                        if g in remaining
                            if value(z_var[current, g]) > 0.5
                                current = g
                                next_found = true
                                break
                            end
                        end
                    end
                    if !next_found
                        current = nothing
                    end
                end
            end
            results["group_sequence"] = group_seq

            results["avg_group_utilization"] = sol["avg_group_utilization"]
            results["tardy_job_count"] = sol["tardy_job_count"]

            if abs(results["objective"] - sol["cost"]["total_cost"]) > 0.01
                println("  警告: 目标值 ($(round(results["objective"],2))) 与重新计算的成本 ($(round(sol["cost"]["total_cost"],2))) 存在差异")
            end

            println("  解提取成功！")
            println("  活跃组数: $(length(results["active_groups"]))")
            println("  活跃车辆数: $(length(results["active_vehicles"]))")
            println("  平均利用率: $(round(sol["avg_group_utilization"]; digits=2))%")
            println("  拖期成本: $(round(sol["cost"]["tardiness_cost"]; digits=2))")
            println("  拖期工件数: $(sol["tardy_job_count"])")

            # 保存 xlsx
            try
                xlsx_dir = joinpath(SCRIPT_DIR, "MILP_Results", "xlsx")
                mkpath(xlsx_dir)
                instance_safe = replace(instance_name, r"[<>:\"/\\|?*]" => "_")
                xlsx_path = joinpath(xlsx_dir, "$(instance_safe)_solution.xlsx")
                save_solution_to_xlsx(model, data, xlsx_path, results)
                results["xlsx_path"] = xlsx_path
                println("  XLSX已保存: $xlsx_path")
            catch e
                println("  XLSX保存失败: $e")
            end
        end

        # 提取并保存详细解到 xlsx
        try
            xlsx_dir = joinpath(SCRIPT_DIR, "MILP_Results", "xlsx")
            mkpath(xlsx_dir)
            instance_safe = replace(instance_name, r"[<>:\"/\\|?*]" => "_")
            xlsx_path = joinpath(xlsx_dir, "$(instance_safe)_solution.xlsx")
            save_solution_to_xlsx(model, data, xlsx_path, results)
            results["xlsx_path"] = xlsx_path
            println("  XLSX已保存: $xlsx_path")
        catch e
            println("  XLSX保存失败: $e")
        end

        println("\n求解完成！")
        println("  状态: $(results["status"])")
        println("  上界 (UB): $(round(results["upper_bound"], digits=2))")
        println("  下界 (LB): $(round(results["lower_bound"], digits=2))")
        println("  Gap: $(round(results["gap"], digits=2))%")
        println("  求解时间: $(round(solve_time, digits=2))秒")
        if haskey(results, "active_groups")
            println("  组数 G: $(length(results["active_groups"]))")
            println("  车辆数: $(length(get(results, "active_vehicles", Int[])))")
            println("  平均利用率(%): $(round(get(results, "avg_group_utilization", 0.0), digits=2))")
            cost_dict = get(results, "cost", Dict())
            println("  拖期成本: $(round(get(cost_dict, "tardiness_cost", 0.0), digits=2))")
            println("  拖期工件数: $(get(results, "tardy_job_count", 0))")
        end
    else
        # 模型无可行解或状态异常
        println("  警告: 模型无可行解或求解异常，状态: $status")
        results["status"] = string(status)
        results["objective"] = Inf
        results["upper_bound"] = Inf
        results["lower_bound"] = Inf
        results["gap"] = Inf
        results["solve_time"] = solve_time
        results["node_count"] = get(results, "node_count", 0)
        results["simplex_iterations"] = get(results, "simplex_iterations", 0)
        # 补全所有字段，避免 batch_solve 中 DataFrame schema 不全
        results["job_to_group"] = Int[]
        results["active_groups"] = Int[]
        results["rotation"] = Int[]
        results["x_coords"] = Float64[]
        results["y_coords"] = Float64[]
        results["job_completion_time"] = Float64[]
        results["tardiness"] = Float64[]
        results["job_to_vehicle"] = Int[]
        results["active_vehicles"] = Int[]
        results["cost"] = Dict{String,Float64}()
        results["group_jobs"] = Dict{Int,Vector{Int}}()
        results["bin_jobs"] = Dict{Int,Vector{Int}}()
        results["vehicle_jobs"] = Dict{Int,Vector{Int}}()
        results["group_to_vehicle_count"] = Dict{Int,Int}()
        results["group_sequence"] = Int[]
        results["avg_group_utilization"] = 0.0
        results["tardy_job_count"] = 0
        results["xlsx_path"] = ""
    end

    return model, results
end

# ==================== 批量求解 ====================
function batch_solve(data_dir::String; time_limit::Float64 = 1800.0, output_dir::String = joinpath(SCRIPT_DIR, "MILP_Results"), output::Bool = false, only_small::Bool = false)
    """
    批量求解算例 - 按规模从小到大排序

    # 参数
    - `data_dir`: 算例数据目录
    - `time_limit`: 每个算例的时间限制（秒）
    - `output_dir`: 结果输出目录
    - `output`: 是否输出求解日志
    - `only_small`: 是否只求解小规模算例（S_开头）
    """
    mkpath(output_dir)

    # 处理相对路径：相对于脚本所在目录
    if !isabspath(data_dir)
        data_dir = joinpath(SCRIPT_DIR, data_dir)
    end

    # 只扫描指定目录下的jld2文件，不扫描子目录
    if !isdir(data_dir)
        println("错误: 目录不存在: $data_dir")
        return
    end

    instance_files = filter(f -> endswith(f, ".jld2"), readdir(data_dir, join=true))

    if isempty(instance_files)
        println("在 $data_dir 中没有找到算例文件")
        return
    end

    # 去重（防止同一文件被多次添加）
    instance_files = unique(instance_files)

    # 从文件名提取规模参数 (格式: S_J_W_X, M_J_W_X, L_J_W_X 或 I_J_W_X)
    function parse_instance_size(filename)
        fname = splitext(last(splitdir(filename)))[1]
        # 匹配 S_J_W_X, M_J_W_X, L_J_W_X 格式
        m = match(r"[SML]_(\d+)_(\d+)_(\d+)", fname)
        if m !== nothing
            J = parse(Int, m.captures[1])  # 工件数
            W = parse(Int, m.captures[2])  # 模台数
            idx = parse(Int, m.captures[3]) # 序号
            prefix = fname[1]  # S, M, 或 L
            return (J, W, idx, fname, prefix)
        end
        # 兼容旧格式 I_J_W_X
        m = match(r"I_(\d+)_(\d+)_(\d+)", fname)
        if m !== nothing
            J = parse(Int, m.captures[1])  # 工件数
            W = parse(Int, m.captures[2])  # 模台数
            idx = parse(Int, m.captures[3]) # 序号
            return (J, W, idx, fname, 'I')
        end
        # 备选：从文件名猜测
        return (999, 999, 0, fname, '?')
    end

    # 解析所有文件
    parsed = [parse_instance_size(f) for f in instance_files]

    # 过滤：只保留小规模算例（如果指定）
    if only_small
        filtered_parsed = filter(p -> p[5] == 'S', parsed)
        instance_files = [f for (f, p) in zip(instance_files, parsed) if p[5] == 'S']
        parsed = filtered_parsed
        println("【只求解小规模算例】过滤后剩余 $(length(instance_files)) 个算例")
    else
        instance_files = [f for (f, p) in zip(instance_files, parsed)]
    end

    # 按规模从小到大排序：先按J(工件数)，再按W(模台数)
    sorted_indices = sortperm(parsed, by=x->(x[1], x[2], x[3]))
    instance_files = instance_files[sorted_indices]
    parsed = parsed[sorted_indices]

    # 统计各规模
    sizes = unique([(p[1], p[2], string(p[5])) for p in parsed])
    sort!(sizes, by=x->(x[3], x[1], x[2]))
    println("找到 $(length(instance_files)) 个算例文件")
    println("规模分布:")
    for (J, W, prefix) in sizes
        count = sum(1 for p in parsed if p[1]==J && p[2]==W && string(p[5])==prefix)
        println("  $(prefix)_$(J)_$(W): $count 个")
    end
    println("求解顺序: 从小规模到大规模")
    println("求解时间限制: 1800秒")
    println("=" ^ 70)

    # 使用时间戳生成唯一文件名
    timestamp = Dates.format(Dates.now(), "yyyy-mm-dd_HH-MM-SS")
    results_file = joinpath(output_dir, "milp_results_$timestamp.csv")
    summary_file = joinpath(output_dir, "milp_summary_$timestamp.csv")

    all_results = []

    for (i, filepath) in enumerate(instance_files)
        instance_name = splitext(last(splitdir(filepath)))[1]
        instance_time_limit = get_time_limit_by_instance(instance_name)
        println("\n[$i/$(length(instance_files))] 求解 $instance_name (时间限制: $(Int(instance_time_limit))s)")

        try
            data = load_instance(filepath)
            model, results = solve_milp(data; time_limit=instance_time_limit, output=output, instance_name=instance_name)

            # 保存单个结果
            results["instance"] = instance_name
            push!(all_results, results)

            # 实时保存到CSV
            save_results(results, instance_name, results_file)

        catch e
            println("  错误: $e")
            push!(all_results, Dict(
                "instance" => instance_name,
                "rotation" => Int[],
                "status" => "ERROR",
                "objective" => Inf,
                "upper_bound" => Inf,
                "lower_bound" => Inf,
                "gap" => Inf,
                "solve_time" => 0,
                "node_count" => 0,
                "simplex_iterations" => 0,
                "active_groups" => Int[],
                "active_vehicles" => Int[],
                "job_to_group" => Int[],
                "job_to_vehicle" => Int[],
                "x_coords" => Float64[],
                "y_coords" => Float64[],
                "tardiness" => Float64[],
                "job_completion_time" => Float64[],
                "cost" => Dict{String,Float64}(),
                "xlsx_path" => "",
                "group_jobs" => Dict{Int,Vector{Int}}(),
                "bin_jobs" => Dict{Int,Vector{Int}}(),
                "vehicle_jobs" => Dict{Int,Vector{Int}}(),
                "group_to_vehicle_count" => Dict{Int,Int}(),
                "group_sequence" => Int[],
                "avg_group_utilization" => 0.0,
                "tardy_job_count" => 0
            ))
        end
    end

    # 生成汇总报告
    df = DataFrame(all_results)
    CSV.write(summary_file, df)

    println("\n" * "=" ^ 70)
    println("批量求解完成！")
    println("  总算例数: $(length(instance_files))")
    println("  结果文件: $results_file")
    println("  汇总文件: $summary_file")
end

# ==================== 结果保存 ====================
function save_results(results::Dict{String,Any}, instance_name::String, output_path::String)
    """
    保存求解结果到CSV文件
    """
    # 提取组数和车辆数
    active_groups_count = length(get(results, "active_groups", Int[]))
    active_vehicles_count = length(get(results, "active_vehicles", Int[]))

    # 提取各成本项
    cost_dict = get(results, "cost", Dict{String,Any}())
    tardiness_cost = get(cost_dict, "tardiness_cost", 0.0)
    vehicle_cost = get(cost_dict, "vehicle_fixed_cost", 0.0)
    mold_cost = get(cost_dict, "mold_activation_cost", 0.0)

    # 提取每组工件数
    group_jobs = get(results, "group_jobs", Dict{Int,Vector{Int}}())
    jobs_per_group = join(["$g:$(length(get(group_jobs, g, Int[])))" for g in sort(collect(keys(group_jobs)))], ";")
    
    # 提取每组车辆数
    group_to_vehicle_count = get(results, "group_to_vehicle_count", Dict{Int,Int}())
    vehicles_per_group = join(["$g:$(get(group_to_vehicle_count, g, 0))" for g in sort(collect(keys(group_to_vehicle_count)))], ";")
    
    # 提取组加工顺序
    group_sequence = get(results, "group_sequence", Int[])
    group_seq_str = join(group_sequence, "->")

    # 计算总运输工件数
    vehicles_dict = get(results, "vehicle_jobs", Dict{Int,Vector{Int}}())
    total_jobs_in_vehicles = isempty(vehicles_dict) ? 0 : sum(length(v) for (k, v) in vehicles_dict)

    df = DataFrame(
        instance = [instance_name],
        status = [string(results["status"])],
        objective = [results["objective"]],
        upper_bound = [results["upper_bound"]],
        lower_bound = [results["lower_bound"]],
        gap = [results["gap"]],
        solve_time = [results["solve_time"]],
        node_count = [get(results, "node_count", 0)],
        group_count = [active_groups_count],
        vehicle_count = [active_vehicles_count],
        avg_group_utilization = [round(get(results, "avg_group_utilization", 0.0), digits=2)],
        tardiness_cost = [tardiness_cost],
        tardy_job_count = [get(results, "tardy_job_count", 0)],
        jobs_per_group = [jobs_per_group],
        vehicles_per_group = [vehicles_per_group],
        total_jobs_in_vehicles = [total_jobs_in_vehicles],
        group_sequence = [group_seq_str],
        vehicle_cost = [vehicle_cost],
        mold_cost = [mold_cost],
        timestamp = [Dates.format(now(), "yyyy-mm-dd HH:MM:SS")]
    )

    if isfile(output_path)
        # 追加到现有文件
        existing_df = CSV.read(output_path, DataFrame)
        df = vcat(existing_df, df)
    end

    CSV.write(output_path, df)
    println("  结果已保存到: $output_path")
end

function save_results_with_overwrite(results::Dict{String,Any}, output_path::String)
    """
    保存求解结果到CSV文件（覆盖模式，仅保留每个算例的最佳结果）
    """
    instance_name = results["instance"]
    
    # 提取组数和车辆数
    active_groups_count = length(get(results, "active_groups", Int[]))
    active_vehicles_count = length(get(results, "active_vehicles", Int[]))

    # 提取每组工件数
    group_jobs = get(results, "group_jobs", Dict{Int,Vector{Int}}())
    jobs_per_group = join(["$g:$(length(get(group_jobs, g, Int[])))" for g in sort(collect(keys(group_jobs)))], ";")
    
    # 提取每组车辆数
    group_to_vehicle_count = get(results, "group_to_vehicle_count", Dict{Int,Int}())
    vehicles_per_group = join(["$g:$(get(group_to_vehicle_count, g, 0))" for g in sort(collect(keys(group_to_vehicle_count)))], ";")
    
    # 提取组加工顺序
    group_sequence = get(results, "group_sequence", Int[])
    group_seq_str = join(group_sequence, "->")

    # 计算总运输工件数
    vehicles_dict = get(results, "vehicle_jobs", Dict{Int,Vector{Int}}())
    total_jobs_in_vehicles = isempty(vehicles_dict) ? 0 : sum(length(v) for (k, v) in vehicles_dict)

    if isfile(output_path)
        try
            existing_df = CSV.read(output_path, DataFrame)
            # 过滤掉已存在的相同算例
            existing_df = existing_df[existing_df.instance .!= instance_name, :]

            new_row = DataFrame(
                instance = [instance_name],
                status = [string(results["status"])],
                objective = [results["objective"]],
                upper_bound = [results["upper_bound"]],
                lower_bound = [results["lower_bound"]],
                gap = [results["gap"]],
                solve_time = [results["solve_time"]],
                node_count = [get(results, "node_count", 0)],
                group_count = [active_groups_count],
                vehicle_count = [active_vehicles_count],
                avg_group_utilization = [round(get(results, "avg_group_utilization", 0.0), digits=2)],
                tardiness_cost = [get(cost_dict, "tardiness_cost", 0.0)],
                tardy_job_count = [get(results, "tardy_job_count", 0)],
                jobs_per_group = [jobs_per_group],
                vehicles_per_group = [vehicles_per_group],
                total_jobs_in_vehicles = [total_jobs_in_vehicles],
                group_sequence = [group_seq_str],
                vehicle_cost = [get(cost_dict, "vehicle_fixed_cost", 0.0)],
                mold_cost = [get(cost_dict, "mold_activation_cost", 0.0)],
                timestamp = [Dates.format(now(), "yyyy-mm-dd HH:MM:SS")]
            )
            df = vcat(existing_df, new_row)
        catch e
            # 如果读取失败，创建新的
        df = DataFrame(
            instance = [instance_name],
            status = [string(results["status"])],
            objective = [results["objective"]],
            upper_bound = [results["upper_bound"]],
            lower_bound = [results["lower_bound"]],
            gap = [results["gap"]],
            solve_time = [results["solve_time"]],
            node_count = [get(results, "node_count", 0)],
            group_count = [active_groups_count],
            vehicle_count = [active_vehicles_count],
            avg_group_utilization = [round(get(results, "avg_group_utilization", 0.0), digits=2)],
            tardiness_cost = [get(cost_dict, "tardiness_cost", 0.0)],
            tardy_job_count = [get(results, "tardy_job_count", 0)],
            jobs_per_group = [jobs_per_group],
            vehicles_per_group = [vehicles_per_group],
            total_jobs_in_vehicles = [total_jobs_in_vehicles],
            group_sequence = [group_seq_str],
            vehicle_cost = [get(cost_dict, "vehicle_fixed_cost", 0.0)],
            mold_cost = [get(cost_dict, "mold_activation_cost", 0.0)],
            timestamp = [Dates.format(now(), "yyyy-mm-dd HH:MM:SS")]
        )
        end
    else
        df = DataFrame(
            instance = [instance_name],
            status = [string(results["status"])],
            objective = [results["objective"]],
            upper_bound = [results["upper_bound"]],
            lower_bound = [results["lower_bound"]],
            gap = [results["gap"]],
            solve_time = [results["solve_time"]],
            node_count = [get(results, "node_count", 0)],
            timestamp = [Dates.format(now(), "yyyy-mm-dd HH:MM:SS")]
        )
    end
    
    CSV.write(output_path, df)
end

# ==================== 解提取与结果导出 ====================
function extract_solution(model::Model, data::Dict{String,Any})
    """
    从已求解的模型中提取所有决策变量的值
    返回包含所有解信息的字典；若提取失败返回Dict("error" => ...)
    """
    try
        J = data["JJ"]; W = data["WW_num"]; G = data["GG"]; V = data["VV"]
        jobs = 1:J; bins = 1:W; groups = 1:G; vehicles = 1:V
        wj = data["wj"]; hj = data["hj"]; wg = data["wg"]

        result = Dict{String,Any}()

        # --- 工件分组 (u[j,g] = 1 表示工件j分配到组g) ---
        job_to_group = Int[]  # job_to_group[j] = g
        u_var = model[:u]
        for j in jobs
            best_g = 0; best_val = 0.0
            for g in groups
                val = value(u_var[j, g])
                if val > best_val; best_val = val; best_g = g; end
            end
            push!(job_to_group, best_g)
        end
        result["job_to_group"] = job_to_group

        # --- 组激活与模台分配 (θ[g], δ[g,w]) ---
        active_groups = Int[]  # 实际使用的组
        group_to_bin = Int[]   # group_to_bin[idx] = w (按active_groups的顺序)
        θ_var = model[:θ]; δ_var = model[:δ]
        for g in groups
            if value(θ_var[g]) > 0.5
                push!(active_groups, g)
                for w in bins
                    if value(δ_var[g, w]) > 0.5; push!(group_to_bin, w); break; end
                end
            end
        end
        result["active_groups"] = active_groups
        result["group_to_bin"] = group_to_bin

        # --- 工件旋转 (o[j]) ---
        o_var = model[:o]
        result["rotation"] = [round(Int, value(o_var[j])) for j in jobs]

        # --- 工件坐标 (x[j], y[j]) ---
        x_var = model[:x]; y_var = model[:y]
        result["x_coords"] = [value(x_var[j]) for j in jobs]
        result["y_coords"] = [value(y_var[j]) for j in jobs]

        # --- 组-工件明细 (每个活跃组包含哪些工件) ---
        group_jobs = Dict{Int,Vector{Int}}()
        for g in active_groups
            group_jobs[g] = Int[j for j in jobs if job_to_group[j] == g]
        end
        result["group_jobs"] = group_jobs

        # --- 组在模台上的工件明细 ---
        bin_jobs = Dict{Int,Vector{Int}}()
        for w in bins; bin_jobs[w] = Int[]; end
        for (idx, g) in enumerate(active_groups)
            w = group_to_bin[idx]
            for j in group_jobs[g]; push!(bin_jobs[w], j); end
        end
        result["bin_jobs"] = bin_jobs

        # --- 组调度时间 (c[g,s], p[g,s], ct[j], T[j]) ---
        c_var = model[:c]; p_var = model[:p]; ct_var = model[:ct]; T_var = model[:T]
        result["completion_time"] = Dict{Int,Dict{Int,Float64}}()
        result["phase_time"] = Dict{Int,Dict{Int,Float64}}()
        for g in groups
            result["completion_time"][g] = Dict{Int,Float64}()
            result["phase_time"][g] = Dict{Int,Float64}()
            for s in 1:4; result["completion_time"][g][s] = value(c_var[g, s]); end
            for s in 1:3; result["phase_time"][g][s] = value(p_var[g, s]); end
        end
        result["job_completion_time"] = [value(ct_var[j]) for j in jobs]
        result["tardiness"] = [value(T_var[j]) for j in jobs]

        # --- 车辆分配 (X[j,v], Y[g,v], A[j,g,v], γ[v]) ---
        X_var = model[:X]; Y_var = model[:Y]; γ_var = model[:γ]
        job_to_vehicle = Int[]
        for j in jobs
            push!(job_to_vehicle, 0)
            for v in vehicles
                if value(X_var[j, v]) > 0.5; job_to_vehicle[end] = v; break; end
            end
        end
        result["job_to_vehicle"] = job_to_vehicle

        # 从 X[j,v] 反推每个车辆装载了哪些组（用于与 Tex 中 eq:job_group_vehicle 对齐）
        active_vehicles = Int[]
        vehicle_jobs = Dict{Int,Vector{Int}}()
        for v in vehicles
            if value(γ_var[v]) > 0.5
                push!(active_vehicles, v)
                vehicle_jobs[v] = Int[j for j in jobs if job_to_vehicle[j] == v]
            else
                vehicle_jobs[v] = Int[]
            end
        end
        result["active_vehicles"] = active_vehicles
        result["vehicle_jobs"] = vehicle_jobs

        # --- 成本明细 ---
        tard_val = [value(T_var[j]) for j in jobs]
        tard_sum = sum(data["betabeta"][j] * tard_val[j] for j in jobs if !isnan(tard_val[j]))
        tardiness_cost = isnan(tard_sum) ? 0.0 : tard_sum
        vehicle_sum = sum(value(γ_var[v]) * data["rho"] for v in vehicles)
        vehicle_cost = isnan(vehicle_sum) ? 0.0 : vehicle_sum
        mold_sum = sum(value(θ_var[g]) * data["alpha"] for g in groups)
        mold_cost = isnan(mold_sum) ? 0.0 : mold_sum
        total_cost = tardiness_cost + vehicle_cost + mold_cost
        result["cost"] = Dict(
            "tardiness_cost" => tardiness_cost,
            "vehicle_fixed_cost" => vehicle_cost,
            "mold_activation_cost" => mold_cost,
            "total_cost" => total_cost
        )

        # --- 平均工件组面积利用率（按组计算） ---
        WW_bin = data["WW"]; HH_bin = data["HH"]  # 标量，所有模台共用
        group_utilizations = Float64[]
        for g in active_groups
            jobs_in_g = get(group_jobs, g, Int[])
            isempty(jobs_in_g) && continue
            bin_area = WW_bin * HH_bin  # 标量直接使用
            used_area = sum(
                (result["rotation"][j] == 1 ? hj[j] : wj[j]) *
                (result["rotation"][j] == 1 ? wj[j] : hj[j])
                for j in jobs_in_g
            )
            push!(group_utilizations, used_area / bin_area * 100)
        end
        avg_group_utilization = isempty(group_utilizations) ? 0.0 : mean(group_utilizations)

        # --- 拖期工件数（T > 0 的工件数量） ---
        tardy_job_count = count(v -> v > 1e-6, tard_val)

        result["avg_group_utilization"] = avg_group_utilization
        result["tardy_job_count"] = tardy_job_count

        return result
    catch e
        return Dict("error" => string(e))
    end
end

function save_solution_to_xlsx(model::Model, data::Dict{String,Any}, output_path::String, results::Dict{String,Any})
    """
    将MILP求解结果保存为多Sheet Excel文件

    Sheet 1: 工件分组方案
    Sheet 2: 模台布局
    Sheet 3: 分车方案
    Sheet 4: 调度甘特图
    Sheet 5: 成本明细
    Sheet 6: 求解信息
    """
    J = data["JJ"]; W = data["WW_num"]; G = data["GG"]; V = data["VV"]
    jobs = 1:J; bins = 1:W; groups = 1:G; vehicles = 1:V
    wj = data["wj"]; hj = data["hj"]; wg = data["wg"]
    pp = data["pp"]; dd = data["dd"]; betabeta = data["betabeta"]
    WW_bin = data["WW"]; HH_bin = data["HH"]
    ptr = data["ptr"]; rho = data["rho"]
    # load_rate = data["load_rate"]  # 单位运输成本 - 不加载
    α = data["alpha"]

    sol = extract_solution(model, data)
    job_to_group = sol["job_to_group"]
    active_groups = sol["active_groups"]
    group_to_bin = sol["group_to_bin"]
    group_jobs = sol["group_jobs"]
    bin_jobs = sol["bin_jobs"]
    rotation = sol["rotation"]
    x_coords = sol["x_coords"]
    y_coords = sol["y_coords"]
    job_to_vehicle = sol["job_to_vehicle"]
    active_vehicles = sol["active_vehicles"]
    cost = sol["cost"]

    mkpath(dirname(output_path))

    # ── Sheet 1: 工件分组方案 ──────────────────────
    sheet1_headers = ["工件编号", "工件宽度", "工件高度", "工件重量",
                      "旋转(0=否,1=是)", "所属组", "组所在模台",
                      "交货期", "延迟惩罚权重", "工件完工时间", "工件延迟时间"]
    sheet1_rows = Any[]
    for j in jobs
        g = job_to_group[j]
        bin_w = "-"
        if g in active_groups
            idx_g = findfirst(==(g), active_groups)
            if idx_g !== nothing && idx_g <= length(group_to_bin)
                bin_w = group_to_bin[idx_g]
            end
        end
        push!(sheet1_rows, Any[
            j, wj[j], hj[j], wg[j], rotation[j], g, bin_w,
            round(dd[j], digits=2), betabeta[j],
            round(sol["job_completion_time"][j], digits=2),
            round(sol["tardiness"][j], digits=2)
        ])
    end

    # ── Sheet 2: 模台布局 ──────────────────────────
    sheet2_headers = ["模台编号", "模台宽度", "模台高度", "工件编号",
                      "工件宽度", "工件高度", "旋转后宽度", "旋转后高度",
                      "X坐标", "Y坐标", "工件组编号"]
    sheet2_rows = Any[]
    for b in bins
        if haskey(bin_jobs, b) && !isempty(bin_jobs[b])
            for j in bin_jobs[b]
                rot = rotation[j]
                w_rot = rot == 1 ? hj[j] : wj[j]
                h_rot = rot == 1 ? wj[j] : hj[j]
                push!(sheet2_rows, Any[
                    b, WW_bin, HH_bin, j, wj[j], hj[j], w_rot, h_rot,
                    round(x_coords[j], digits=2), round(y_coords[j], digits=2),
                    job_to_group[j]
                ])
            end
        end
    end

    # ── Sheet 3: 分车方案 ──────────────────────────
    sheet3_headers = ["车辆编号", "车辆载重上限", "车辆固定成本",
                      "是否使用(0=否,1=是)", "车辆载重",
                      "组编号", "组所在模台", "组内工件列表"]
    sheet3_rows = Any[]
    for (idx, g) in enumerate(active_groups)
        isempty(group_jobs[g]) && continue
        v_of_g = job_to_vehicle[group_jobs[g][1]]
        w_of_g = group_to_bin[idx]
        jobs_in_g = group_jobs[g]
        wg_sum = sum(wg[j] for j in jobs_in_g)
        # 运输成本 = 0 (目标函数中不含运输成本)
        push!(sheet3_rows, Any[
            v_of_g, data["Q"], rho, 1, round(wg_sum, digits=2),
            g, w_of_g, join(jobs_in_g, ",")
        ])
    end

    # ── Sheet 4: 调度甘特图 ────────────────────────
    sheet4_headers = ["组编号", "组所在模台", "工件列表", "工件数",
                      "阶段1开始", "阶段1完成", "阶段1时长",
                      "阶段2开始", "阶段2完成", "阶段2时长",
                      "阶段3开始", "阶段3完成", "阶段3时长(已含养护)",
                      "阶段4(运输)开始", "阶段4完成", "阶段4时长"]
    sheet4_rows = Any[]
    for (idx, g) in enumerate(active_groups)
        if !haskey(sol["completion_time"], g)
            continue
        end
        c_times = sol["completion_time"][g]
        phase_t = sol["phase_time"][g]
        gbin = group_to_bin[idx]
        # 计算开始时间: S = c - p
        s1 = get(c_times, 1, 0.0) - get(phase_t, 1, 0.0)
        s2 = get(c_times, 2, 0.0) - get(phase_t, 2, 0.0)
        s3 = get(c_times, 3, 0.0) - get(phase_t, 3, 0.0)
        s4 = get(c_times, 4, 0.0) - ptr  # 运输开始时间
        push!(sheet4_rows, Any[
            g, gbin, join(get(group_jobs, g, Int[]), ","), length(get(group_jobs, g, Int[])),
            round(s1, digits=2),
            round(get(c_times, 1, 0.0), digits=2),
            round(get(phase_t, 1, 0.0), digits=2),
            round(s2, digits=2),
            round(get(c_times, 2, 0.0), digits=2),
            round(get(phase_t, 2, 0.0), digits=2),
            round(s3, digits=2),
            round(get(c_times, 3, 0.0), digits=2),
            round(get(phase_t, 3, 0.0), digits=2),
            round(s4, digits=2),
            round(get(c_times, 4, 0.0), digits=2),
            ptr
        ])
    end

    # ── Sheet 5: 成本明细 ──────────────────────────
    sheet5_headers = ["成本项目", "数值", "单位", "说明"]
    tard_cost = cost["tardiness_cost"]
    veh_cost = cost["vehicle_fixed_cost"]
    mold_cost = cost["mold_activation_cost"]
    total_cost = cost["total_cost"]
    sheet5_rows = Any[
        ["延迟惩罚成本",
         (isnothing(tard_cost) ? "N/A" : round(tard_cost, digits=2)),
         "元", "各工件 β_j × T_j 之和"],
        ["车辆固定成本",
         (isnothing(veh_cost) ? "N/A" : round(veh_cost, digits=2)),
         "元/车", "使用的车辆数 × ρ"],
        ["模台激活成本",
         (isnothing(mold_cost) ? "N/A" : round(mold_cost, digits=2)),
         "元/模台", "使用的模台数 × α"],
        ["总成本",
         (isnothing(total_cost) ? "N/A" : round(total_cost, digits=2)),
         "元", "延迟惩罚 + 车辆固定 + 模台激活"],
        ["使用的模台数", length(active_groups), "个", ""],
        ["使用的车辆数", length(active_vehicles), "辆", ""],
        ["未按时交货的工件数", count(>(0), sol["tardiness"]), "个", ""],
        ["总延迟时间", round(sum(sol["tardiness"]), digits=2), "时间单位", ""],
    ]

    # ── Sheet 6: 求解信息 ──────────────────────────
    sheet6_headers = ["项目", "值"]
    sheet6_rows = Any[
        ["工件数 J", J],
        ["模台数上限 W", W],
        ["工件宽度范围", "$(minimum(wj))~$(maximum(wj))"],
        ["工件高度范围", "$(minimum(hj))~$(maximum(hj))"],
        ["模台尺寸", "$(WW_bin) × $(HH_bin)"],
        ["模台激活成本 α", α],
        ["车辆固定成本 ρ", rho],
        ["车辆载重上限 Q", data["Q"]],
        ["运输时间 ptr", ptr],
        ["交货期范围", "$(round(minimum(dd),digits=2))~$(round(maximum(dd),digits=2))"],
        ["延迟惩罚范围", "$(round(minimum(betabeta),digits=2))~$(round(maximum(betabeta),digits=2))"],
        ["求解状态", string(termination_status(model))],
        ["上界 (Best Bound)", results["upper_bound"]],
        ["下界 (Best Integer)", results["lower_bound"]],
        ["Gap (%)", round(results["gap"], digits=4)],
        ["求解时间 (秒)", round(results["solve_time"], digits=2)],
        ["未按时交货工件数", count(>(0), sol["tardiness"]), "个"],
    ]

    # ── 写入 xlsx ──────────────────────────────────
    mkpath(dirname(output_path))

    XLSX.openxlsx(output_path, mode="w") do xf
        for (sheetname, headers, rows) in [
            ("分组方案",   sheet1_headers, sheet1_rows),
            ("模台布局",   sheet2_headers, sheet2_rows),
            ("分车方案",   sheet3_headers, sheet3_rows),
            ("调度甘特图", sheet4_headers, sheet4_rows),
            ("成本明细",   sheet5_headers, sheet5_rows),
            ("求解信息",   sheet6_headers, sheet6_rows),
        ]
            sheet = XLSX.addsheet!(xf, sheetname)
            # 写入表头
            for (col_idx, h) in enumerate(headers)
                sheet[1, col_idx] = h
            end
            # 写入数据行
            for (row_idx, row_data) in enumerate(rows)
                for (col_idx, val) in enumerate(row_data)
                    sheet[row_idx + 1, col_idx] = val
                end
            end
        end
    end
end

# ==================== 辅助函数 ====================
function get_time_limit_by_instance(filename::String)::Float64
    """
    根据算例文件名确定时间限制
    - S_*: 小规模 -> 600秒
    - M_*: 中等规模 -> 1000秒
    - L_*: 大规模 -> 1800秒（保留但不使用）
    - I_*: 旧格式，默认1800秒
    """
    fname = splitext(last(splitdir(filename)))[1]

    if startswith(fname, "S_")
        return 600.0   # 小规模: 600秒
    elseif startswith(fname, "M_")
        return 1000.0   # 中等规模: 1000秒
    elseif startswith(fname, "L_")
        return 1800.0    # 大规模: 1800秒
    else
        return 1800.0    # 默认: 1800秒
    end
end

# ==================== 主程序 ====================
# 统一主程序入口放在文件末尾，这里不再直接执行，避免与下方入口重复


# ==================== 多目录批量求解 ====================
function batch_solve_all_dirs(data_dirs::Vector{String}; time_limit::Float64 = 1800.0, output_dir::String = joinpath(SCRIPT_DIR, "MILP_Results"), output::Bool = false, only_small::Bool = false)
    """
    批量求解多个目录的算例 - 按规模从小到大排序

    # 参数
    - `data_dirs`: 多个算例数据目录
    - `time_limit`: 每个算例的时间限制（秒）
    - `output_dir`: 结果输出目录
    - `output`: 是否输出求解日志
    - `only_small`: 是否只求解小规模算例（S_开头）

    # 示例
    batch_solve_all_dirs(["DATA_Instances/small", "DATA_Instances/medium", "DATA_Instances/large"])
    """
    mkpath(output_dir)

    # 收集所有目录中的文件
    all_files = String[]
    for data_dir in data_dirs
        if isdir(data_dir)
            files = filter(f -> endswith(f, ".jld2"), readdir(data_dir, join=true))
            all_files = vcat(all_files, files)
        else
            println("警告: 目录不存在: $data_dir")
        end
    end

    if isempty(all_files)
        println("没有找到任何算例文件")
        return
    end

    # 从文件名提取规模参数 (格式: S_J_W_X, M_J_W_X, L_J_W_X 或 I_J_W_X)
    function parse_instance_size(filename)
        fname = splitext(last(splitdir(filename)))[1]
        # 匹配 S_J_W_X, M_J_W_X, L_J_W_X 格式
        m = match(r"[SML]_(\d+)_(\d+)_(\d+)", fname)
        if m !== nothing
            J = parse(Int, m.captures[1])  # 工件数
            W = parse(Int, m.captures[2])  # 模台数
            idx = parse(Int, m.captures[3]) # 序号
            prefix = fname[1]  # S, M, 或 L
            return (J, W, idx, fname, prefix)
        end
        # 兼容旧格式 I_J_W_X
        m = match(r"I_(\d+)_(\d+)_(\d+)", fname)
        if m !== nothing
            J = parse(Int, m.captures[1])  # 工件数
            W = parse(Int, m.captures[2])  # 模台数
            idx = parse(Int, m.captures[3]) # 序号
            return (J, W, idx, fname, 'I')
        end
        return (999, 999, 0, fname, '?')
    end

    # 解析所有文件
    parsed = [parse_instance_size(f) for f in all_files]

    # 过滤：只保留小规模算例（如果指定）
    if only_small
        filtered = filter(p -> p[5] == 'S', parsed)
        all_files = [f for (f, p) in zip(all_files, parsed) if p[5] == 'S']
        parsed = filtered
        println("【只求解小规模算例】过滤后剩余 $(length(all_files)) 个算例")
    end

    # 按规模从小到大排序：先按J(工件数)，再按W(模台数)
    sorted_indices = sortperm(parsed, by=x->(x[1], x[2], x[3]))
    all_files = all_files[sorted_indices]
    parsed = parsed[sorted_indices]

    # 统计各规模
    sizes = unique([(p[1], p[2], string(p[5])) for p in parsed])
    sort!(sizes, by=x->(x[3], x[1], x[2]))
    println("找到 $(length(all_files)) 个算例文件")
    println("规模分布:")
    for (J, W, prefix) in sizes
        count = sum(1 for p in parsed if p[1]==J && p[2]==W && string(p[5])==prefix)
        println("  $(prefix)_$(J)_$(W): $count 个")
    end
    println("求解顺序: 从小规模到大规模")
    println("求解时间限制: 1800秒")
    println("=" ^ 70)
    println("求解时间限制: S_*=600s, M_*=1000s, L_*=1800s")
    println("=" ^ 70)

    # 使用时间戳生成唯一文件名
    timestamp = Dates.format(Dates.now(), "yyyy-mm-dd_HH-MM-SS")
    results_file = joinpath(output_dir, "milp_results_$timestamp.csv")
    summary_file = joinpath(output_dir, "milp_summary_$timestamp.csv")

    all_results = []

    for (i, filepath) in enumerate(all_files)
        instance_name = splitext(last(splitdir(filepath)))[1]
        instance_time_limit = get_time_limit_by_instance(filepath)
        println("\n[$i/$(length(all_files))] 求解 $instance_name (时间限制: $(Int(instance_time_limit))s)")

        try
            data = load_instance(filepath)
            model, results = solve_milp(data; time_limit=instance_time_limit, output=true, instance_name=instance_name)  # 启用求解日志

            results["instance"] = instance_name
            push!(all_results, results)

            # 实时保存到CSV
            save_results(results, instance_name, results_file)

        catch e
            println("  错误: $e")
            push!(all_results, Dict(
                "instance" => instance_name,
                "rotation" => Int[],
                "status" => "ERROR",
                "objective" => Inf,
                "upper_bound" => Inf,
                "lower_bound" => Inf,
                "gap" => Inf,
                "solve_time" => 0,
                "node_count" => 0,
                "simplex_iterations" => 0,
                "active_groups" => Int[],
                "active_vehicles" => Int[],
                "job_to_group" => Int[],
                "job_to_vehicle" => Int[],
                "x_coords" => Float64[],
                "y_coords" => Float64[],
                "tardiness" => Float64[],
                "job_completion_time" => Float64[],
                "cost" => Dict{String,Float64}(),
                "xlsx_path" => "",
                "group_jobs" => Dict{Int,Vector{Int}}(),
                "bin_jobs" => Dict{Int,Vector{Int}}(),
                "vehicle_jobs" => Dict{Int,Vector{Int}}(),
                "group_to_vehicle_count" => Dict{Int,Int}(),
                "group_sequence" => Int[],
                "avg_group_utilization" => 0.0,
                "tardy_job_count" => 0
            ))
        end
    end

    # 生成汇总报告
    df = DataFrame(all_results)
    CSV.write(summary_file, df)

    println("\n" * "=" ^ 70)
    println("批量求解完成！")
    println("  总算例数: $(length(all_files))")
    println("  结果文件: $results_file")
    println("  汇总文件: $summary_file")
    println("=" ^ 70)
end

# ==================== 主程序入口 ====================
# 默认只运行小规模算例（S_开头），时间限制由 get_time_limit_by_instance 自动确定
if abspath(PROGRAM_FILE) == @__FILE__
    println("\n开始批量求解...")
    println("求解范围: DATA_Instances 目录 - 所有算例（S_、M_、L_）")
    println("时间限制: S_小规模=600s, M_中规模=1000s, L_大规模=1800s")
    data_dir = joinpath(SCRIPT_DIR, "DATA_Instances")
    batch_solve(data_dir; time_limit=1800.0, output_dir=joinpath(SCRIPT_DIR, "MILP_Results"), output=true, only_small=false)  # 测试所有规模
end
