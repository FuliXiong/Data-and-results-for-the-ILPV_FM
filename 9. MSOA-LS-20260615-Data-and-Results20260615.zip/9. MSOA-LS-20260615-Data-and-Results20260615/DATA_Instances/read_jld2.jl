using JLD2

data = load("S_10_2_1.jld2")

println("=" ^ 70)
println("算例文件内容: S_10_2_1.jld2")
println("=" ^ 70)

for (k, v) in data
    println("$k => $(typeof(v))")
    if typeof(v) <: AbstractVector
        if length(v) <= 20
            println("  $v")
        else
            println("  [$(v[1:10]) ... $(v[end])] (共$(length(v))个)")
        end
    elseif typeof(v) <: AbstractMatrix
        println("  矩阵尺寸: $(size(v))")
        println("  $v")
    else
        println("  $v")
    end
    println()
end
